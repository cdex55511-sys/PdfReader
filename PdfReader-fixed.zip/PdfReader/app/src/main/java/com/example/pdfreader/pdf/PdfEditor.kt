package com.example.pdfreader.pdf

import android.content.Context
import android.graphics.Bitmap
import android.graphics.Canvas
import android.graphics.Paint
import android.text.Layout
import android.text.StaticLayout
import android.text.TextPaint
import com.example.pdfreader.data.Annot
import com.example.pdfreader.data.AnnotType
import com.example.pdfreader.data.NRect
import com.example.pdfreader.data.OutlineEntry
import com.example.pdfreader.data.PageSpec
import com.example.pdfreader.data.Pt
import com.example.pdfreader.data.SearchHit
import com.tom_roush.pdfbox.android.PDFBoxResourceLoader
import com.tom_roush.pdfbox.io.MemoryUsageSetting
import com.tom_roush.pdfbox.multipdf.PDFMergerUtility
import com.tom_roush.pdfbox.pdmodel.PDDocument
import com.tom_roush.pdfbox.pdmodel.PDPage
import com.tom_roush.pdfbox.pdmodel.PDPageContentStream
import com.tom_roush.pdfbox.pdmodel.common.PDRectangle
import com.tom_roush.pdfbox.pdmodel.encryption.AccessPermission
import com.tom_roush.pdfbox.pdmodel.encryption.StandardProtectionPolicy
import com.tom_roush.pdfbox.pdmodel.font.PDType1Font
import com.tom_roush.pdfbox.pdmodel.graphics.image.LosslessFactory
import com.tom_roush.pdfbox.pdmodel.graphics.state.PDExtendedGraphicsState
import com.tom_roush.pdfbox.pdmodel.interactive.action.PDActionGoTo
import com.tom_roush.pdfbox.pdmodel.interactive.documentnavigation.destination.PDNamedDestination
import com.tom_roush.pdfbox.pdmodel.interactive.documentnavigation.destination.PDPageDestination
import com.tom_roush.pdfbox.pdmodel.interactive.documentnavigation.outline.PDOutlineItem
import com.tom_roush.pdfbox.text.PDFTextStripper
import com.tom_roush.pdfbox.text.TextPosition
import com.tom_roush.pdfbox.util.Matrix
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.currentCoroutineContext
import kotlinx.coroutines.ensureActive
import kotlinx.coroutines.withContext
import java.io.File
import kotlin.math.atan2
import kotlin.math.ceil
import kotlin.math.cos
import kotlin.math.max
import kotlin.math.min
import kotlin.math.sin

/** All PDFBox-based operations. Everything runs on Dispatchers.IO. */
object PdfEditor {
    private var inited = false

    fun init(context: Context) {
        if (!inited) {
            PDFBoxResourceLoader.init(context.applicationContext)
            inited = true
        }
    }

    private fun tempOnly() = MemoryUsageSetting.setupTempFileOnly()

    // ---------------------------------------------------------------- password

    /** Writes a copy of [src] with all security removed. Throws InvalidPasswordException on a wrong password. */
    suspend fun decrypt(context: Context, src: File, password: String, dst: File) = withContext(Dispatchers.IO) {
        init(context)
        PDDocument.load(src, password).use { doc ->
            doc.setAllSecurityToBeRemoved(true)
            doc.save(dst)
        }
    }

    // ---------------------------------------------------------------- page operations

    /**
     * Builds a new PDF from [plan] (reorder, delete, rotate, insert blank pages) by rearranging the pages of the
     * source document *in place*, so everything attached to the document rather than to a page survives: the
     * outline/bookmarks, form fields, metadata, named destinations and link targets.
     */
    suspend fun build(context: Context, src: File, plan: List<PageSpec>, dst: File) = withContext(Dispatchers.IO) {
        init(context)
        PDDocument.load(src, tempOnly()).use { doc ->
            val original = (0 until doc.numberOfPages).map { doc.getPage(it) }
            // Page size, rotation and resources may be inherited from the page tree; pin them to each page
            // before the tree is rebuilt, otherwise moved pages could lose them.
            original.forEach { p ->
                p.mediaBox = p.mediaBox
                p.cropBox = p.cropBox
                p.rotation = p.rotation
                p.resources?.let { p.resources = it }
            }
            for (i in original.indices.reversed()) doc.removePage(i)

            var lastBox: PDRectangle = original.firstOrNull()?.mediaBox ?: PDRectangle.A4
            plan.forEach { spec ->
                if (spec.src in original.indices) {
                    val p = original[spec.src]
                    if (spec.rotate != 0) p.rotation = ((p.rotation + spec.rotate) % 360 + 360) % 360
                    doc.addPage(p)
                    lastBox = p.mediaBox
                } else {
                    doc.addPage(PDPage(lastBox))
                }
            }
            doc.save(dst)
        }
    }

    suspend fun merge(context: Context, base: File, others: List<File>, dst: File) = withContext(Dispatchers.IO) {
        init(context)
        val merger = PDFMergerUtility()
        merger.addSource(base)
        others.forEach { merger.addSource(it) }
        merger.setDestinationFileName(dst.absolutePath)
        merger.mergeDocuments(tempOnly())
    }

    // ---------------------------------------------------------------- outline

    suspend fun outline(context: Context, file: File): List<OutlineEntry> = withContext(Dispatchers.IO) {
        init(context)
        runCatching {
            PDDocument.load(file, tempOnly()).use { doc ->
                val result = mutableListOf<OutlineEntry>()
                val root = doc.documentCatalog.documentOutline ?: return@use result

                fun pageOf(item: PDOutlineItem): Int {
                    val dest = item.destination ?: (item.action as? PDActionGoTo)?.destination
                    val pageDest: PDPageDestination? = when (dest) {
                        is PDPageDestination -> dest
                        is PDNamedDestination -> doc.documentCatalog.findNamedDestinationPage(dest)
                        else -> null
                    }
                    return pageDest?.retrievePageNumber() ?: -1
                }

                fun walk(first: PDOutlineItem?, level: Int) {
                    var cur = first
                    while (cur != null) {
                        val p = runCatching { pageOf(cur!!) }.getOrDefault(-1)
                        if (p >= 0) result += OutlineEntry(cur.title ?: "(untitled)", p, level)
                        walk(cur.firstChild, level + 1)
                        cur = cur.nextSibling
                    }
                }
                walk(root.firstChild, 0)
                result
            }
        }.getOrDefault(emptyList())
    }

    // ---------------------------------------------------------------- text, search

    /** Extracts one page (0-based) with the shared [stripper]. Pages without any text give [PageText.EMPTY]. */
    internal fun extractPage(doc: PDDocument, stripper: PageTextStripper, pageIndex: Int): PageText {
        stripper.result = null
        stripper.startPage = pageIndex + 1
        stripper.endPage = pageIndex + 1
        stripper.getText(doc)
        return stripper.result ?: PageText.EMPTY
    }

    /** Streams cumulative results through [onProgress] (called on the main thread) after each page with a match. */
    suspend fun search(
        context: Context,
        file: File,
        query: String,
        maxHits: Int = 500,
        onProgress: (List<SearchHit>) -> Unit,
    ) = withContext(Dispatchers.IO) {
        init(context)
        val q = query.trim().replace(Regex("\\s+"), " ")
        if (q.isEmpty()) return@withContext
        PDDocument.load(file, tempOnly()).use { doc ->
            val stripper = PageTextStripper()
            val acc = ArrayList<SearchHit>()
            for (p in 0 until doc.numberOfPages) {
                currentCoroutineContext().ensureActive()
                val found = extractPage(doc, stripper, p).find(q, p)
                if (found.isNotEmpty()) {
                    acc += found
                    val snapshot = acc.toList()
                    withContext(Dispatchers.Main) { onProgress(snapshot) }
                    if (acc.size >= maxHits) break
                }
            }
        }
    }

    // ---------------------------------------------------------------- flatten annotations into the PDF

    /** Bakes [annots] into a copy of [src]; with [password] the result is also encrypted. */
    suspend fun exportWithAnnotations(
        context: Context,
        src: File,
        annots: List<Annot>,
        dst: File,
        password: String? = null,
    ) = withContext(Dispatchers.IO) {
        init(context)
        PDDocument.load(src, tempOnly()).use { doc ->
            annots.groupBy { it.page }.forEach { (pageIndex, list) ->
                if (pageIndex !in 0 until doc.numberOfPages) return@forEach
                val page = doc.getPage(pageIndex)
                val geo = Geo(page)
                PDPageContentStream(doc, page, PDPageContentStream.AppendMode.APPEND, true, true).use { cs ->
                    list.forEach { drawAnnot(doc, cs, geo, it) }
                }
            }
            if (!password.isNullOrEmpty()) {
                val policy = StandardProtectionPolicy(password, password, AccessPermission())
                policy.encryptionKeyLength = 128
                doc.protect(policy)
            }
            doc.save(dst)
        }
    }

    private fun drawAnnot(doc: PDDocument, cs: PDPageContentStream, g: Geo, a: Annot) {
        val r = (a.color shr 16) and 0xFF
        val gr = (a.color shr 8) and 0xFF
        val b = a.color and 0xFF
        when (a.type) {
            AnnotType.INK, AnnotType.HIGHLIGHT -> {
                val first = a.points.firstOrNull() ?: return
                cs.saveGraphicsState()
                if (a.type == AnnotType.HIGHLIGHT) {
                    setAlpha(cs, 0.35f)
                    cs.setLineCapStyle(0)
                } else {
                    cs.setLineCapStyle(1)
                }
                cs.setLineJoinStyle(1)
                cs.setStrokingColor(r, gr, b)
                cs.setLineWidth(a.width * g.minSide)
                cs.moveTo(g.x(first), g.y(first))
                if (a.points.size == 1) {
                    cs.lineTo(g.x(first) + 0.01f, g.y(first))
                } else {
                    a.points.drop(1).forEach { cs.lineTo(g.x(it), g.y(it)) }
                }
                cs.stroke()
                cs.restoreGraphicsState()
            }
            AnnotType.TEXT -> drawText(doc, cs, g, a, r, gr, b)
            AnnotType.MARK_HIGHLIGHT, AnnotType.MARK_UNDERLINE, AnnotType.MARK_STRIKE -> drawMarkup(cs, g, a, r, gr, b)
            AnnotType.SHAPE_LINE, AnnotType.SHAPE_ARROW, AnnotType.SHAPE_RECT, AnnotType.SHAPE_OVAL ->
                drawShape(cs, g, a, r, gr, b)
        }
    }

    private fun setAlpha(cs: PDPageContentStream, alpha: Float) {
        val gs = PDExtendedGraphicsState()
        gs.setStrokingAlphaConstant(alpha)
        gs.setNonStrokingAlphaConstant(alpha)
        cs.setGraphicsStateParameters(gs)
    }

    private fun drawMarkup(cs: PDPageContentStream, g: Geo, a: Annot, r: Int, gr: Int, b: Int) {
        cs.saveGraphicsState()
        if (a.type == AnnotType.MARK_HIGHLIGHT) {
            setAlpha(cs, 0.35f)
            cs.setNonStrokingColor(r, gr, b)
        } else {
            cs.setStrokingColor(r, gr, b)
        }
        var i = 0
        while (i + 1 < a.points.size) {
            val p = a.points[i]
            val q = a.points[i + 1]
            i += 2
            val l = min(p.x, q.x)
            val rt = max(p.x, q.x)
            val t = min(p.y, q.y)
            val bt = max(p.y, q.y)
            when (a.type) {
                AnnotType.MARK_HIGHLIGHT -> {
                    val c1 = Pt(l, t)
                    val c2 = Pt(rt, t)
                    val c3 = Pt(rt, bt)
                    val c4 = Pt(l, bt)
                    cs.moveTo(g.x(c1), g.y(c1))
                    cs.lineTo(g.x(c2), g.y(c2))
                    cs.lineTo(g.x(c3), g.y(c3))
                    cs.lineTo(g.x(c4), g.y(c4))
                    cs.closePath()
                    cs.fill()
                }
                else -> {
                    val y = if (a.type == AnnotType.MARK_UNDERLINE) bt else (t + bt) / 2f
                    val u = Pt(l, y)
                    val v = Pt(rt, y)
                    cs.setLineWidth(max(0.6f, (bt - t) * g.dispH * 0.07f))
                    cs.moveTo(g.x(u), g.y(u))
                    cs.lineTo(g.x(v), g.y(v))
                    cs.stroke()
                }
            }
        }
        cs.restoreGraphicsState()
    }

    private fun drawShape(cs: PDPageContentStream, g: Geo, a: Annot, r: Int, gr: Int, b: Int) {
        if (a.points.size < 2) return
        val p = a.points[0]
        val q = a.points[1]
        val stroke = a.width * g.minSide
        cs.saveGraphicsState()
        cs.setStrokingColor(r, gr, b)
        cs.setLineWidth(stroke)
        cs.setLineCapStyle(1)
        cs.setLineJoinStyle(1)

        fun seg(u: Pt, v: Pt) {
            cs.moveTo(g.x(u), g.y(u))
            cs.lineTo(g.x(v), g.y(v))
            cs.stroke()
        }

        when (a.type) {
            AnnotType.SHAPE_LINE -> seg(p, q)
            AnnotType.SHAPE_ARROW -> {
                seg(p, q)
                val (h1, h2) = arrowHead(g, p, q, stroke)
                seg(q, h1)
                seg(q, h2)
            }
            AnnotType.SHAPE_RECT -> {
                val l = min(p.x, q.x)
                val rt = max(p.x, q.x)
                val t = min(p.y, q.y)
                val bt = max(p.y, q.y)
                val c = listOf(Pt(l, t), Pt(rt, t), Pt(rt, bt), Pt(l, bt))
                cs.moveTo(g.x(c[0]), g.y(c[0]))
                for (k in 1..3) cs.lineTo(g.x(c[k]), g.y(c[k]))
                cs.closePath()
                cs.stroke()
            }
            AnnotType.SHAPE_OVAL -> {
                val cx = (p.x + q.x) / 2f
                val cy = (p.y + q.y) / 2f
                val rx = kotlin.math.abs(q.x - p.x) / 2f
                val ry = kotlin.math.abs(q.y - p.y) / 2f
                val k = 0.5523f
                fun cv(c1: Pt, c2: Pt, e: Pt) =
                    cs.curveTo(g.x(c1), g.y(c1), g.x(c2), g.y(c2), g.x(e), g.y(e))
                val start = Pt(cx + rx, cy)
                cs.moveTo(g.x(start), g.y(start))
                cv(Pt(cx + rx, cy + k * ry), Pt(cx + k * rx, cy + ry), Pt(cx, cy + ry))
                cv(Pt(cx - k * rx, cy + ry), Pt(cx - rx, cy + k * ry), Pt(cx - rx, cy))
                cv(Pt(cx - rx, cy - k * ry), Pt(cx - k * rx, cy - ry), Pt(cx, cy - ry))
                cv(Pt(cx + k * rx, cy - ry), Pt(cx + rx, cy - k * ry), Pt(cx + rx, cy))
                cs.closePath()
                cs.stroke()
            }
            else -> Unit
        }
        cs.restoreGraphicsState()
    }

    /** Two end points of an arrow head at [q]; computed in displayed-page points so it matches the on-screen shape. */
    private fun arrowHead(g: Geo, p: Pt, q: Pt, strokePt: Float): Pair<Pt, Pt> {
        val px = p.x * g.dispW
        val py = p.y * g.dispH
        val qx = q.x * g.dispW
        val qy = q.y * g.dispH
        val ang = atan2(qy - py, qx - px)
        val len = max(strokePt * 4f, g.minSide * 0.03f)
        fun at(delta: Float) = Pt((qx - len * cos(ang + delta)) / g.dispW, (qy - len * sin(ang + delta)) / g.dispH)
        return at(0.5f) to at(-0.5f)
    }

    private fun drawText(doc: PDDocument, cs: PDPageContentStream, g: Geo, a: Annot, r: Int, gr: Int, b: Int) {
        val anchor = a.points.firstOrNull() ?: return
        if (a.text.isBlank()) return
        val size = a.width * g.minSide
        val simple = a.text.all { it == '\n' || it.code in 32..126 }
        if (simple) {
            // Real, selectable text for plain Latin text
            cs.setNonStrokingColor(r, gr, b)
            cs.beginText()
            cs.setFont(PDType1Font.HELVETICA, size)
            a.text.split("\n").forEachIndexed { i, line ->
                cs.setTextMatrix(g.place(anchor, size * 0.85f + i * size * 1.2f))
                cs.showText(line)
            }
            cs.endText()
        } else {
            // Any other script (Arabic, Devanagari, CJK…): shape with Android's text engine, embed as an image
            val scale = 3f
            val paint = TextPaint(Paint.ANTI_ALIAS_FLAG).apply {
                color = a.color
                textSize = size * scale
            }
            val wPx = ceil(Layout.getDesiredWidth(a.text, paint)).toInt().coerceAtLeast(1) + 2
            val layout = StaticLayout.Builder.obtain(a.text, 0, a.text.length, paint, wPx).build()
            val bmp = Bitmap.createBitmap(wPx, layout.height.coerceAtLeast(1), Bitmap.Config.ARGB_8888)
            layout.draw(Canvas(bmp))
            val img = LosslessFactory.createFromImage(doc, bmp)
            val wPt = wPx / scale
            val hPt = bmp.height / scale
            cs.saveGraphicsState()
            cs.transform(g.place(anchor, hPt))
            cs.drawImage(img, 0f, 0f, wPt, hPt)
            cs.restoreGraphicsState()
        }
    }
}

/**
 * Collects one page's text in logical order with a rectangle per character.
 *
 * PDFBox delivers text one *word* at a time, with the characters already re-ordered into logical order
 * (important for Arabic/Hebrew) but the glyph positions still in drawing order, so for right-to-left words the
 * position list is walked backwards. Word and line gaps are recorded as ' ' and '\n' so phrases can match across them.
 */
internal class PageTextStripper : PDFTextStripper() {
    var result: PageText? = null
    private val buf = StringBuilder()
    private val pos = ArrayList<TextPosition?>()

    override fun startPage(page: PDPage) {
        buf.setLength(0)
        pos.clear()
        super.startPage(page)
    }

    override fun writeString(text: String, textPositions: MutableList<TextPosition>) {
        if (text.isEmpty() || textPositions.isEmpty()) return
        val n = text.length
        val m = textPositions.size
        val rtl = text.any { PageText.isRtl(it) }
        for (k in 0 until n) {
            var pi = when {
                n == m -> k
                n == 1 -> 0
                else -> ((k.toLong() * (m - 1)) / (n - 1)).toInt()
            }
            if (rtl) pi = m - 1 - pi
            buf.append(text[k])
            pos.add(textPositions[pi.coerceIn(0, m - 1)])
        }
    }

    override fun writeWordSeparator() {
        buf.append(' ')
        pos.add(null)
    }

    override fun writeLineSeparator() {
        buf.append('\n')
        pos.add(null)
    }

    override fun endPage(page: PDPage) {
        super.endPage(page)
        if (buf.isEmpty()) return
        val box = page.cropBox
        val rot = ((page.rotation % 360) + 360) % 360
        val dw = if (rot == 90 || rot == 270) box.height else box.width
        val dh = if (rot == 90 || rot == 270) box.width else box.height
        val rects = pos.map { tp ->
            tp?.let {
                NRect(
                    (it.xDirAdj / dw).coerceIn(0f, 1f),
                    ((it.yDirAdj - it.heightDir) / dh).coerceIn(0f, 1f),
                    ((it.xDirAdj + it.widthDirAdj) / dw).coerceIn(0f, 1f),
                    ((it.yDirAdj + it.heightDir * 0.25f) / dh).coerceIn(0f, 1f),
                )
            }
        }
        result = PageText(buf.toString(), rects)
    }
}

/**
 * Maps normalised display coordinates (origin top-left, as seen by the reader) to PDF user space and back,
 * taking the page's /CropBox and /Rotate into account.
 */
internal class Geo(page: PDPage) {
    private val rot = ((page.rotation % 360) + 360) % 360
    private val box = page.cropBox
    private val w = box.width
    private val h = box.height
    val dispW = if (rot == 90 || rot == 270) h else w
    val dispH = if (rot == 90 || rot == 270) w else h
    val minSide = min(dispW, dispH)

    // [rightX, rightY, downX, downY] unit vectors of the displayed page axes in PDF space
    private val vec: FloatArray = when (rot) {
        90 -> floatArrayOf(0f, 1f, 1f, 0f)
        180 -> floatArrayOf(-1f, 0f, 0f, 1f)
        270 -> floatArrayOf(0f, -1f, -1f, 0f)
        else -> floatArrayOf(1f, 0f, 0f, -1f)
    }
    private val ox = when (rot) {
        90 -> box.lowerLeftX
        180 -> box.lowerLeftX + w
        270 -> box.lowerLeftX + w
        else -> box.lowerLeftX
    }
    private val oy = when (rot) {
        90 -> box.lowerLeftY
        180 -> box.lowerLeftY
        270 -> box.lowerLeftY + h
        else -> box.lowerLeftY + h
    }

    fun x(p: Pt) = ox + vec[0] * p.x * dispW + vec[2] * p.y * dispH
    fun y(p: Pt) = oy + vec[1] * p.x * dispW + vec[3] * p.y * dispH

    /** PDF user-space point -> normalised display point. */
    fun toNorm(px: Float, py: Float): Pt {
        val dx = px - ox
        val dy = py - oy
        return Pt((dx * vec[0] + dy * vec[1]) / dispW, (dx * vec[2] + dy * vec[3]) / dispH)
    }

    /** Matrix that puts upright content with its top-left at [anchor], origin moved [offDown] points down. */
    fun place(anchor: Pt, offDown: Float) = Matrix(
        vec[0], vec[1], -vec[2], -vec[3],
        x(anchor) + vec[2] * offDown, y(anchor) + vec[3] * offDown,
    )
}
