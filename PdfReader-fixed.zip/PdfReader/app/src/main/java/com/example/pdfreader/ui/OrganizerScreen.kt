package com.example.pdfreader.ui

import android.graphics.Bitmap
import androidx.activity.compose.BackHandler
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.foundation.BorderStroke
import androidx.compose.foundation.Image
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.aspectRatio
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.navigationBarsPadding
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.statusBarsPadding
import androidx.compose.foundation.lazy.grid.GridCells
import androidx.compose.foundation.lazy.grid.LazyVerticalGrid
import androidx.compose.foundation.lazy.grid.itemsIndexed
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.filled.ArrowBack
import androidx.compose.material.icons.automirrored.filled.ArrowForward
import androidx.compose.material.icons.filled.CallMerge
import androidx.compose.material.icons.filled.CheckCircle
import androidx.compose.material.icons.filled.ContentCut
import androidx.compose.material.icons.filled.Delete
import androidx.compose.material.icons.filled.NoteAdd
import androidx.compose.material.icons.filled.RotateRight
import androidx.compose.material3.Button
import androidx.compose.material3.HorizontalDivider
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableIntStateOf
import androidx.compose.runtime.mutableStateListOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.produceState
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.asImageBitmap
import androidx.compose.ui.graphics.graphicsLayer
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.unit.dp
import com.example.pdfreader.data.PageSpec

private class Item(val uid: Int, val spec: PageSpec)

/** Full-screen page manager: reorder, rotate, delete, insert blank pages, extract, and merge other PDFs. */
@Composable
fun OrganizerScreen(vm: AppViewModel, session: DocSession, onClose: () -> Unit) {
    val engine = session.engine
    var nextUid by remember { mutableIntStateOf(engine.pageCount) }
    val items = remember(engine) {
        mutableStateListOf<Item>().apply { addAll(List(engine.pageCount) { Item(it, PageSpec(it, 0)) }) }
    }
    val selected = remember(engine) { mutableStateListOf<Int>() } // uids

    val identity = items.size == engine.pageCount && items.withIndex().all { (i, it) -> it.spec.src == i && it.spec.rotate == 0 }

    BackHandler { onClose() }

    val extractLauncher = rememberLauncherForActivityResult(ActivityResultContracts.CreateDocument("application/pdf")) { uri ->
        if (uri != null) {
            val plan = items.filter { it.uid in selected && it.spec.src >= 0 }.map { it.spec }
            if (plan.isNotEmpty()) vm.extract(session, plan, uri)
        }
    }
    val mergeLauncher = rememberLauncherForActivityResult(ActivityResultContracts.OpenMultipleDocuments()) { uris ->
        if (uris.isNotEmpty()) {
            vm.merge(session, uris)
            onClose()
        }
    }

    fun mutateSelected(block: (Item) -> Item?) {
        val snapshot = items.toList()
        items.clear()
        snapshot.forEach { item -> if (item.uid in selected) block(item)?.let { items.add(it) } else items.add(item) }
        selected.retainAll(items.map { it.uid }.toSet())
    }

    fun move(delta: Int) {
        val list = items.toMutableList()
        val idxs = list.indices.filter { list[it].uid in selected }
        if (idxs.isEmpty()) return
        if (delta < 0 && idxs.first() == 0) return
        if (delta > 0 && idxs.last() == list.lastIndex) return
        val order = if (delta < 0) idxs else idxs.reversed()
        order.forEach { i ->
            val t = list[i]; list[i] = list[i + delta]; list[i + delta] = t
        }
        items.clear(); items.addAll(list)
    }

    Surface(Modifier.fillMaxSize(), color = MaterialTheme.colorScheme.background) {
        Column(Modifier.fillMaxSize().statusBarsPadding().navigationBarsPadding()) {
            Row(Modifier.fillMaxWidth().padding(horizontal = 4.dp), verticalAlignment = Alignment.CenterVertically) {
                IconButton(onClick = onClose) { Icon(Icons.AutoMirrored.Filled.ArrowBack, "Back") }
                Column(Modifier.weight(1f)) {
                    Text("Organize pages", style = MaterialTheme.typography.titleMedium)
                    Text(
                        if (selected.isEmpty()) "${items.size} pages · tap to select" else "${selected.size} selected",
                        style = MaterialTheme.typography.bodySmall,
                        color = MaterialTheme.colorScheme.onSurfaceVariant,
                    )
                }
                TextButton(onClick = { mergeLauncher.launch(arrayOf("application/pdf")) }) {
                    Icon(Icons.Default.CallMerge, null); Text("  Merge")
                }
                Button(
                    enabled = !identity && items.isNotEmpty(),
                    onClick = { vm.applyPlan(session, items.map { it.spec }); onClose() },
                    modifier = Modifier.padding(end = 8.dp),
                ) { Text("Apply") }
            }
            HorizontalDivider()

            LazyVerticalGrid(
                columns = GridCells.Adaptive(104.dp),
                modifier = Modifier.weight(1f),
                contentPadding = PaddingValues(12.dp),
                horizontalArrangement = Arrangement.spacedBy(10.dp),
                verticalArrangement = Arrangement.spacedBy(10.dp),
            ) {
                itemsIndexed(items, key = { _, it -> it.uid }) { pos, item ->
                    val isSel = item.uid in selected
                    Column(horizontalAlignment = Alignment.CenterHorizontally) {
                        Box(
                            Modifier
                                .fillMaxWidth()
                                .aspectRatio(0.72f)
                                .clip(RoundedCornerShape(8.dp))
                                .background(Color.White)
                                .clickable { if (isSel) selected.remove(item.uid) else selected.add(item.uid) }
                                .then(
                                    if (isSel) Modifier.border(BorderStroke(3.dp, MaterialTheme.colorScheme.primary), RoundedCornerShape(8.dp))
                                    else Modifier,
                                ),
                            contentAlignment = Alignment.Center,
                        ) {
                            if (item.spec.src >= 0) {
                                val bmp by produceState<Bitmap?>(engine.cached(item.spec.src, 240), engine, item.spec.src) {
                                    value = runCatching { engine.render(item.spec.src, 240) }.getOrNull() ?: value
                                }
                                bmp?.let {
                                    Image(
                                        it.asImageBitmap(), null,
                                        Modifier.fillMaxSize().padding(4.dp).graphicsLayer { rotationZ = item.spec.rotate.toFloat() },
                                        contentScale = ContentScale.Fit,
                                    )
                                }
                            } else {
                                Text("Blank", color = Color.Gray, style = MaterialTheme.typography.labelMedium)
                            }
                            if (isSel) {
                                Icon(
                                    Icons.Default.CheckCircle, null,
                                    Modifier.align(Alignment.TopEnd).padding(4.dp),
                                    tint = MaterialTheme.colorScheme.primary,
                                )
                            }
                        }
                        Text("${pos + 1}", style = MaterialTheme.typography.labelMedium, modifier = Modifier.padding(top = 4.dp))
                    }
                }
            }

            HorizontalDivider()
            val has = selected.isNotEmpty()
            Row(Modifier.fillMaxWidth().padding(horizontal = 4.dp, vertical = 4.dp), horizontalArrangement = Arrangement.SpaceEvenly) {
                IconButton(enabled = has, onClick = { move(-1) }) { Icon(Icons.AutoMirrored.Filled.ArrowBack, "Move earlier") }
                IconButton(enabled = has, onClick = { move(1) }) { Icon(Icons.AutoMirrored.Filled.ArrowForward, "Move later") }
                IconButton(
                    enabled = has,
                    onClick = { mutateSelected { Item(it.uid, PageSpec(it.spec.src, (it.spec.rotate + 90) % 360)) } },
                ) { Icon(Icons.Default.RotateRight, "Rotate") }
                IconButton(
                    onClick = {
                        // Insert a blank page after the last selected page, or at the end
                        val at = items.indexOfLast { it.uid in selected }.let { if (it < 0) items.size else it + 1 }
                        items.add(at, Item(nextUid++, PageSpec(-1, 0)))
                    },
                ) { Icon(Icons.Default.NoteAdd, "Insert blank page") }
                IconButton(
                    enabled = has && items.any { it.uid in selected && it.spec.src >= 0 },
                    onClick = { extractLauncher.launch(session.meta.name + " (extract).pdf") },
                ) { Icon(Icons.Default.ContentCut, "Extract selected pages") }
                IconButton(
                    enabled = has && selected.size < items.size,
                    onClick = { mutateSelected { null } },
                ) { Icon(Icons.Default.Delete, "Delete") }
            }
        }
    }
}
