package com.example.pdfreader.ui

import android.graphics.Bitmap
import androidx.compose.foundation.BorderStroke
import androidx.compose.foundation.Image
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.aspectRatio
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.lazy.grid.GridCells
import androidx.compose.foundation.lazy.grid.LazyVerticalGrid
import androidx.compose.foundation.lazy.grid.items
import androidx.compose.foundation.lazy.grid.rememberLazyGridState
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.text.KeyboardOptions
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Bookmark
import androidx.compose.material.icons.filled.CheckCircle
import androidx.compose.material.icons.filled.Download
import androidx.compose.material3.AlertDialog
import androidx.compose.material3.Button
import androidx.compose.material3.CircularProgressIndicator
import androidx.compose.material3.ExperimentalMaterial3Api
import androidx.compose.material3.Icon
import androidx.compose.material3.LinearProgressIndicator
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.ModalBottomSheet
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.RadioButton
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.produceState
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.asImageBitmap
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.input.KeyboardType
import androidx.compose.ui.text.input.PasswordVisualTransformation
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import com.example.pdfreader.ocr.OcrData
import com.example.pdfreader.pdf.PdfEngine
import kotlin.math.roundToInt

// ------------------------------------------------------------------ thumbnails

/** A grid of page previews for quick visual navigation. */
@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun PagesSheet(session: DocSession, onDismiss: () -> Unit) {
    val engine = session.engine
    val bookmarked = session.meta.bookmarks.map { it.page }.toSet()
    val gridState = rememberLazyGridState(initialFirstVisibleItemIndex = (session.currentPage - 3).coerceAtLeast(0))
    ModalBottomSheet(onDismissRequest = onDismiss) {
        Text("Pages", Modifier.padding(horizontal = 20.dp), style = MaterialTheme.typography.titleMedium)
        LazyVerticalGrid(
            columns = GridCells.Adaptive(104.dp),
            state = gridState,
            modifier = Modifier.fillMaxWidth().height(460.dp),
            contentPadding = PaddingValues(16.dp),
            horizontalArrangement = Arrangement.spacedBy(10.dp),
            verticalArrangement = Arrangement.spacedBy(10.dp),
        ) {
            items(count = engine.pageCount, key = { it }) { i ->
                val current = i == session.currentPage
                Column(horizontalAlignment = Alignment.CenterHorizontally) {
                    Box(
                        Modifier
                            .fillMaxWidth()
                            .aspectRatio(1f / (engine.sizeOf(i)?.aspect ?: 1.4f))
                            .clip(RoundedCornerShape(6.dp))
                            .background(Color.White)
                            .then(
                                if (current) Modifier.border(BorderStroke(3.dp, MaterialTheme.colorScheme.primary), RoundedCornerShape(6.dp)) else Modifier,
                            )
                            .clickable {
                                session.jump(i)
                                onDismiss()
                            },
                    ) {
                        val thumb by produceState<Bitmap?>(engine.cached(i, PdfEngine.THUMB_WIDTH), engine, i) {
                            if (value == null) value = runCatching { engine.render(i, PdfEngine.THUMB_WIDTH) }.getOrNull()
                        }
                        thumb?.let {
                            Image(it.asImageBitmap(), "Page ${i + 1}", Modifier.fillMaxSize(), contentScale = ContentScale.Fit)
                        }
                        if (i in bookmarked) {
                            Icon(
                                Icons.Default.Bookmark,
                                "Bookmarked",
                                Modifier.align(Alignment.TopEnd).size(20.dp),
                                tint = MaterialTheme.colorScheme.primary,
                            )
                        }
                    }
                    Text(
                        "${i + 1}",
                        Modifier.padding(top = 4.dp),
                        style = MaterialTheme.typography.labelMedium,
                        color = if (current) MaterialTheme.colorScheme.primary else MaterialTheme.colorScheme.onSurfaceVariant,
                    )
                }
            }
        }
    }
}

// ------------------------------------------------------------------ OCR

/**
 * Text recognition for scanned pages. Language data (a few MB each) is downloaded once; recognition then runs on
 * the device. Results are used for search, selection and copy; they are not written back into the PDF.
 */
@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun OcrSheet(vm: AppViewModel, session: DocSession, onDismiss: () -> Unit) {
    val context = LocalContext.current
    var chosen by remember { mutableStateOf(session.meta.ocrLang ?: "eng") }
    vm.ocrDataVersion // re-read availability after a download finishes
    val state = session.ocrState
    val running = state != null
    val ready = OcrData.has(context, chosen)

    ModalBottomSheet(onDismissRequest = onDismiss) {
        Column(
            Modifier.padding(horizontal = 20.dp).verticalScroll(rememberScrollState()),
            verticalArrangement = Arrangement.spacedBy(8.dp),
        ) {
            Text("Recognize text (OCR)", style = MaterialTheme.typography.titleMedium)
            Text(
                "Makes scanned pages searchable and selectable. Pages that already contain text are skipped. " +
                    "Language data is downloaded once (about 1–15 MB each); recognition runs on this device.",
                style = MaterialTheme.typography.bodySmall,
                color = MaterialTheme.colorScheme.onSurfaceVariant,
            )
            val recognised = session.ocr.size
            if (recognised > 0) {
                Text("$recognised page(s) recognised in this document.", style = MaterialTheme.typography.bodyMedium)
            }

            OcrData.languages.forEach { lang ->
                val have = OcrData.has(context, lang.code)
                val progress = vm.ocrDownloads[lang.code]
                Row(
                    Modifier
                        .fillMaxWidth()
                        .clickable(enabled = !running) { chosen = lang.code },
                    verticalAlignment = Alignment.CenterVertically,
                ) {
                    RadioButton(selected = chosen == lang.code, onClick = { chosen = lang.code }, enabled = !running)
                    Text(lang.label, Modifier.weight(1f))
                    when {
                        progress != null -> {
                            CircularProgressIndicator(progress = { progress }, modifier = Modifier.size(22.dp), strokeWidth = 2.dp)
                            Spacer(Modifier.size(12.dp))
                        }
                        have -> {
                            Icon(Icons.Default.CheckCircle, "Downloaded", tint = MaterialTheme.colorScheme.primary)
                            Spacer(Modifier.size(12.dp))
                        }
                        else -> TextButton(onClick = { vm.downloadOcrLang(lang.code) }) {
                            Icon(Icons.Default.Download, null, Modifier.size(18.dp))
                            Text("  Download")
                        }
                    }
                }
            }
            vm.ocrError?.let {
                Text(it, color = MaterialTheme.colorScheme.error, style = MaterialTheme.typography.bodySmall)
            }

            if (state != null) {
                Text("Page ${state.done} of ${state.total}…", style = MaterialTheme.typography.bodyMedium)
                LinearProgressIndicator(
                    progress = { if (state.total == 0) 0f else state.done / state.total.toFloat() },
                    modifier = Modifier.fillMaxWidth(),
                )
                OutlinedButton(onClick = { session.cancelOcr() }) { Text("Stop") }
            } else {
                session.ocrMessage?.let { Text(it, style = MaterialTheme.typography.bodyMedium) }
                Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                    Button(onClick = { session.startOcr(chosen) }, enabled = ready) {
                        Text(if (ready) "Recognize all pages" else "Download the language first")
                    }
                    if (recognised > 0) {
                        OutlinedButton(onClick = { session.clearOcr() }) { Text("Clear results") }
                    }
                }
            }
            Spacer(Modifier.size(24.dp))
        }
    }
}

// ------------------------------------------------------------------ properties / password

@Composable
fun PropertiesDialog(session: DocSession, onDismiss: () -> Unit) {
    val size = session.engine.sizeOf(0)
    val rows = buildList {
        add("Name" to session.meta.name)
        add("File size" to formatSize(session.meta.sizeBytes))
        add("Pages" to session.engine.pageCount.toString())
        if (size != null) {
            // PDF points → millimetres
            add("Page size" to "${(size.width / 72f * 25.4f).roundToInt()} × ${(size.height / 72f * 25.4f).roundToInt()} mm")
        }
        add("Bookmarks" to session.meta.bookmarks.size.toString())
        add("Annotations" to session.annots.size.toString())
        if (session.ocr.isNotEmpty()) add("OCR pages" to session.ocr.size.toString())
        add("Last opened" to relativeTime(session.meta.lastOpened))
    }
    AlertDialog(
        onDismissRequest = onDismiss,
        confirmButton = { TextButton(onClick = onDismiss) { Text("Close") } },
        title = { Text("Properties") },
        text = {
            Column(verticalArrangement = Arrangement.spacedBy(8.dp)) {
                rows.forEach { (k, v) ->
                    Row {
                        Text(k, Modifier.weight(0.4f), color = MaterialTheme.colorScheme.onSurfaceVariant)
                        Text(v, Modifier.weight(0.6f), maxLines = 2, overflow = TextOverflow.Ellipsis)
                    }
                }
            }
        },
    )
}

/** Asks for a password (twice) before saving an encrypted copy. */
@Composable
fun SavePasswordDialog(onConfirm: (String) -> Unit, onDismiss: () -> Unit) {
    var pw by remember { mutableStateOf("") }
    var again by remember { mutableStateOf("") }
    val tooShort = pw.length < 4
    val mismatch = pw != again
    AlertDialog(
        onDismissRequest = onDismiss,
        title = { Text("Save with password") },
        text = {
            Column(verticalArrangement = Arrangement.spacedBy(8.dp)) {
                Text(
                    "The saved copy will need this password to open. There is no way to recover it if you forget it.",
                    style = MaterialTheme.typography.bodySmall,
                )
                OutlinedTextField(
                    value = pw,
                    onValueChange = { pw = it },
                    label = { Text("Password") },
                    singleLine = true,
                    visualTransformation = PasswordVisualTransformation(),
                    keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Password),
                )
                OutlinedTextField(
                    value = again,
                    onValueChange = { again = it },
                    label = { Text("Repeat password") },
                    singleLine = true,
                    isError = again.isNotEmpty() && mismatch,
                    visualTransformation = PasswordVisualTransformation(),
                    keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Password),
                )
            }
        },
        confirmButton = {
            TextButton(onClick = { onConfirm(pw) }, enabled = !tooShort && !mismatch) { Text("Choose location") }
        },
        dismissButton = { TextButton(onClick = onDismiss) { Text("Cancel") } },
    )
}
