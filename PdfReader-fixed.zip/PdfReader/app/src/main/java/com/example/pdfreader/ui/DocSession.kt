package com.example.pdfreader.ui

import android.content.Context
import androidx.compose.runtime.Stable
import androidx.compose.runtime.derivedStateOf
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableFloatStateOf
import androidx.compose.runtime.mutableIntStateOf
import androidx.compose.runtime.mutableStateMapOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.setValue
import com.example.pdfreader.data.Annot
import com.example.pdfreader.data.AnnotType
import com.example.pdfreader.data.Bookmark
import com.example.pdfreader.data.ColorMode
import com.example.pdfreader.data.DocMeta
import com.example.pdfreader.data.NRect
import com.example.pdfreader.data.OcrState
import com.example.pdfreader.data.OcrWord
import com.example.pdfreader.data.OutlineEntry
import com.example.pdfreader.data.PageLink
import com.example.pdfreader.data.PageSpec
import com.example.pdfreader.data.Pt
import com.example.pdfreader.data.SearchHit
import com.example.pdfreader.data.Store
import com.example.pdfreader.data.TextSelection
import com.example.pdfreader.data.ViewMode
import com.example.pdfreader.ocr.OcrData
import com.example.pdfreader.ocr.OcrRecognizer
import com.example.pdfreader.pdf.PageText
import com.example.pdfreader.pdf.PdfEditor
import com.example.pdfreader.pdf.PdfEngine
import com.example.pdfreader.pdf.PdfIndex
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.Job
import kotlinx.coroutines.NonCancellable
import kotlinx.coroutines.delay
import kotlinx.coroutines.ensureActive
import kotlinx.coroutines.flow.MutableSharedFlow
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext
import java.io.File
import java.util.UUID
import kotlin.coroutines.cancellation.CancellationException
import kotlin.math.max
import kotlin.math.min

enum class Tool { NONE, PEN, HIGHLIGHT, TEXT, ERASER, LINE, ARROW, RECT, OVAL }

val Tool.isShape: Boolean get() = this == Tool.LINE || this == Tool.ARROW || this == Tool.RECT || this == Tool.OVAL

data class TextEdit(val page: Int, val at: Pt, val existing: Annot?)

private const val OCR_WIDTH = 2000

/** Everything about one open document (= one tab). */
@Stable
class DocSession(
    initialMeta: DocMeta,
    initialEngine: PdfEngine,
    initialAnnots: List<Annot>,
    initialOcr: Map<Int, List<OcrWord>>,
    private val appContext: Context,
    private val store: Store,
    private val scope: CoroutineScope,
) {
    var meta by mutableStateOf(initialMeta); private set
    var engine by mutableStateOf(initialEngine); private set
    var annots by mutableStateOf(initialAnnots); private set

    val id: String get() = meta.id
    val annotsByPage: Map<Int, List<Annot>> by derivedStateOf { annots.groupBy { it.page } }

    val zoom = ZoomState()

    // ------------------------------------------------------------ navigation
    var currentPage by mutableIntStateOf(initialMeta.lastPage.coerceIn(0, (initialEngine.pageCount - 1).coerceAtLeast(0)))
        private set
    val jumps = MutableSharedFlow<Int>(extraBufferCapacity = 8)

    fun jump(page: Int) {
        val p = page.coerceIn(0, engine.pageCount - 1)
        currentPage = p
        jumps.tryEmit(p)
        scheduleSave()
    }

    fun stepPage(delta: Int) = jump(currentPage + delta)

    fun onPageChanged(page: Int) {
        if (page != currentPage && page in 0 until engine.pageCount) {
            currentPage = page
            meta = meta.copy(lastPage = page)
            scheduleSave()
        }
    }

    /** Set when a link was followed, so the reader can offer a way back to where it was. */
    var returnPage by mutableStateOf<Int?>(null); private set

    fun followLink(page: Int) {
        returnPage = currentPage
        jump(page)
    }

    fun goBackFromLink() {
        returnPage?.let { jump(it) }
        returnPage = null
    }

    fun dismissReturn() {
        returnPage = null
    }

    // ------------------------------------------------------------ auto-scroll
    var autoScroll by mutableStateOf(false)
    var autoSpeed by mutableFloatStateOf(0.35f)

    // ------------------------------------------------------------ view preferences
    fun setViewMode(mode: ViewMode) {
        meta = meta.copy(viewMode = mode, lastPage = currentPage)
        zoom.reset()
        scheduleSave()
    }

    fun rename(name: String) {
        meta = meta.copy(name = name)
        scheduleSave()
    }

    fun setFavorite(value: Boolean) {
        meta = meta.copy(favorite = value)
        scheduleSave()
    }

    fun setColorMode(mode: ColorMode) {
        meta = meta.copy(colorMode = mode)
        scheduleSave()
    }

    // ------------------------------------------------------------ bookmarks
    val isBookmarked: Boolean get() = meta.bookmarks.any { it.page == currentPage }

    fun toggleBookmark() {
        val existing = meta.bookmarks.firstOrNull { it.page == currentPage }
        meta = if (existing != null) {
            meta.copy(bookmarks = meta.bookmarks - existing)
        } else {
            meta.copy(
                bookmarks = (meta.bookmarks + Bookmark(currentPage, "Page ${currentPage + 1}", System.currentTimeMillis()))
                    .sortedBy { it.page },
            )
        }
        scheduleSave()
    }

    fun removeBookmark(b: Bookmark) {
        meta = meta.copy(bookmarks = meta.bookmarks - b)
        scheduleSave()
    }

    // ------------------------------------------------------------ annotation tools
    var tool by mutableStateOf(Tool.NONE)
    var penColor by mutableIntStateOf(0xFF1E88E5.toInt())
    var highlightColor by mutableIntStateOf(0xFFFFEB3B.toInt())
    var penWidth by mutableFloatStateOf(0.004f)
    var textEdit by mutableStateOf<TextEdit?>(null)

    private val undoStack = ArrayDeque<List<Annot>>()
    private val redoStack = ArrayDeque<List<Annot>>()
    var canUndo by mutableStateOf(false); private set
    var canRedo by mutableStateOf(false); private set

    private fun refreshUndo() {
        canUndo = undoStack.isNotEmpty()
        canRedo = redoStack.isNotEmpty()
    }

    private fun commit(newList: List<Annot>) {
        undoStack.addLast(annots)
        if (undoStack.size > 100) undoStack.removeFirst()
        redoStack.clear()
        annots = newList
        refreshUndo()
        scheduleSave()
    }

    fun addAnnot(a: Annot) = commit(annots + a)

    fun replaceAnnot(a: Annot) = commit(annots.map { if (it.id == a.id) a else it })

    fun removeAnnots(ids: Set<String>) = commit(annots.filterNot { it.id in ids })

    fun undo() {
        val prev = undoStack.removeLastOrNull() ?: return
        redoStack.addLast(annots)
        annots = prev
        refreshUndo()
        scheduleSave()
    }

    fun redo() {
        val next = redoStack.removeLastOrNull() ?: return
        undoStack.addLast(annots)
        annots = next
        refreshUndo()
        scheduleSave()
    }

    // ------------------------------------------------------------ text, selection, links
    private var index = PdfIndex(appContext, store.pdf(initialMeta.id))
    private val texts = mutableStateMapOf<Int, PageText>()
    val links = mutableStateMapOf<Int, List<PageLink>>()

    fun textOf(page: Int): PageText? = texts[page]

    /** The page's text: the PDF's own text layer, or the OCR result for scanned pages. */
    private suspend fun loadText(page: Int): PageText {
        texts[page]?.let { return it }
        val idx = index
        val own = idx.text(page)
        val pt = if (!own.isBlank) own else ocr[page]?.let { PageText.fromWords(it) } ?: own
        if (idx === index) texts[page] = pt
        return pt
    }

    suspend fun ensureLinks(page: Int) {
        if (links.containsKey(page)) return
        val idx = index
        val l = idx.links(page)
        if (idx === index) links[page] = l
    }

    var selection by mutableStateOf<TextSelection?>(null); private set

    fun beginSelection(page: Int, nx: Float, ny: Float) {
        scope.launch {
            val pt = loadText(page)
            val aspect = engine.sizeOf(page)?.aspect ?: 1.4f
            val i = pt.indexAt(nx, ny, aspect)
            if (i < 0) return@launch
            val r = pt.wordRange(i)
            selection = TextSelection(page, r.first, r.last)
        }
    }

    /** Drag one end of the selection to the character nearest (nx, ny). */
    fun moveSelection(isStart: Boolean, nx: Float, ny: Float) {
        val s = selection ?: return
        val pt = texts[s.page] ?: return
        val aspect = engine.sizeOf(s.page)?.aspect ?: 1.4f
        val i = pt.indexAt(nx, ny, aspect)
        if (i < 0) return
        selection = if (isStart) s.copy(start = min(i, s.end)) else s.copy(end = max(i, s.start))
    }

    fun clearSelection() {
        selection = null
    }

    fun selectedText(): String? {
        val s = selection ?: return null
        return texts[s.page]?.textFor(s.start, s.end)
    }

    /** Turns the selection into an editable text-markup annotation. */
    fun markSelection(type: AnnotType) {
        val s = selection ?: return
        val rects: List<NRect> = texts[s.page]?.rectsFor(s.start, s.end).orEmpty()
        if (rects.isEmpty()) return
        addAnnot(
            Annot(
                id = UUID.randomUUID().toString(),
                page = s.page,
                type = type,
                color = if (type == AnnotType.MARK_HIGHLIGHT) highlightColor else penColor,
                width = 0f,
                points = rects.flatMap { listOf(Pt(it.l, it.t), Pt(it.r, it.b)) },
            ),
        )
        selection = null
    }

    // ------------------------------------------------------------ OCR
    var ocr by mutableStateOf(initialOcr); private set
    var ocrState by mutableStateOf<OcrState?>(null); private set
    var ocrMessage by mutableStateOf<String?>(null); private set
    private var ocrJob: Job? = null

    /** Recognises every page that has no text layer of its own. Results are kept and used by search and selection. */
    fun startOcr(language: String) {
        if (ocrJob?.isActive == true) return
        ocrMessage = null
        val spec = if (language != "eng" && OcrData.has(appContext, "eng")) "$language+eng" else language
        ocrJob = scope.launch {
            val total = engine.pageCount
            ocrState = OcrState(0, total, language)
            var recognizer: OcrRecognizer? = null
            try {
                val rec = withContext(Dispatchers.Default) { OcrRecognizer.create(appContext, spec) }
                recognizer = rec
                val result = HashMap(ocr)
                var added = 0
                for (p in 0 until total) {
                    ensureActive()
                    ocrState = OcrState(p, total, language)
                    if (result.containsKey(p)) continue
                    if (!index.text(p).isBlank) continue
                    val bmp = engine.renderUncached(p, OCR_WIDTH)
                    val words = try {
                        withContext(Dispatchers.Default) { rec.recognize(bmp) }
                    } finally {
                        bmp.recycle()
                    }
                    result[p] = words
                    added++
                    ocr = HashMap(result)
                    texts.remove(p)
                }
                ocrMessage = if (added == 0) "Nothing to recognise: every page already has text." else "Recognised $added page(s)."
            } catch (e: CancellationException) {
                ocrMessage = "Stopped."
                throw e
            } catch (t: Throwable) {
                ocrMessage = t.message ?: "OCR failed."
            } finally {
                recognizer?.close()
                withContext(NonCancellable + Dispatchers.IO) {
                    store.saveOcr(id, ocr)
                }
                meta = meta.copy(ocrLang = language)
                scheduleSave()
                ocrState = null
            }
        }
    }

    fun cancelOcr() {
        ocrJob?.cancel()
    }

    fun clearOcr() {
        ocrJob?.cancel()
        ocr = emptyMap()
        texts.clear()
        scope.launch(Dispatchers.IO) { store.saveOcr(id, emptyMap()) }
    }

    // ------------------------------------------------------------ persistence
    private var saveJob: Job? = null

    private fun scheduleSave() {
        saveJob?.cancel()
        saveJob = scope.launch {
            delay(600)
            val m = meta
            val a = annots
            withContext(Dispatchers.IO) {
                store.saveMeta(m)
                store.saveAnnots(m.id, a)
            }
        }
    }

    /** Synchronous save; used when leaving the document or the app. */
    fun flush() {
        saveJob?.cancel()
        runCatching {
            store.saveMeta(meta.copy(lastPage = currentPage))
            store.saveAnnots(id, annots)
        }
    }

    fun close() {
        searchJob?.cancel()
        ocrJob?.cancel()
        flush()
        val e = engine
        val ix = index
        scope.launch {
            e.close()
            ix.close()
        }
    }

    // ------------------------------------------------------------ outline
    var outline by mutableStateOf<List<OutlineEntry>?>(null); private set

    suspend fun ensureOutline(context: Context) {
        if (outline == null) outline = PdfEditor.outline(context, store.pdf(id))
    }

    // ------------------------------------------------------------ search
    var searchQuery by mutableStateOf("")
    var searchHits by mutableStateOf<List<SearchHit>>(emptyList()); private set
    var searchIndex by mutableIntStateOf(-1); private set
    var searching by mutableStateOf(false); private set
    private var searchJob: Job? = null

    fun search(context: Context, query: String) {
        searchJob?.cancel()
        searchQuery = query
        searchHits = emptyList()
        searchIndex = -1
        val q = query.trim()
        if (q.isEmpty()) {
            searching = false
            return
        }
        searching = true
        searchJob = scope.launch {
            var pdfHits: List<SearchHit> = emptyList()
            try {
                PdfEditor.search(context, store.pdf(id), q) { hits ->
                    pdfHits = hits
                    searchHits = hits
                    if (searchIndex < 0 && hits.isNotEmpty()) searchIndex = 0
                }
                // Scanned pages have no text layer, so search the OCR results as well
                val normalized = q.replace(Regex("\\s+"), " ")
                val ocrHits = withContext(Dispatchers.Default) {
                    ocr.entries.sortedBy { it.key }.flatMap { (p, words) -> PageText.fromWords(words).find(normalized, p) }
                }
                if (ocrHits.isNotEmpty()) {
                    searchHits = (pdfHits + ocrHits).sortedBy { it.page }
                    if (searchIndex < 0) searchIndex = 0
                }
            } catch (e: CancellationException) {
                throw e
            } catch (_: Throwable) {
                // text extraction can fail on damaged files; keep what we have
            } finally {
                searching = false
            }
        }
    }

    fun clearSearch() {
        searchJob?.cancel()
        searchQuery = ""
        searchHits = emptyList()
        searchIndex = -1
        searching = false
    }

    fun gotoHit(i: Int) {
        if (searchHits.isEmpty()) return
        val n = ((i % searchHits.size) + searchHits.size) % searchHits.size
        searchIndex = n
        jump(searchHits[n].page)
    }

    // ------------------------------------------------------------ page operations
    private fun replaceFile(tmp: File) {
        val dst = store.pdf(id)
        if (!tmp.renameTo(dst)) {
            tmp.copyTo(dst, overwrite = true)
            tmp.delete()
        }
        meta = meta.copy(sizeBytes = dst.length())
    }

    private suspend fun reopenEngine() {
        val old = engine
        val oldIndex = index
        engine = PdfEngine.open(store.pdf(id))
        index = PdfIndex(appContext, store.pdf(id))
        texts.clear()
        links.clear()
        selection = null
        scope.launch {
            old.close()
            oldIndex.close()
        }
        outline = null
        clearSearch()
    }

    /** Applies reorder / delete / rotate / blank-insert in one go and remaps annotations, OCR and bookmarks. */
    suspend fun applyPlan(context: Context, plan: List<PageSpec>) {
        require(plan.isNotEmpty()) { "A document needs at least one page" }
        val tmp = File(store.dir(id), "edit.tmp")
        PdfEditor.build(context, store.pdf(id), plan, tmp)
        replaceFile(tmp)

        val newIndexOf = HashMap<Int, Int>()
        val rotationOf = HashMap<Int, Int>()
        plan.forEachIndexed { i, s ->
            if (s.src >= 0) {
                newIndexOf[s.src] = i
                rotationOf[s.src] = s.rotate
            }
        }
        annots = annots.mapNotNull { a ->
            val n = newIndexOf[a.page] ?: return@mapNotNull null
            val rot = rotationOf[a.page] ?: 0
            a.copy(page = n, points = a.points.map { rotatePt(it, rot) })
        }
        // Recognised text is dropped for rotated pages (its boxes would no longer line up); it can simply be re-run
        val remappedOcr = HashMap<Int, List<OcrWord>>()
        ocr.forEach { (old, words) ->
            val n = newIndexOf[old]
            if (n != null && (rotationOf[old] ?: 0) == 0) remappedOcr[n] = words
        }
        ocr = remappedOcr
        withContext(Dispatchers.IO) { store.saveOcr(id, remappedOcr) }

        val bookmarks = meta.bookmarks.mapNotNull { b -> newIndexOf[b.page]?.let { b.copy(page = it) } }
            .sortedBy { it.page }

        reopenEngine()
        undoStack.clear()
        redoStack.clear()
        refreshUndo()
        meta = meta.copy(bookmarks = bookmarks, pageCount = engine.pageCount)
        currentPage = currentPage.coerceIn(0, engine.pageCount - 1)
        zoom.reset()
        scheduleSave()
    }

    suspend fun merge(context: Context, others: List<File>) {
        val tmp = File(store.dir(id), "merge.tmp")
        PdfEditor.merge(context, store.pdf(id), others, tmp)
        replaceFile(tmp)
        reopenEngine()
        meta = meta.copy(pageCount = engine.pageCount)
        scheduleSave()
    }

    /** Writes the PDF (with annotations baked in, and encrypted when [password] is given) to [dst]. */
    suspend fun exportTo(context: Context, dst: File, password: String? = null) {
        withContext(Dispatchers.IO) {
            if (annots.isEmpty() && password.isNullOrEmpty()) {
                store.pdf(id).copyTo(dst, overwrite = true)
            } else {
                PdfEditor.exportWithAnnotations(context, store.pdf(id), annots, dst, password)
            }
        }
    }

    private fun rotatePt(p: Pt, clockwiseDegrees: Int): Pt = when (((clockwiseDegrees % 360) + 360) % 360) {
        90 -> Pt(1f - p.y, p.x)
        180 -> Pt(1f - p.x, 1f - p.y)
        270 -> Pt(p.y, 1f - p.x)
        else -> p
    }
}
