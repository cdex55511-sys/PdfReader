package com.example.pdfreader.data

import kotlinx.serialization.Serializable

@Serializable
data class Bookmark(val page: Int, val title: String, val createdAt: Long)

@Serializable
enum class ViewMode(val label: String) {
    CONTINUOUS("Continuous scroll"),
    PAGED_HORIZONTAL("Page by page (swipe sideways)"),
    PAGED_VERTICAL("Page by page (swipe up/down)"),
}

@Serializable
enum class ColorMode(val label: String) {
    DAY("Day"),
    NIGHT("Night"),
    SEPIA("Sepia"),
    WARM("Warm"),
    GRAY("Grayscale"),
}

/** Persisted per-document state. The working copy of the PDF lives next to it in the library folder. */
@Serializable
data class DocMeta(
    val id: String,
    val name: String,
    val sizeBytes: Long,
    val pageCount: Int = 0,
    val lastOpened: Long,
    val lastPage: Int = 0,
    val favorite: Boolean = false,
    val viewMode: ViewMode = ViewMode.CONTINUOUS,
    val colorMode: ColorMode = ColorMode.DAY,
    val bookmarks: List<Bookmark> = emptyList(),
    val ocrLang: String? = null,
)

@Serializable
enum class AnnotType {
    INK, HIGHLIGHT, TEXT,

    /** Text markup made from a selection; [Annot.points] holds (top-left, bottom-right) pairs, one pair per line. */
    MARK_HIGHLIGHT, MARK_UNDERLINE, MARK_STRIKE,

    /** Shapes; [Annot.points] holds the two corner / end points. */
    SHAPE_LINE, SHAPE_ARROW, SHAPE_RECT, SHAPE_OVAL,
}

/** Point normalised to the displayed page: x, y in 0..1, origin top-left. */
@Serializable
data class Pt(val x: Float, val y: Float)

/**
 * An annotation stored as an editable overlay (not yet baked into the PDF).
 * [width] is a fraction of the page's shorter side (stroke width, or font size for TEXT),
 * which keeps it stable when a page is rotated.
 */
@Serializable
data class Annot(
    val id: String,
    val page: Int,
    val type: AnnotType,
    val color: Int,
    val width: Float,
    val points: List<Pt>,
    val text: String = "",
)

data class OutlineEntry(val title: String, val page: Int, val level: Int)

data class NRect(val l: Float, val t: Float, val r: Float, val b: Float)

data class SearchHit(val page: Int, val snippet: String, val rects: List<NRect>)

/** One page of a rebuilt document. [src] = index in the current file, or -1 for a new blank page. */
data class PageSpec(val src: Int, val rotate: Int)

/** A tappable link on a page: [page] >= 0 is an internal jump, otherwise [uri] is external. */
data class PageLink(val rect: NRect, val page: Int, val uri: String?)

/** One recognised word. Coordinates are fractions of the page (0..1, origin top-left). */
@Serializable
data class OcrWord(val t: String, val l: Float, val top: Float, val r: Float, val b: Float)

/** Inclusive character range selected on [page] (indices into that page's PageText). */
data class TextSelection(val page: Int, val start: Int, val end: Int)

data class OcrState(val done: Int, val total: Int, val language: String)
