package com.example.pdfreader.ui

import android.content.Context
import android.content.Intent
import android.graphics.Bitmap
import android.net.Uri
import android.widget.Toast
import androidx.compose.foundation.Canvas
import androidx.compose.foundation.Image
import androidx.compose.foundation.background
import androidx.compose.foundation.gestures.awaitEachGesture
import androidx.compose.foundation.gestures.awaitFirstDown
import androidx.compose.foundation.gestures.awaitLongPressOrCancellation
import androidx.compose.foundation.gestures.detectTapGestures
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.size
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateListOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.rememberUpdatedState
import androidx.compose.runtime.setValue
import androidx.compose.ui.Modifier
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.geometry.Size
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.ColorFilter
import androidx.compose.ui.graphics.ColorMatrix
import androidx.compose.ui.graphics.FilterQuality
import androidx.compose.ui.graphics.Path
import androidx.compose.ui.graphics.StrokeCap
import androidx.compose.ui.graphics.StrokeJoin
import androidx.compose.ui.graphics.asImageBitmap
import androidx.compose.ui.graphics.drawscope.DrawScope
import androidx.compose.ui.graphics.drawscope.Stroke
import androidx.compose.ui.input.pointer.pointerInput
import androidx.compose.ui.input.pointer.positionChanged
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.platform.LocalDensity
import androidx.compose.ui.text.TextMeasurer
import androidx.compose.ui.text.TextStyle
import androidx.compose.ui.text.drawText
import androidx.compose.ui.text.rememberTextMeasurer
import androidx.compose.ui.unit.dp
import com.example.pdfreader.data.Annot
import com.example.pdfreader.data.AnnotType
import com.example.pdfreader.data.ColorMode
import com.example.pdfreader.data.Pt
import com.example.pdfreader.pdf.PdfEngine
import java.util.UUID
import kotlin.coroutines.cancellation.CancellationException
import kotlin.math.abs
import kotlin.math.atan2
import kotlin.math.ceil
import kotlin.math.cos
import kotlin.math.hypot
import kotlin.math.max
import kotlin.math.min
import kotlin.math.sin
import kotlin.math.sqrt

private const val MAX_PIXELS = 12_000_000f
const val HIGHLIGHT_WIDTH = 0.032f
private val SelectionColor = Color(0xFF3D7BFF)

// ------------------------------------------------------------------ reading modes

fun colorFilterFor(mode: ColorMode): ColorFilter? = when (mode) {
    ColorMode.DAY -> null
    // inverted, slightly softened so pure white/black don't glare
    ColorMode.NIGHT -> ColorFilter.colorMatrix(
        ColorMatrix(
            floatArrayOf(
                -0.86f, 0f, 0f, 0f, 238f,
                0f, -0.86f, 0f, 0f, 238f,
                0f, 0f, -0.86f, 0f, 238f,
                0f, 0f, 0f, 1f, 0f,
            ),
        ),
    )
    ColorMode.SEPIA -> ColorFilter.colorMatrix(
        ColorMatrix(
            floatArrayOf(
                0.393f, 0.769f, 0.189f, 0f, 0f,
                0.349f, 0.686f, 0.168f, 0f, 0f,
                0.272f, 0.534f, 0.131f, 0f, 0f,
                0f, 0f, 0f, 1f, 0f,
            ),
        ),
    )
    ColorMode.WARM -> ColorFilter.colorMatrix(
        ColorMatrix(
            floatArrayOf(
                1f, 0f, 0f, 0f, 0f,
                0f, 0.94f, 0f, 0f, 0f,
                0f, 0f, 0.78f, 0f, 0f,
                0f, 0f, 0f, 1f, 0f,
            ),
        ),
    )
    ColorMode.GRAY -> ColorFilter.colorMatrix(ColorMatrix().apply { setToSaturation(0f) })
}

fun pageBackground(mode: ColorMode): Color = when (mode) {
    ColorMode.NIGHT -> Color(0xFF121212)
    ColorMode.SEPIA -> Color(0xFFF4ECD8)
    ColorMode.WARM -> Color(0xFFFBF1E0)
    else -> Color.White
}

fun deskBackground(mode: ColorMode): Color = when (mode) {
    ColorMode.NIGHT -> Color(0xFF0B0B0C)
    ColorMode.SEPIA -> Color(0xFFD9CDB0)
    ColorMode.WARM -> Color(0xFFE6DCCB)
    ColorMode.GRAY -> Color(0xFFD7D7D7)
    ColorMode.DAY -> Color(0xFFE4E5EA)
}

// ------------------------------------------------------------------ page

/**
 * One rendered page plus its annotation overlay.
 * [fit] = true fits the whole page inside the box (paged modes); false = fill the box width (continuous).
 */
@Composable
fun PdfPage(session: DocSession, index: Int, boxWidthPx: Int, boxHeightPx: Int, fit: Boolean) {
    val engine = session.engine
    val size = engine.sizeOf(index) ?: return
    val density = LocalDensity.current

    val wPx: Float
    val hPx: Float
    if (fit) {
        val s = min(boxWidthPx / size.width, boxHeightPx / size.height)
        wPx = size.width * s
        hPx = size.height * s
    } else {
        wPx = boxWidthPx.toFloat()
        hPx = wPx * size.aspect
    }

    // Render at the on-screen size times the settled zoom (1.0 at rest, then 0.5 steps), capped by a pixel budget,
    // and quantised to 32px so small layout changes reuse the cached bitmap.
    val renderScale = (ceil((session.zoom.settledScale - 0.01f) * 2f) / 2f).coerceAtLeast(1f)
    val maxW = sqrt(MAX_PIXELS / size.aspect)
    val target = (ceil(min(wPx * renderScale, maxW) / 32f) * 32f).toInt().coerceAtLeast(64)

    var bmp by remember(engine, index) {
        mutableStateOf<Bitmap?>(engine.cached(index, target) ?: engine.cached(index, PdfEngine.THUMB_WIDTH))
    }
    LaunchedEffect(engine, index, target) {
        if (bmp?.width != target) {
            try {
                if (bmp == null) bmp = engine.render(index, PdfEngine.THUMB_WIDTH) // instant low-res preview
                bmp = engine.render(index, target)
            } catch (e: CancellationException) {
                throw e
            } catch (_: Throwable) {
                // out of memory or render failure: keep whatever is already shown
            }
        }
    }
    // Links are read lazily, a page at a time, so they are ready by the time the reader taps
    LaunchedEffect(engine, index) { session.ensureLinks(index) }

    val mode = session.meta.colorMode
    val filter = remember(mode) { colorFilterFor(mode) }

    Box(
        Modifier
            .size(with(density) { wPx.toDp() }, with(density) { hPx.toDp() })
            .background(pageBackground(mode)),
    ) {
        val current = bmp
        if (current != null) {
            val image = remember(current) { current.asImageBitmap() }
            Image(
                bitmap = image,
                contentDescription = "Page ${index + 1}",
                modifier = Modifier.fillMaxSize(),
                contentScale = ContentScale.FillBounds,
                colorFilter = filter,
                filterQuality = FilterQuality.High,
            )
        }
        AnnotLayer(session, index, wPx, hPx)
    }
}

private fun Tool.shapeType(): AnnotType = when (this) {
    Tool.LINE -> AnnotType.SHAPE_LINE
    Tool.ARROW -> AnnotType.SHAPE_ARROW
    Tool.RECT -> AnnotType.SHAPE_RECT
    else -> AnnotType.SHAPE_OVAL
}

private val SafeSchemes = setOf("http", "https", "mailto", "tel")

private fun openExternal(context: Context, uri: String) {
    val parsed = Uri.parse(uri)
    // Only ordinary web/mail/phone links: PDFs can carry intent:, file: and other schemes that must not be launched
    if (parsed.scheme?.lowercase() !in SafeSchemes) {
        Toast.makeText(context, "This link type isn't supported", Toast.LENGTH_SHORT).show()
        return
    }
    try {
        context.startActivity(Intent(Intent.ACTION_VIEW, parsed).addFlags(Intent.FLAG_ACTIVITY_NEW_TASK))
    } catch (_: Exception) {
        Toast.makeText(context, "No app can open this link", Toast.LENGTH_SHORT).show()
    }
}

// ------------------------------------------------------------------ annotation overlay + input

@Composable
private fun AnnotLayer(session: DocSession, index: Int, wPx: Float, hPx: Float) {
    val context = LocalContext.current
    val tool = session.tool
    val list = session.annotsByPage[index].orEmpty()
    val latestList by rememberUpdatedState(list)
    val hits = session.searchHits.filter { it.page == index }
    val currentHit = session.searchHits.getOrNull(session.searchIndex)
    val live = remember(index) { mutableStateListOf<Pt>() }
    var erasing by remember(index) { mutableStateOf(emptySet<String>()) }
    val measurer = rememberTextMeasurer()

    val links = session.links[index].orEmpty()
    val latestLinks by rememberUpdatedState(links)
    val sel = session.selection?.takeIf { it.page == index }
    val pageText = session.textOf(index)
    val selRects = remember(sel, pageText) {
        if (sel != null && pageText != null) pageText.rectsFor(sel.start, sel.end) else emptyList()
    }
    val latestSelRects by rememberUpdatedState(selRects)
    val latestSelection by rememberUpdatedState(session.selection)

    val input: Modifier = when (tool) {
        Tool.PEN, Tool.HIGHLIGHT, Tool.LINE, Tool.ARROW, Tool.RECT, Tool.OVAL -> Modifier.pointerInput(tool, wPx, hPx) {
            awaitEachGesture {
                val down = awaitFirstDown(requireUnconsumed = true)
                val start = Pt(down.position.x / wPx, down.position.y / hPx)
                live.clear()
                live.add(start)
                down.consume()
                var ok = true
                while (true) {
                    val ev = awaitPointerEvent()
                    if (ev.changes.count { it.pressed } > 1) { ok = false; break }
                    val ch = ev.changes.firstOrNull { it.id == down.id } ?: break
                    if (ch.isConsumed && ch.positionChanged()) { ok = false; break }
                    if (!ch.pressed) { ch.consume(); break }
                    val p = Pt(ch.position.x / wPx, ch.position.y / hPx)
                    when (tool) {
                        Tool.PEN -> {
                            val last = live.last()
                            if (abs(p.x - last.x) * wPx + abs(p.y - last.y) * hPx > 1.5f) live.add(p)
                        }
                        Tool.HIGHLIGHT -> {
                            // straight highlighter band; snaps horizontal when the drag is nearly level
                            val y = if (abs(p.y - start.y) < 0.02f) start.y else p.y
                            if (live.size == 1) live.add(Pt(p.x, y)) else live[1] = Pt(p.x, y)
                        }
                        else -> if (live.size == 1) live.add(p) else live[1] = p
                    }
                    ch.consume()
                }
                val last = live.lastOrNull()
                val moved = last != null && abs(last.x - start.x) * wPx + abs(last.y - start.y) * hPx > 6f
                val valid = ok && live.isNotEmpty() && (tool == Tool.PEN || moved)
                if (valid) {
                    session.addAnnot(
                        Annot(
                            id = UUID.randomUUID().toString(),
                            page = index,
                            type = when (tool) {
                                Tool.PEN -> AnnotType.INK
                                Tool.HIGHLIGHT -> AnnotType.HIGHLIGHT
                                else -> tool.shapeType()
                            },
                            color = if (tool == Tool.HIGHLIGHT) session.highlightColor else session.penColor,
                            width = if (tool == Tool.HIGHLIGHT) HIGHLIGHT_WIDTH else session.penWidth,
                            points = live.toList(),
                        ),
                    )
                }
                live.clear()
            }
        }

        Tool.ERASER -> Modifier.pointerInput(tool, wPx, hPx) {
            awaitEachGesture {
                val down = awaitFirstDown(requireUnconsumed = true)
                val removed = mutableSetOf<String>()
                fun probe(pos: Offset) {
                    latestList.forEach { a ->
                        if (a.id !in removed && a.hit(pos, wPx, hPx, 14f)) removed += a.id
                    }
                    erasing = removed.toSet()
                }
                probe(down.position)
                down.consume()
                while (true) {
                    val ev = awaitPointerEvent()
                    if (ev.changes.count { it.pressed } > 1) { removed.clear(); break }
                    val ch = ev.changes.firstOrNull { it.id == down.id } ?: break
                    if (!ch.pressed) { ch.consume(); break }
                    probe(ch.position)
                    ch.consume()
                }
                if (removed.isNotEmpty()) session.removeAnnots(removed.toSet())
                erasing = emptySet()
            }
        }

        Tool.TEXT -> Modifier.pointerInput(tool, wPx, hPx) {
            detectTapGestures { pos ->
                val existing = latestList.lastOrNull { it.type == AnnotType.TEXT && it.hit(pos, wPx, hPx, 12f) }
                session.textEdit = TextEdit(index, Pt(pos.x / wPx, pos.y / hPx), existing)
            }
        }

        // Reading: long-press selects a word, handles extend it, a tap on a link follows it.
        // Anything else is left unconsumed so scrolling, zooming and "tap to toggle the bars" keep working.
        Tool.NONE -> Modifier.pointerInput(wPx, hPx) {
            val handleReach = 36.dp.toPx()
            val handleLift = 22.dp.toPx()
            awaitEachGesture {
                val down = awaitFirstDown(requireUnconsumed = false)

                val rects = latestSelRects
                if (rects.isNotEmpty()) {
                    val first = rects.first()
                    val last = rects.last()
                    val dStart = hypot(down.position.x - first.l * wPx, down.position.y - first.b * hPx)
                    val dEnd = hypot(down.position.x - last.r * wPx, down.position.y - last.b * hPx)
                    if (min(dStart, dEnd) <= handleReach) {
                        val isStart = dStart <= dEnd
                        down.consume()
                        while (true) {
                            val ev = awaitPointerEvent()
                            val ch = ev.changes.firstOrNull { it.id == down.id } ?: break
                            if (!ch.pressed) { ch.consume(); break }
                            session.moveSelection(isStart, ch.position.x / wPx, (ch.position.y - handleLift) / hPx)
                            ch.consume()
                        }
                        return@awaitEachGesture
                    }
                }

                val pressed = awaitLongPressOrCancellation(down.id)
                if (pressed != null) {
                    session.beginSelection(index, pressed.position.x / wPx, pressed.position.y / hPx)
                    pressed.consume()
                    while (true) {
                        val ev = awaitPointerEvent()
                        ev.changes.forEach { it.consume() }
                        if (ev.changes.none { it.pressed }) break
                    }
                } else {
                    val up = currentEvent.changes.firstOrNull { it.id == down.id }
                    if (up != null && !up.pressed && !up.isConsumed) {
                        val nx = down.position.x / wPx
                        val ny = down.position.y / hPx
                        val link = latestLinks.firstOrNull {
                            nx >= it.rect.l - 0.004f && nx <= it.rect.r + 0.004f &&
                                ny >= it.rect.t - 0.004f && ny <= it.rect.b + 0.004f
                        }
                        if (link != null) {
                            up.consume()
                            if (link.page >= 0) session.followLink(link.page)
                            else link.uri?.let { openExternal(context, it) }
                        } else if (latestSelection != null) {
                            up.consume()
                            session.clearSelection()
                        }
                    }
                }
            }
        }
    }

    Canvas(Modifier.fillMaxSize().then(input)) {
        hits.forEach { hit ->
            val isCurrent = hit === currentHit
            hit.rects.forEach { r ->
                drawRect(
                    color = if (isCurrent) Color(0x99FF9800) else Color(0x66FFEB3B),
                    topLeft = Offset(r.l * size.width, r.t * size.height),
                    size = Size((r.r - r.l) * size.width, (r.b - r.t) * size.height),
                )
            }
        }
        list.forEach { a -> if (a.id !in erasing) drawAnnot(a, measurer) }
        if (live.isNotEmpty()) {
            val ms = min(size.width, size.height)
            when {
                tool == Tool.HIGHLIGHT -> if (live.size >= 2) {
                    drawLine(
                        Color(session.highlightColor).copy(alpha = 0.35f),
                        Offset(live[0].x * size.width, live[0].y * size.height),
                        Offset(live[1].x * size.width, live[1].y * size.height),
                        strokeWidth = HIGHLIGHT_WIDTH * ms,
                        cap = StrokeCap.Butt,
                    )
                }
                tool.isShape -> if (live.size >= 2) {
                    drawShape(Annot("live", index, tool.shapeType(), session.penColor, session.penWidth, live.toList()))
                }
                else -> drawInk(live, Color(session.penColor), session.penWidth * ms)
            }
        }
        // Text selection: tinted lines plus a teardrop handle at each end
        if (selRects.isNotEmpty()) {
            selRects.forEach { r ->
                drawRect(
                    color = SelectionColor.copy(alpha = 0.3f),
                    topLeft = Offset(r.l * size.width, r.t * size.height),
                    size = Size((r.r - r.l) * size.width, (r.b - r.t) * size.height),
                )
            }
            val f = selRects.first()
            val l = selRects.last()
            val radius = 8.dp.toPx()
            val stem = 2.dp.toPx()
            drawLine(SelectionColor, Offset(f.l * size.width, f.t * size.height), Offset(f.l * size.width, f.b * size.height), stem)
            drawCircle(SelectionColor, radius, Offset(f.l * size.width, f.b * size.height + radius))
            drawLine(SelectionColor, Offset(l.r * size.width, l.t * size.height), Offset(l.r * size.width, l.b * size.height), stem)
            drawCircle(SelectionColor, radius, Offset(l.r * size.width, l.b * size.height + radius))
        }
    }
}

private fun DrawScope.drawAnnot(a: Annot, measurer: TextMeasurer) {
    val ms = min(size.width, size.height)
    val color = Color(a.color)
    when (a.type) {
        AnnotType.INK -> drawInk(a.points, color, a.width * ms)
        AnnotType.HIGHLIGHT -> if (a.points.size >= 2) {
            drawLine(
                color.copy(alpha = 0.35f),
                Offset(a.points.first().x * size.width, a.points.first().y * size.height),
                Offset(a.points.last().x * size.width, a.points.last().y * size.height),
                strokeWidth = a.width * ms,
                cap = StrokeCap.Butt,
            )
        }
        AnnotType.TEXT -> {
            val p = a.points.firstOrNull() ?: return
            drawText(
                textMeasurer = measurer,
                text = a.text,
                topLeft = Offset(p.x * size.width, p.y * size.height),
                style = TextStyle(color = color, fontSize = (a.width * ms).toSp()),
                softWrap = false,
            )
        }
        AnnotType.MARK_HIGHLIGHT, AnnotType.MARK_UNDERLINE, AnnotType.MARK_STRIKE -> {
            var i = 0
            while (i + 1 < a.points.size) {
                val p = a.points[i]
                val q = a.points[i + 1]
                i += 2
                val l = min(p.x, q.x) * size.width
                val r = max(p.x, q.x) * size.width
                val t = min(p.y, q.y) * size.height
                val b = max(p.y, q.y) * size.height
                val thick = max(1.5f, (b - t) * 0.07f)
                when (a.type) {
                    AnnotType.MARK_HIGHLIGHT ->
                        drawRect(color.copy(alpha = 0.35f), Offset(l, t), Size(r - l, b - t))
                    AnnotType.MARK_UNDERLINE -> drawLine(color, Offset(l, b), Offset(r, b), thick)
                    else -> drawLine(color, Offset(l, (t + b) / 2f), Offset(r, (t + b) / 2f), thick)
                }
            }
        }
        AnnotType.SHAPE_LINE, AnnotType.SHAPE_ARROW, AnnotType.SHAPE_RECT, AnnotType.SHAPE_OVAL -> drawShape(a)
    }
}

private fun DrawScope.drawShape(a: Annot) {
    if (a.points.size < 2) return
    val w = size.width
    val h = size.height
    val ms = min(w, h)
    val p = Offset(a.points[0].x * w, a.points[0].y * h)
    val q = Offset(a.points[1].x * w, a.points[1].y * h)
    val color = Color(a.color)
    val sw = a.width * ms
    val stroke = Stroke(width = sw, cap = StrokeCap.Round, join = StrokeJoin.Round)
    val topLeft = Offset(min(p.x, q.x), min(p.y, q.y))
    val extent = Size(abs(q.x - p.x), abs(q.y - p.y))
    when (a.type) {
        AnnotType.SHAPE_LINE -> drawLine(color, p, q, sw, StrokeCap.Round)
        AnnotType.SHAPE_ARROW -> {
            drawLine(color, p, q, sw, StrokeCap.Round)
            val ang = atan2(q.y - p.y, q.x - p.x)
            val len = max(sw * 4f, ms * 0.03f)
            for (delta in floatArrayOf(0.5f, -0.5f)) {
                val e = Offset(q.x - len * cos(ang + delta), q.y - len * sin(ang + delta))
                drawLine(color, q, e, sw, StrokeCap.Round)
            }
        }
        AnnotType.SHAPE_RECT -> drawRect(color, topLeft, extent, style = stroke)
        AnnotType.SHAPE_OVAL -> drawOval(color, topLeft, extent, style = stroke)
        else -> Unit
    }
}

private fun DrawScope.drawInk(pts: List<Pt>, color: Color, strokePx: Float) {
    if (pts.isEmpty()) return
    val w = size.width
    val h = size.height
    if (pts.size == 1) {
        drawCircle(color, strokePx / 2f, Offset(pts[0].x * w, pts[0].y * h))
        return
    }
    val path = Path()
    path.moveTo(pts[0].x * w, pts[0].y * h)
    for (i in 1 until pts.size) {
        val p0 = pts[i - 1]
        val p1 = pts[i]
        path.quadraticBezierTo(p0.x * w, p0.y * h, (p0.x + p1.x) / 2f * w, (p0.y + p1.y) / 2f * h)
    }
    path.lineTo(pts.last().x * w, pts.last().y * h)
    drawPath(path, color, style = Stroke(width = strokePx, cap = StrokeCap.Round, join = StrokeJoin.Round))
}

// ------------------------------------------------------------------ hit testing (pixel space)

private fun distToSegment(p: Offset, a: Offset, b: Offset): Float {
    val dx = b.x - a.x
    val dy = b.y - a.y
    val len2 = dx * dx + dy * dy
    if (len2 == 0f) return hypot(p.x - a.x, p.y - a.y)
    val t = (((p.x - a.x) * dx + (p.y - a.y) * dy) / len2).coerceIn(0f, 1f)
    return hypot(p.x - (a.x + t * dx), p.y - (a.y + t * dy))
}

internal fun Annot.hit(p: Offset, w: Float, h: Float, tol: Float): Boolean {
    val ms = min(w, h)
    val first = points.firstOrNull() ?: return false
    return when (type) {
        AnnotType.TEXT -> {
            val lines = text.split("\n")
            val tw = (lines.maxOfOrNull { it.length } ?: 1) * width * ms * 0.55f
            val th = lines.size * width * ms * 1.25f
            p.x in (first.x * w - tol)..(first.x * w + tol + tw) &&
                p.y in (first.y * h - tol)..(first.y * h + th + tol)
        }
        AnnotType.MARK_HIGHLIGHT, AnnotType.MARK_UNDERLINE, AnnotType.MARK_STRIKE -> {
            var inside = false
            var i = 0
            while (i + 1 < points.size && !inside) {
                val a = points[i]
                val b = points[i + 1]
                i += 2
                inside = p.x in (min(a.x, b.x) * w - tol)..(max(a.x, b.x) * w + tol) &&
                    p.y in (min(a.y, b.y) * h - tol)..(max(a.y, b.y) * h + tol)
            }
            inside
        }
        AnnotType.SHAPE_LINE, AnnotType.SHAPE_ARROW -> {
            points.size >= 2 && distToSegment(
                p,
                Offset(points[0].x * w, points[0].y * h),
                Offset(points[1].x * w, points[1].y * h),
            ) <= tol + width * ms / 2f
        }
        AnnotType.SHAPE_RECT -> {
            if (points.size < 2) {
                false
            } else {
                val l = min(points[0].x, points[1].x) * w
                val r = max(points[0].x, points[1].x) * w
                val t = min(points[0].y, points[1].y) * h
                val b = max(points[0].y, points[1].y) * h
                val outer = p.x in (l - tol)..(r + tol) && p.y in (t - tol)..(b + tol)
                val inner = p.x in (l + tol)..(r - tol) && p.y in (t + tol)..(b - tol)
                outer && !inner
            }
        }
        AnnotType.SHAPE_OVAL -> {
            if (points.size < 2) {
                false
            } else {
                val cx = (points[0].x + points[1].x) / 2f * w
                val cy = (points[0].y + points[1].y) / 2f * h
                val rx = max(abs(points[1].x - points[0].x) / 2f * w, 1f)
                val ry = max(abs(points[1].y - points[0].y) / 2f * h, 1f)
                val d = sqrt(((p.x - cx) / rx) * ((p.x - cx) / rx) + ((p.y - cy) / ry) * ((p.y - cy) / ry))
                abs(d - 1f) * min(rx, ry) <= tol + width * ms / 2f
            }
        }
        AnnotType.INK, AnnotType.HIGHLIGHT -> {
            val reach = tol + width * ms / 2f
            if (points.size == 1) {
                hypot(p.x - first.x * w, p.y - first.y * h) <= reach
            } else {
                points.zipWithNext().any { (a, b) ->
                    distToSegment(p, Offset(a.x * w, a.y * h), Offset(b.x * w, b.y * h)) <= reach
                }
            }
        }
    }
}
