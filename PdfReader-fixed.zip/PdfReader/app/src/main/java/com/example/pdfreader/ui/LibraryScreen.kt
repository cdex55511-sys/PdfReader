package com.example.pdfreader.ui

import android.graphics.Bitmap
import android.graphics.BitmapFactory
import androidx.compose.foundation.Image
import androidx.compose.foundation.background
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.aspectRatio
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.lazy.grid.GridCells
import androidx.compose.foundation.lazy.grid.GridItemSpan
import androidx.compose.foundation.lazy.grid.LazyVerticalGrid
import androidx.compose.foundation.lazy.grid.items
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Delete
import androidx.compose.material.icons.filled.Edit
import androidx.compose.material.icons.filled.FileOpen
import androidx.compose.material.icons.filled.MoreVert
import androidx.compose.material.icons.filled.PictureAsPdf
import androidx.compose.material.icons.filled.Search
import androidx.compose.material.icons.filled.Star
import androidx.compose.material.icons.filled.StarBorder
import androidx.compose.material3.AlertDialog
import androidx.compose.material3.Card
import androidx.compose.material3.DropdownMenu
import androidx.compose.material3.DropdownMenuItem
import androidx.compose.material3.ElevatedCard
import androidx.compose.material3.ExtendedFloatingActionButton
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.LinearProgressIndicator
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.Scaffold
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.produceState
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.asImageBitmap
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import com.example.pdfreader.data.DocMeta
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.withContext

@Composable
fun LibraryScreen(vm: AppViewModel, onOpenPicker: () -> Unit) {
    var query by remember { mutableStateOf("") }
    val all = vm.recents
    val filtered = all.filter { it.name.contains(query, ignoreCase = true) }
    val hero = if (query.isBlank()) filtered.firstOrNull() else null
    // Starred documents first; the sort is stable so each group stays in most-recently-opened order
    val rest = (if (hero != null) filtered.drop(1) else filtered).sortedByDescending { it.favorite }
    var renaming by remember { mutableStateOf<DocMeta?>(null) }

    Scaffold(
        containerColor = MaterialTheme.colorScheme.background,
        floatingActionButton = {
            ExtendedFloatingActionButton(
                onClick = onOpenPicker,
                icon = { Icon(Icons.Default.FileOpen, null) },
                text = { Text("Open PDF") },
            )
        },
    ) { pad ->
        LazyVerticalGrid(
            columns = GridCells.Adaptive(150.dp),
            modifier = Modifier.fillMaxSize(),
            contentPadding = PaddingValues(
                start = 16.dp, end = 16.dp,
                top = pad.calculateTopPadding() + 24.dp,
                bottom = pad.calculateBottomPadding() + 96.dp,
            ),
            horizontalArrangement = Arrangement.spacedBy(12.dp),
            verticalArrangement = Arrangement.spacedBy(12.dp),
        ) {
            item(span = { GridItemSpan(maxLineSpan) }) {
                Column {
                    Text("Library", style = MaterialTheme.typography.displaySmall)
                    Text(
                        if (all.isEmpty()) "Your PDFs will show up here" else "${all.size} document${if (all.size == 1) "" else "s"}",
                        style = MaterialTheme.typography.bodyMedium,
                        color = MaterialTheme.colorScheme.onSurfaceVariant,
                    )
                }
            }
            if (all.size > 3) {
                item(span = { GridItemSpan(maxLineSpan) }) {
                    OutlinedTextField(
                        value = query,
                        onValueChange = { query = it },
                        modifier = Modifier.fillMaxWidth(),
                        singleLine = true,
                        placeholder = { Text("Search documents") },
                        leadingIcon = { Icon(Icons.Default.Search, null) },
                        shape = RoundedCornerShape(28.dp),
                    )
                }
            }
            if (all.isEmpty()) {
                item(span = { GridItemSpan(maxLineSpan) }) { EmptyState(onOpenPicker) }
            }
            if (hero != null) {
                item(span = { GridItemSpan(maxLineSpan) }) { HeroCard(vm, hero) }
            }
            items(rest, key = { it.id }) { meta -> DocCard(vm, meta) { renaming = it } }
        }
    }

    renaming?.let { target ->
        var text by remember(target.id) { mutableStateOf(target.name) }
        AlertDialog(
            onDismissRequest = { renaming = null },
            title = { Text("Rename") },
            text = { OutlinedTextField(value = text, onValueChange = { text = it }, singleLine = true) },
            confirmButton = {
                TextButton(
                    enabled = text.isNotBlank(),
                    onClick = { vm.rename(target, text); renaming = null },
                ) { Text("Save") }
            },
            dismissButton = { TextButton(onClick = { renaming = null }) { Text("Cancel") } },
        )
    }
}

@Composable
private fun EmptyState(onOpenPicker: () -> Unit) {
    Column(Modifier.fillMaxWidth().padding(vertical = 48.dp), horizontalAlignment = Alignment.CenterHorizontally) {
        Icon(Icons.Default.PictureAsPdf, null, Modifier.size(72.dp), tint = MaterialTheme.colorScheme.primary)
        Spacer(Modifier.height(16.dp))
        Text("No PDFs yet", style = MaterialTheme.typography.titleLarge)
        Text(
            "Tap Open PDF, or open a PDF from any file manager and choose this app.",
            Modifier.padding(horizontal = 24.dp, vertical = 8.dp),
            style = MaterialTheme.typography.bodyMedium,
            color = MaterialTheme.colorScheme.onSurfaceVariant,
        )
    }
}

@Composable
private fun Thumb(vm: AppViewModel, meta: DocMeta, modifier: Modifier) {
    val bmp by produceState<Bitmap?>(null, meta.id, meta.lastOpened, meta.pageCount) {
        value = withContext(Dispatchers.IO) {
            val f = vm.store.thumb(meta.id)
            if (f.exists()) BitmapFactory.decodeFile(f.absolutePath) else null
        }
    }
    Box(modifier.background(androidx.compose.ui.graphics.Color.White), contentAlignment = Alignment.Center) {
        val b = bmp
        if (b != null) {
            Image(b.asImageBitmap(), null, Modifier.fillMaxSize(), contentScale = ContentScale.Crop, alignment = Alignment.TopCenter)
        } else {
            Icon(Icons.Default.PictureAsPdf, null, tint = MaterialTheme.colorScheme.outline)
        }
    }
}

@Composable
private fun HeroCard(vm: AppViewModel, meta: DocMeta) {
    ElevatedCard(onClick = { vm.openRecent(meta) }, Modifier.fillMaxWidth()) {
        Row(Modifier.padding(12.dp), verticalAlignment = Alignment.CenterVertically) {
            Thumb(vm, meta, Modifier.width(88.dp).aspectRatio(0.72f).clip(RoundedCornerShape(10.dp)))
            Column(Modifier.weight(1f).padding(start = 16.dp)) {
                Text("Continue reading", style = MaterialTheme.typography.labelMedium, color = MaterialTheme.colorScheme.primary)
                Text(meta.name, style = MaterialTheme.typography.titleMedium, maxLines = 2, overflow = TextOverflow.Ellipsis)
                Text(
                    "Page ${meta.lastPage + 1} of ${meta.pageCount} · ${relativeTime(meta.lastOpened)}",
                    style = MaterialTheme.typography.bodySmall,
                    color = MaterialTheme.colorScheme.onSurfaceVariant,
                )
                Spacer(Modifier.height(10.dp))
                LinearProgressIndicator(
                    progress = { if (meta.pageCount > 0) (meta.lastPage + 1f) / meta.pageCount else 0f },
                    modifier = Modifier.fillMaxWidth(),
                )
            }
        }
    }
}

@Composable
private fun DocCard(vm: AppViewModel, meta: DocMeta, onRename: (DocMeta) -> Unit) {
    var menu by remember { mutableStateOf(false) }
    Card(onClick = { vm.openRecent(meta) }, Modifier.fillMaxWidth()) {
        Box {
            Thumb(vm, meta, Modifier.fillMaxWidth().aspectRatio(0.78f))
            Box(Modifier.align(Alignment.TopEnd)) {
                IconButton(onClick = { menu = true }) { Icon(Icons.Default.MoreVert, "Options", tint = MaterialTheme.colorScheme.onSurface) }
                DropdownMenu(expanded = menu, onDismissRequest = { menu = false }) {
                    DropdownMenuItem(
                        text = { Text(if (meta.favorite) "Remove star" else "Star") },
                        leadingIcon = { Icon(if (meta.favorite) Icons.Default.Star else Icons.Default.StarBorder, null) },
                        onClick = { menu = false; vm.toggleFavorite(meta) },
                    )
                    DropdownMenuItem(
                        text = { Text("Rename") },
                        leadingIcon = { Icon(Icons.Default.Edit, null) },
                        onClick = { menu = false; onRename(meta) },
                    )
                    DropdownMenuItem(
                        text = { Text("Remove from library") },
                        leadingIcon = { Icon(Icons.Default.Delete, null) },
                        onClick = { menu = false; vm.deleteDoc(meta) },
                    )
                }
            }
            if (meta.favorite) {
                Icon(Icons.Default.Star, null, Modifier.align(Alignment.TopStart).padding(8.dp).size(18.dp), tint = androidx.compose.ui.graphics.Color(0xFFFFB300))
            }
        }
        Column(Modifier.padding(12.dp)) {
            Text(meta.name, style = MaterialTheme.typography.titleSmall, maxLines = 2, overflow = TextOverflow.Ellipsis)
            Text(
                "${meta.pageCount} pages · ${formatSize(meta.sizeBytes)}",
                style = MaterialTheme.typography.bodySmall,
                color = MaterialTheme.colorScheme.onSurfaceVariant,
            )
        }
    }
}
