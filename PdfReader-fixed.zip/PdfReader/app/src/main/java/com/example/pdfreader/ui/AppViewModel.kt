package com.example.pdfreader.ui

import android.app.Application
import android.content.ClipData
import android.content.Context
import android.content.Intent
import android.graphics.Bitmap
import android.net.Uri
import android.provider.OpenableColumns
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableIntStateOf
import androidx.compose.runtime.mutableStateListOf
import androidx.compose.runtime.mutableStateMapOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.setValue
import androidx.core.content.FileProvider
import androidx.lifecycle.AndroidViewModel
import androidx.lifecycle.viewModelScope
import com.example.pdfreader.data.DocMeta
import com.example.pdfreader.data.PageSpec
import com.example.pdfreader.data.Store
import com.example.pdfreader.ocr.OcrData
import com.example.pdfreader.pdf.PdfEditor
import com.example.pdfreader.pdf.PdfEngine
import com.tom_roush.pdfbox.pdmodel.encryption.InvalidPasswordException
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext
import java.io.File
import java.io.FileOutputStream
import java.security.MessageDigest
import kotlin.coroutines.cancellation.CancellationException

class PasswordRequest(val id: String, val name: String, val size: Long)

private class NotAPdf : Exception()

private class Imported(val id: String, val name: String, val size: Long)

class AppViewModel(app: Application) : AndroidViewModel(app) {
    private val ctx: Context get() = getApplication<Application>()
    val store = Store(app)
    private val prefs = app.getSharedPreferences("prefs", Context.MODE_PRIVATE)

    var recents by mutableStateOf<List<DocMeta>>(emptyList()); private set
    val tabs = mutableStateListOf<DocSession>()
    var activeId by mutableStateOf<String?>(null); private set
    var busy by mutableStateOf<String?>(null); private set

    // ---- OCR language packs (downloaded on demand, kept in app storage)
    val ocrDownloads = mutableStateMapOf<String, Float>()
    var ocrDataVersion by mutableIntStateOf(0); private set
    var ocrError by mutableStateOf<String?>(null)

    fun downloadOcrLang(code: String) {
        if (ocrDownloads.containsKey(code)) return
        ocrDownloads[code] = 0f
        viewModelScope.launch {
            try {
                OcrData.download(ctx, code) { p -> ocrDownloads[code] = p }
                ocrDataVersion++
            } catch (e: CancellationException) {
                throw e
            } catch (e: Exception) {
                ocrError = "Couldn't download the language data. Check your connection and try again."
            } finally {
                ocrDownloads.remove(code)
            }
        }
    }
    var toast by mutableStateOf<String?>(null)
    var passwordFor by mutableStateOf<PasswordRequest?>(null); private set

    var keepScreenOn by mutableStateOf(prefs.getBoolean("keep_on", true)); private set
    var volumePaging by mutableStateOf(prefs.getBoolean("volume_paging", false)); private set

    val active: DocSession? get() = tabs.firstOrNull { it.id == activeId }

    init {
        PdfEditor.init(app)
        refreshRecents()
        restoreTabs()
    }

    // ------------------------------------------------------------ settings
    fun setKeepScreenOn(v: Boolean) {
        keepScreenOn = v
        prefs.edit().putBoolean("keep_on", v).apply()
    }

    fun setVolumePaging(v: Boolean) {
        volumePaging = v
        prefs.edit().putBoolean("volume_paging", v).apply()
    }

    // ------------------------------------------------------------ library
    fun refreshRecents() {
        viewModelScope.launch { recents = withContext(Dispatchers.IO) { store.loadAll() } }
    }

    fun toggleFavorite(meta: DocMeta) {
        // An open tab owns its metadata and would overwrite the file on its next save, so change it there.
        val open = tabs.firstOrNull { it.id == meta.id }
        if (open != null) {
            open.setFavorite(!open.meta.favorite)
            open.flush()
            refreshRecents()
            return
        }
        viewModelScope.launch {
            withContext(Dispatchers.IO) {
                store.loadMeta(meta.id)?.let { store.saveMeta(it.copy(favorite = !it.favorite)) }
            }
            refreshRecents()
        }
    }

    fun rename(meta: DocMeta, newName: String) {
        val name = newName.trim().ifEmpty { return }
        val open = tabs.firstOrNull { it.id == meta.id }
        if (open != null) {
            open.rename(name)
            open.flush()
            refreshRecents()
            return
        }
        viewModelScope.launch {
            withContext(Dispatchers.IO) {
                store.loadMeta(meta.id)?.let { store.saveMeta(it.copy(name = name)) }
            }
            refreshRecents()
        }
    }

    fun deleteDoc(meta: DocMeta) {
        tabs.firstOrNull { it.id == meta.id }?.let { closeTab(it.id) }
        viewModelScope.launch {
            withContext(Dispatchers.IO) { store.delete(meta.id) }
            refreshRecents()
        }
    }

    // ------------------------------------------------------------ tabs
    private fun persistTabs() {
        prefs.edit()
            .putString("tabs", tabs.joinToString(",") { it.id })
            .putString("active", activeId)
            .apply()
    }

    private fun restoreTabs() {
        viewModelScope.launch {
            val ids = prefs.getString("tabs", "").orEmpty().split(",").filter { it.isNotBlank() }
            val last = prefs.getString("active", null)
            for (id in ids) {
                val meta = withContext(Dispatchers.IO) { store.loadMeta(id) } ?: continue
                val engine = runCatching { PdfEngine.open(store.pdf(id)) }.getOrNull() ?: continue
                tabs.add(DocSession(meta, engine, store.loadAnnots(id), store.loadOcr(id), ctx, store, viewModelScope))
            }
            activeId = last?.takeIf { l -> tabs.any { it.id == l } }
        }
    }

    fun activate(id: String) {
        active?.flush()
        activeId = id
        persistTabs()
    }

    fun showLibrary() {
        active?.flush()
        activeId = null
        persistTabs()
        refreshRecents()
    }

    fun closeTab(id: String) {
        val idx = tabs.indexOfFirst { it.id == id }
        if (idx < 0) return
        val s = tabs.removeAt(idx)
        s.close()
        if (activeId == id) activeId = tabs.getOrNull(idx.coerceAtMost(tabs.size - 1))?.id
        persistTabs()
        refreshRecents()
    }

    fun flushAll() {
        tabs.forEach { it.flush() }
        persistTabs()
    }

    // ------------------------------------------------------------ opening files
    fun openUri(uri: Uri) {
        viewModelScope.launch {
            busy = "Opening…"
            try {
                val imported = withContext(Dispatchers.IO) { importPdf(uri) }
                openImported(imported.id, imported.name, imported.size)
            } catch (e: NotAPdf) {
                toast = "That file isn't a PDF."
            } catch (e: CancellationException) {
                throw e
            } catch (e: Throwable) {
                toast = "Couldn't open this file: ${e.message ?: e.javaClass.simpleName}"
            } finally {
                busy = null
            }
        }
    }

    fun openRecent(meta: DocMeta) {
        viewModelScope.launch {
            busy = "Opening…"
            try {
                openImported(meta.id, meta.name, meta.sizeBytes)
            } catch (e: CancellationException) {
                throw e
            } catch (e: Throwable) {
                toast = "Couldn't open this file: ${e.message ?: e.javaClass.simpleName}"
            } finally {
                busy = null
            }
        }
    }

    /** Copies the picked file into app storage (so editing is safe and works for cloud providers) and verifies it is a PDF. */
    private fun importPdf(uri: Uri): Imported {
        val name = queryName(uri) ?: uri.lastPathSegment ?: "document.pdf"
        val tmp = File.createTempFile("import", ".pdf", ctx.cacheDir)
        val md = MessageDigest.getInstance("SHA-256")
        var total = 0L
        var head = ByteArray(0)
        val input = ctx.contentResolver.openInputStream(uri) ?: throw java.io.IOException("Can't read file")
        input.use { ins ->
            tmp.outputStream().use { out ->
                val buf = ByteArray(64 * 1024)
                while (true) {
                    val n = ins.read(buf)
                    if (n < 0) break
                    if (total == 0L) head = buf.copyOf(minOf(n, 1024))
                    md.update(buf, 0, n)
                    out.write(buf, 0, n)
                    total += n
                }
            }
        }
        if (!String(head, Charsets.ISO_8859_1).contains("%PDF-")) {
            tmp.delete()
            throw NotAPdf()
        }
        val id = md.digest().joinToString("") { "%02x".format(it) }.take(32)
        val dest = store.pdf(id)
        if (!dest.exists()) {
            tmp.copyTo(dest, overwrite = true)
        }
        tmp.delete()
        return Imported(id, name.removeSuffix(".pdf").removeSuffix(".PDF"), total)
    }

    private fun queryName(uri: Uri): String? =
        runCatching {
            ctx.contentResolver.query(uri, arrayOf(OpenableColumns.DISPLAY_NAME), null, null, null)?.use { c ->
                if (c.moveToFirst()) c.getString(0) else null
            }
        }.getOrNull()

    private suspend fun openImported(id: String, name: String, size: Long) {
        if (tabs.any { it.id == id }) {
            activate(id)
            return
        }
        val file = store.pdf(id)
        val engine = try {
            PdfEngine.open(file)
        } catch (e: SecurityException) {
            passwordFor = PasswordRequest(id, name, size)
            return
        }
        if (engine.pageCount == 0) {
            engine.close()
            toast = "This PDF has no pages."
            return
        }
        val now = System.currentTimeMillis()
        val meta = (store.loadMeta(id) ?: DocMeta(id = id, name = name, sizeBytes = size, lastOpened = now))
            .copy(lastOpened = now, pageCount = engine.pageCount)
        withContext(Dispatchers.IO) { store.saveMeta(meta) }
        tabs.add(DocSession(meta, engine, store.loadAnnots(id), store.loadOcr(id), ctx, store, viewModelScope))
        activeId = id
        persistTabs()
        refreshRecents()
        updateThumbnail(id, engine)
    }

    private fun updateThumbnail(id: String, engine: PdfEngine) {
        viewModelScope.launch {
            runCatching {
                val bmp = engine.render(0, 360)
                withContext(Dispatchers.IO) {
                    FileOutputStream(store.thumb(id)).use { bmp.compress(Bitmap.CompressFormat.JPEG, 82, it) }
                }
                refreshRecents()
            }
        }
    }

    // ------------------------------------------------------------ passwords
    fun submitPassword(password: String) {
        val req = passwordFor ?: return
        launchBusy("Unlocking…") {
            try {
                val tmp = File(store.dir(req.id), "dec.tmp")
                PdfEditor.decrypt(ctx, store.pdf(req.id), password, tmp)
                tmp.copyTo(store.pdf(req.id), overwrite = true)
                tmp.delete()
                passwordFor = null
                openImported(req.id, req.name, req.size)
            } catch (e: InvalidPasswordException) {
                toast = "Wrong password."
            }
        }
    }

    fun cancelPassword() {
        passwordFor?.let { req ->
            if (store.loadMeta(req.id) == null) store.delete(req.id)
        }
        passwordFor = null
    }

    // ------------------------------------------------------------ editing
    private fun launchBusy(message: String, block: suspend () -> Unit) {
        viewModelScope.launch {
            busy = message
            try {
                block()
            } catch (e: CancellationException) {
                throw e
            } catch (e: Throwable) {
                toast = e.message ?: "Something went wrong."
            } finally {
                busy = null
            }
        }
    }

    fun applyPlan(s: DocSession, plan: List<PageSpec>) = launchBusy("Applying changes…") {
        s.applyPlan(ctx, plan)
        updateThumbnail(s.id, s.engine)
        toast = "Pages updated"
    }

    fun merge(s: DocSession, uris: List<Uri>) = launchBusy("Merging…") {
        val files = withContext(Dispatchers.IO) {
            uris.map { uri ->
                val f = File.createTempFile("merge", ".pdf", ctx.cacheDir)
                ctx.contentResolver.openInputStream(uri)?.use { ins -> f.outputStream().use { ins.copyTo(it) } }
                val head = ByteArray(1024)
                val n = f.inputStream().use { it.read(head) }.coerceAtLeast(0)
                if (!String(head, 0, n, Charsets.ISO_8859_1).contains("%PDF-")) {
                    f.delete()
                    throw IllegalArgumentException("One of the selected files isn't a PDF.")
                }
                f
            }
        }
        try {
            s.merge(ctx, files)
        } finally {
            files.forEach { it.delete() }
        }
        updateThumbnail(s.id, s.engine)
        toast = "Merged ${files.size} file(s)"
    }

    fun extract(s: DocSession, plan: List<PageSpec>, dest: Uri) = launchBusy("Extracting…") {
        val tmp = File(ctx.cacheDir, "extract.pdf")
        PdfEditor.build(ctx, store.pdf(s.id), plan, tmp)
        copyToUri(tmp, dest)
        tmp.delete()
        toast = "Saved ${plan.size} page(s)"
    }

    fun saveCopy(s: DocSession, dest: Uri, password: String? = null) = launchBusy("Saving…") {
        val tmp = File(ctx.cacheDir, "export.pdf")
        s.exportTo(ctx, tmp, password)
        copyToUri(tmp, dest)
        tmp.delete()
        toast = "Saved"
    }

    /** Exports the document (with annotations) to a cache file and hands it to [then] on the main thread. */
    fun export(s: DocSession, then: (File) -> Unit) = launchBusy("Preparing…") {
        val dir = File(ctx.cacheDir, "shared").apply { mkdirs() }
        val safe = s.meta.name.replace(Regex("[^A-Za-z0-9._ -]"), "_").ifBlank { "document" }
        val out = File(dir, "$safe.pdf")
        s.exportTo(ctx, out)
        then(out)
    }

    fun share(file: File) {
        val uri = FileProvider.getUriForFile(ctx, "${ctx.packageName}.files", file)
        val send = Intent(Intent.ACTION_SEND).apply {
            type = "application/pdf"
            putExtra(Intent.EXTRA_STREAM, uri)
            clipData = ClipData.newRawUri("", uri)
            addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION)
        }
        ctx.startActivity(Intent.createChooser(send, "Share PDF").addFlags(Intent.FLAG_ACTIVITY_NEW_TASK))
    }

    private suspend fun copyToUri(file: File, dest: Uri) = withContext(Dispatchers.IO) {
        val out = ctx.contentResolver.openOutputStream(dest, "wt") ?: throw java.io.IOException("Can't write file")
        out.use { o -> file.inputStream().use { it.copyTo(o) } }
    }

    override fun onCleared() {
        flushAll()
        super.onCleared()
    }
}
