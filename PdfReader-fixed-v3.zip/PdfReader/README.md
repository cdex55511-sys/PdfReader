# PDF Reader (Android, Kotlin + Jetpack Compose)

A PDF-only reader with annotation and page-editing tools. Native Kotlin, Material 3 (dynamic colour, light/dark), min SDK 26.

## Open and run
1. Open this folder in **Android Studio** (Ladybug 2024.2 or newer) and let Gradle sync.
2. Run on a device or emulator (Android 8.0+). Command line: `./gradlew assembleDebug`.

## Features
**Reading**
- Layouts: continuous scroll, page-by-page horizontal swipe, page-by-page vertical swipe (remembered per document)
- Reading modes: Day, Night (inverted), Sepia, Warm, Grayscale
- Pinch zoom up to 6x, double-tap zoom, pan; pages re-render sharper when you stop zooming
- Immersive mode (tap the middle of the page to hide all bars), keep-screen-on, optional volume-key page turns
- Page slider, go-to-page, thumbnail grid, resumes at your last page; "Continue reading" card on the home screen
- **Speed-sensitive swipe**: in continuous mode a gentle flick scrolls a little, a hard flick covers many pages (distance scales with swipe speed, also while zoomed); in page-by-page modes a hard flick can skip up to 12 pages
- Auto-scroll at an adjustable speed (menu or View sheet); tap the pause button to stop
- Tappable links inside the PDF (internal jumps show a "Back to page N" button; web/mail/phone links open outside the app)

**Tabs, bookmarks, navigation**
- Several PDFs open at once as tabs (restored after the app restarts)
- Library: starred documents first, rename, remove, search by name
- Bookmarks (per page, listed in a sheet), table of contents / outline, full-text search (phrases work, matches highlighted per line, next/previous)

**Text tools**
- Long-press a word to select, drag the handles; Copy, Highlight, Underline, Strikethrough, Search for it, or Share the text (Arabic/RTL aware)
- OCR for scanned PDFs (Tesseract, on-device): Menu > Recognize text. Pick a language (Arabic, Urdu, Persian, English and 10 more); its data is downloaded once. Recognized text is searchable and selectable

**Editing**
- **Pen, Brush and Marker**: Pen is an even line; Brush varies its width with your speed (or stylus pressure); Marker is wide, flat and translucent. Each tool remembers its own colour, thickness and opacity
- Thickness slider with live preview plus five one-tap sizes; opacity slider; any colour via the custom colour picker (hue/saturation/brightness or hex)
- Highlighter band (adjustable height and opacity) and **area highlight**: drag a translucent box over a figure, table or paragraph (optional outline)
- Shapes: line, arrow, double arrow, rectangle, oval, triangle, diamond; each can be filled (tint or solid), solid / dashed / dotted, and snapped to 45 degrees / squares / circles
- **Select tool**: tap anything you've drawn to move it, resize it with the corner handles (line ends have their own handles), change its colour, thickness, opacity, fill or dash afterwards, duplicate it, bring it forward or send it back, edit text, or delete it
- **Eraser** with adjustable size: erase just the part of a pen stroke you touch, or whole items
- **Underline, strikethrough and squiggly underline** tools: drag across text (tap a word for just that word); each has its own colour, thickness and opacity. They also work from the text-selection bar, and on scanned pages without text they mark along the line you drag
- **Sticky notes**: tap the page to drop a note icon with text; tap a note to read or edit it. Colour, icon size and opacity are adjustable. On export a note is drawn on the page and also added as a real PDF note annotation carrying its text
- **Finger offset**: when you draw with a finger, the line appears 20 dp above the fingertip (a small ring shows exactly where) so your finger doesn't hide it. Adjustable 0-60 dp in the annotation options; a stylus is never shifted
- **Notebooks**: Library > New notebook creates a blank PDF (blank, lined, grid or dotted; A4, A5, Letter or square; portrait or landscape) for rough work and sketches. Add pages with the + button, then Menu > Export as PDF (or Share). Notebooks live in your library like any other PDF
- Annotations list (menu): every annotation by page; tap to jump to it, delete one, clear a page or everything
- Text notes (any language) with size slider and colour; undo/redo covers all of the above
- Save with password (AES-128 encrypted copy); Properties dialog
- Annotations stay editable; they are baked into the PDF when you Save a copy, Share or Print
- Organize pages: reorder, rotate, delete, insert blank pages, extract selected pages to a new PDF, merge other PDFs (the PDF's outline and form fields are kept)
- Open password-protected PDFs

**PDF only**: the file picker and the intent filters accept `application/pdf` only, and files are checked for a PDF header on import.

## How it stays fast
- Rendering uses the platform `PdfRenderer` (PDFium) off the main thread; page sizes are read once so the list never jumps
- LRU bitmap cache sized to 20% of the heap, low-res preview first, then full resolution, capped at about 12 megapixels per page
- Pinch/pan is a GPU transform; the re-render happens once when the gesture ends
- Very large PDFs (300+ pages) open instantly: page sizes are read lazily and corrected as pages render
- Low-memory handling: the bitmap cache is dropped on system memory pressure, and a render that runs out of memory frees the cache and retries once
- Editing, search and export use PDFBox (`pdfbox-android`) with temp-file memory mode for large documents

## Layout
- `pdf/PdfEngine.kt` rendering + cache; `pdf/PdfIndex.kt` text and links; `pdf/PageText.kt` selection geometry; `ocr/OcrEngine.kt` Tesseract; `pdf/PdfEditor.kt` page ops, merge, outline, search, annotation export
- `ui/DocSession.kt` per-tab state (zoom, bookmarks, annotations, undo, search); `ui/AppViewModel.kt` library, tabs, import
- `ui/AnnotBar.kt` annotation toolbar and style panel; `data/Strokes.kt` stroke geometry shared by screen and export; `ui/ReaderScreen.kt`, `PageView.kt`, `ZoomContainer.kt`, `OrganizerScreen.kt`, `LibraryScreen.kt`, `Sheets.kt`, `MoreSheets.kt`

## Known limits
- Not compiled in the authoring environment (no Android SDK there): expect to fix a few small compile errors on first sync
- The Tesseract OCR library adds roughly 10-20 MB to the APK (native code for several CPU types); language data needs the INTERNET permission once
- OCR results are stored beside the document for search/selection; they are not written into the PDF as an invisible text layer. OCR on a page is dropped if that page is rotated
- Annotations are flattened into the PDF on export (Save a copy, Share, Print); other PDF apps see drawing, not editable annotation objects
- Sticky notes are not a pop-up bubble in other apps unless that app shows PDF note annotations
- Not implemented: filling in form fields, read-aloud, signature stamps, cloud sync
- Library versions (Tesseract4Android 4.7.0, PDFBox-Android 2.0.27.0) and some API calls were written from memory, so check them first if Gradle sync or the build complains

## Notes
- Opened PDFs are copied into app storage (editing never touches the original). "Remove from library" deletes the copy.
- Saved annotations are drawn as ink/highlight strokes and text; they are not editable in other PDF apps after export.
- Change `applicationId`/`namespace` in `app/build.gradle.kts` before publishing.
