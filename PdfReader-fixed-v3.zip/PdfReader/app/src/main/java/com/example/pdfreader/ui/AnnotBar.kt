package com.example.pdfreader.ui

import androidx.compose.foundation.BorderStroke
import androidx.compose.foundation.Canvas
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.horizontalScroll
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.heightIn
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.filled.Backspace
import androidx.compose.material.icons.automirrored.filled.Redo
import androidx.compose.material.icons.automirrored.filled.Undo
import androidx.compose.material.icons.filled.ContentCopy
import androidx.compose.material.icons.filled.Delete
import androidx.compose.material.icons.filled.Done
import androidx.compose.material.icons.filled.Edit
import androidx.compose.material.icons.filled.FlipToBack
import androidx.compose.material.icons.filled.FlipToFront
import androidx.compose.material.icons.filled.Highlight
import androidx.compose.material.icons.filled.KeyboardArrowDown
import androidx.compose.material.icons.filled.KeyboardArrowUp
import androidx.compose.material.icons.filled.TextFields
import androidx.compose.material.icons.filled.TouchApp
import androidx.compose.material3.AlertDialog
import androidx.compose.material3.DropdownMenu
import androidx.compose.material3.DropdownMenuItem
import androidx.compose.material3.FilterChip
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.IconButtonDefaults
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.Slider
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.geometry.Size
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.Path
import androidx.compose.ui.graphics.StrokeCap
import androidx.compose.ui.graphics.StrokeJoin
import androidx.compose.ui.graphics.drawscope.Stroke
import androidx.compose.ui.graphics.toArgb
import androidx.compose.ui.graphics.vector.ImageVector
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.input.KeyboardType
import androidx.compose.ui.unit.dp
import androidx.compose.foundation.text.KeyboardOptions
import com.example.pdfreader.data.AnnotType
import com.example.pdfreader.data.BrushType
import com.example.pdfreader.data.isClosedShape
import com.example.pdfreader.data.isLineShape
import kotlin.math.abs
import kotlin.math.roundToInt

private val inkColors = listOf(0xFF111111, 0xFFE53935, 0xFF1E88E5, 0xFF43A047, 0xFFFB8C00, 0xFF8E24AA, 0xFF757575, 0xFFFFFFFF)
    .map { it.toInt() }
private val markerColors = listOf(0xFFFFEB3B, 0xFF69F0AE, 0xFFFF80AB, 0xFF18FFFF, 0xFFFFAB40, 0xFFB388FF, 0xFFFF5252)
    .map { it.toInt() }

private val markupTools = listOf(
    Tool.UNDERLINE to "Underline", Tool.STRIKE to "Strikethrough", Tool.SQUIGGLY to "Squiggly underline",
)

private val shapeTools = listOf(
    Tool.LINE to "Line", Tool.ARROW to "Arrow", Tool.DOUBLE_ARROW to "Double arrow", Tool.RECT to "Rectangle",
    Tool.OVAL to "Oval", Tool.TRIANGLE to "Triangle", Tool.DIAMOND to "Diamond",
)

/** Annotation toolbar: tools on top, then the options of whichever tool (or selected annotation) is active. */
@Composable
fun AnnotationBar(session: DocSession) {
    val t = session.tool
    var showOptions by remember { mutableStateOf(true) }
    var lastShape by remember { mutableStateOf(Tool.RECT) }
    var shapeMenu by remember { mutableStateOf(false) }
    var lastMarkup by remember { mutableStateOf(Tool.UNDERLINE) }
    var markupMenu by remember { mutableStateOf(false) }
    LaunchedEffect(t) {
        if (t.isShape) lastShape = t
        if (t.isTextMarkup) lastMarkup = t
    }

    Column(Modifier.fillMaxWidth().padding(horizontal = 8.dp, vertical = 4.dp)) {
        Row(verticalAlignment = Alignment.CenterVertically) {
            Row(Modifier.weight(1f).horizontalScroll(rememberScrollState()), verticalAlignment = Alignment.CenterVertically) {
                ToolIcon(Icons.Default.TouchApp, "Select, move and resize", t == Tool.SELECT) { session.tool = Tool.SELECT }
                ToolIcon(Icons.Default.Edit, "Pen and brush", t == Tool.PEN) { session.tool = Tool.PEN }
                ToolIcon(Icons.Default.Highlight, "Highlighter", t == Tool.HIGHLIGHT) { session.tool = Tool.HIGHLIGHT }
                ToolGlyph(Tool.AREA, "Area highlight", t == Tool.AREA) { session.tool = Tool.AREA }
                Box {
                    ToolGlyph(if (t.isTextMarkup) t else lastMarkup, "Underline, strikethrough, squiggly", t.isTextMarkup) {
                        if (t.isTextMarkup) markupMenu = true else session.tool = lastMarkup
                    }
                    DropdownMenu(expanded = markupMenu, onDismissRequest = { markupMenu = false }) {
                        markupTools.forEach { (tool, label) ->
                            DropdownMenuItem(
                                text = { Text(label) },
                                leadingIcon = { ShapeGlyph(tool, MaterialTheme.colorScheme.onSurface) },
                                onClick = { markupMenu = false; session.tool = tool },
                            )
                        }
                    }
                }
                ToolIcon(Icons.Default.TextFields, "Text", t == Tool.TEXT) { session.tool = Tool.TEXT }
                ToolGlyph(Tool.NOTE, "Sticky note", t == Tool.NOTE) { session.tool = Tool.NOTE }
                Box {
                    ToolGlyph(if (t.isShape) t else lastShape, "Shapes", t.isShape) {
                        if (t.isShape) shapeMenu = true else session.tool = lastShape
                    }
                    DropdownMenu(expanded = shapeMenu, onDismissRequest = { shapeMenu = false }) {
                        shapeTools.forEach { (tool, label) ->
                            DropdownMenuItem(
                                text = { Text(label) },
                                leadingIcon = { ShapeGlyph(tool, MaterialTheme.colorScheme.onSurface) },
                                onClick = { shapeMenu = false; session.tool = tool },
                            )
                        }
                    }
                }
                ToolIcon(Icons.AutoMirrored.Filled.Backspace, "Eraser", t == Tool.ERASER) { session.tool = Tool.ERASER }
            }
            IconButton(onClick = { session.undo() }, enabled = session.canUndo) { Icon(Icons.AutoMirrored.Filled.Undo, "Undo") }
            IconButton(onClick = { session.redo() }, enabled = session.canRedo) { Icon(Icons.AutoMirrored.Filled.Redo, "Redo") }
            IconButton(onClick = { showOptions = !showOptions }) {
                Icon(if (showOptions) Icons.Default.KeyboardArrowDown else Icons.Default.KeyboardArrowUp, "Show or hide options")
            }
            IconButton(onClick = { session.tool = Tool.NONE }) { Icon(Icons.Default.Done, "Done") }
        }
        if (showOptions) {
            Column(Modifier.heightIn(max = 270.dp).verticalScroll(rememberScrollState())) {
                ToolOptions(session)
            }
        }
    }
}

@Composable
private fun ToolOptions(session: DocSession) {
    val t = session.tool
    when {
        t == Tool.SELECT -> {
            val a = session.selectedAnnot
            if (a == null) {
                Hint("Tap anything you've drawn to select it. Drag to move it; drag a corner handle to resize.")
            } else {
                Row(Modifier.horizontalScroll(rememberScrollState()), verticalAlignment = Alignment.CenterVertically) {
                    if (a.type == AnnotType.TEXT) {
                        IconButton(onClick = { session.textEdit = TextEdit(a.page, a.points[0], a) }) { Icon(Icons.Default.Edit, "Edit text") }
                    }
                    IconButton(onClick = { session.duplicateSelected() }) { Icon(Icons.Default.ContentCopy, "Duplicate") }
                    IconButton(onClick = { session.bringSelectedToFront() }) { Icon(Icons.Default.FlipToFront, "Bring to front") }
                    IconButton(onClick = { session.sendSelectedToBack() }) { Icon(Icons.Default.FlipToBack, "Send to back") }
                    IconButton(onClick = { session.deleteSelected() }) { Icon(Icons.Default.Delete, "Delete") }
                    if (a.type.isLineShape || a.type.isClosedShape || a.type == AnnotType.AREA) {
                        SnapChip(session)
                    }
                }
                val key = a.styleKey()
                StylePanel(
                    key = key,
                    style = a.toStyle(),
                    onChange = { session.restyle(a.withStyle(it)) },
                    showOpacity = a.type != AnnotType.TEXT,
                    closed = a.type.isClosedShape,
                    dashable = a.type.isClosedShape || a.type.isLineShape,
                    brushes = a.type == AnnotType.INK,
                    sizeLabel = sizeLabelFor(key),
                )
                if (a.type == AnnotType.NOTE) Hint("Tap the note again to read or edit its text.")
            }
        }
        t == Tool.ERASER -> {
            Row(Modifier.horizontalScroll(rememberScrollState()).padding(horizontal = 4.dp), horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                FilterChip(selected = session.eraserPartial, onClick = { session.eraserPartial = true }, label = { Text("Erase part of a stroke") })
                FilterChip(selected = !session.eraserPartial, onClick = { session.eraserPartial = false }, label = { Text("Erase whole item") })
            }
            Row(Modifier.padding(horizontal = 12.dp), verticalAlignment = Alignment.CenterVertically) {
                Text("Size", style = MaterialTheme.typography.labelMedium)
                Slider(
                    value = session.eraserSize,
                    onValueChange = { session.eraserSize = it },
                    valueRange = 6f..44f,
                    modifier = Modifier.weight(1f).padding(horizontal = 8.dp),
                )
                Box(Modifier.size(44.dp), contentAlignment = Alignment.Center) {
                    Box(Modifier.size((session.eraserSize * 2f).dp.coerceAtMost(44.dp)).border(1.5.dp, MaterialTheme.colorScheme.onSurfaceVariant, CircleShape))
                }
            }
            Hint("Drag over your drawing. Highlights, shapes and text are removed whole.")
        }
        t.styleKey != null -> {
            val key = t.styleKey ?: return
            val style = session.styleOf(key)
            if (t.isDragShape) {
                Row(Modifier.padding(start = 8.dp)) { SnapChip(session) }
            }
            StylePanel(
                key = key,
                style = style,
                onChange = { new -> session.updateStyle(key) { new } },
                showOpacity = key != StyleKey.TEXT,
                closed = t == Tool.RECT || t == Tool.OVAL || t == Tool.TRIANGLE || t == Tool.DIAMOND,
                dashable = t.isShape,
                brushes = key == StyleKey.PEN,
                sizeLabel = sizeLabelFor(key),
            )
            when (key) {
                StyleKey.TEXT -> Hint("Tap the page to add text. Use Select to move, resize or edit it later.")
                StyleKey.HIGHLIGHT -> Hint("Drag along a line of text. A nearly level drag snaps straight.")
                StyleKey.AREA -> Hint("Drag a box over a figure, table or paragraph.")
                StyleKey.UNDERLINE, StyleKey.STRIKE, StyleKey.SQUIGGLY ->
                    Hint("Drag across the text. Tap a word to mark just that word.")
                StyleKey.NOTE -> Hint("Tap the page to add a note. Tap a note to read or edit it.")
                else -> Unit
            }
        }
    }
    if (t != Tool.SELECT && t != Tool.TEXT && t != Tool.NOTE) FingerOffsetRow()
    Hint("Two fingers to zoom or scroll while annotating. Leave the tools to select text.")
}

/** How far above the fingertip a finger-drawn line appears. Stylus input is never shifted. */
@Composable
private fun FingerOffsetRow() {
    val context = LocalContext.current
    val dp = PenPrefs.fingerOffsetDp
    Row(Modifier.padding(horizontal = 12.dp), verticalAlignment = Alignment.CenterVertically) {
        Text(if (dp < 1f) "Finger offset: off" else "Finger offset: ${dp.roundToInt()} dp", Modifier.width(140.dp), style = MaterialTheme.typography.labelMedium)
        Slider(
            value = dp,
            onValueChange = { PenPrefs.setFingerOffset(context, it) },
            valueRange = 0f..60f,
            modifier = Modifier.weight(1f),
        )
    }
}

private fun sizeLabelFor(key: StyleKey?): String = when (key) {
    StyleKey.UNDERLINE, StyleKey.STRIKE, StyleKey.SQUIGGLY -> "Line thickness"
    StyleKey.NOTE -> "Icon size"

    StyleKey.PEN -> "Thickness"
    StyleKey.HIGHLIGHT -> "Band height"
    StyleKey.AREA -> "Border"
    StyleKey.TEXT -> "Text size"
    StyleKey.SHAPE -> "Line width"
    null -> ""
}

@Composable
private fun SnapChip(session: DocSession) {
    FilterChip(
        selected = session.snapShapes,
        onClick = { session.snapShapes = !session.snapShapes },
        label = { Text("Snap: 45° / square") },
    )
}

/**
 * Colour, thickness, opacity, brush, fill and dash controls. It edits a [ToolStyle], so the same panel serves a tool's
 * remembered look and the look of an annotation that is currently selected.
 */
@Composable
private fun StylePanel(
    key: StyleKey?,
    style: ToolStyle,
    onChange: (ToolStyle) -> Unit,
    showOpacity: Boolean,
    closed: Boolean,
    dashable: Boolean,
    brushes: Boolean,
    sizeLabel: String,
) {
    var customColor by remember { mutableStateOf(false) }
    val palette = if (key == StyleKey.HIGHLIGHT || key == StyleKey.AREA || key == StyleKey.NOTE) markerColors else inkColors

    SwatchRow(palette, style.color, onPick = { onChange(style.copy(color = it)) }, onCustom = { customColor = true })
    if (customColor) {
        ColorPickerDialog(style.color, onPick = { onChange(style.copy(color = it)); customColor = false }, onDismiss = { customColor = false })
    }

    if (brushes) {
        Row(Modifier.horizontalScroll(rememberScrollState()).padding(horizontal = 8.dp), horizontalArrangement = Arrangement.spacedBy(8.dp)) {
            BrushType.entries.forEach { b ->
                FilterChip(selected = style.brush == b, onClick = { onChange(style.withBrush(b)) }, label = { Text(b.label) })
            }
        }
    }

    if (key != null) {
        val range = widthRange(key, style.brush)
        SizeRow(sizeLabel, style.width, range, previewColor = Color(style.color), border = key == StyleKey.AREA, text = key == StyleKey.TEXT) {
            onChange(style.copy(width = it))
        }
    }

    if (showOpacity) {
        Row(Modifier.padding(horizontal = 12.dp), verticalAlignment = Alignment.CenterVertically) {
            Text("Opacity ${(style.opacity * 100).roundToInt()}%", Modifier.width(104.dp), style = MaterialTheme.typography.labelMedium)
            Slider(
                value = style.opacity.coerceIn(0.1f, 1f),
                onValueChange = { onChange(style.copy(opacity = it)) },
                valueRange = 0.1f..1f,
                modifier = Modifier.weight(1f),
            )
        }
    }

    if (closed) {
        Row(Modifier.horizontalScroll(rememberScrollState()).padding(horizontal = 8.dp), horizontalArrangement = Arrangement.spacedBy(8.dp), verticalAlignment = Alignment.CenterVertically) {
            Text("Fill", style = MaterialTheme.typography.labelMedium)
            listOf("None" to 0f, "Tint" to 0.25f, "Solid" to 1f).forEach { (label, v) ->
                FilterChip(selected = abs(style.fill - v) < 0.01f, onClick = { onChange(style.copy(fill = v)) }, label = { Text(label) })
            }
        }
    }
    if (dashable) {
        Row(Modifier.horizontalScroll(rememberScrollState()).padding(horizontal = 8.dp), horizontalArrangement = Arrangement.spacedBy(8.dp), verticalAlignment = Alignment.CenterVertically) {
            Text("Line", style = MaterialTheme.typography.labelMedium)
            listOf("Solid", "Dashed", "Dotted").forEachIndexed { i, label ->
                FilterChip(selected = style.dash == i, onClick = { onChange(style.copy(dash = i)) }, label = { Text(label) })
            }
        }
    }
}

/** Slider with a live preview of the thickness, plus five one-tap sizes. */
@Composable
private fun SizeRow(
    label: String,
    value: Float,
    range: ClosedFloatingPointRange<Float>,
    previewColor: Color,
    border: Boolean,
    text: Boolean,
    onChange: (Float) -> Unit,
) {
    Column(Modifier.padding(horizontal = 12.dp)) {
        Row(verticalAlignment = Alignment.CenterVertically) {
            Text(label, Modifier.width(84.dp), style = MaterialTheme.typography.labelMedium)
            Slider(
                value = value.coerceIn(range.start, range.endInclusive),
                onValueChange = onChange,
                valueRange = range,
                modifier = Modifier.weight(1f),
            )
            SizePreview(value, previewColor, text)
        }
        Row(horizontalArrangement = Arrangement.spacedBy(10.dp), verticalAlignment = Alignment.CenterVertically) {
            val steps = 5
            for (i in 0 until steps) {
                val v = range.start + (range.endInclusive - range.start) * (i / (steps - 1f))
                val selected = abs(value - v) < (range.endInclusive - range.start) * 0.08f
                Box(
                    Modifier
                        .size(36.dp)
                        .clip(CircleShape)
                        .border(
                            BorderStroke(if (selected) 2.dp else 1.dp, if (selected) MaterialTheme.colorScheme.primary else MaterialTheme.colorScheme.outline),
                            CircleShape,
                        )
                        .clickable { onChange(v) },
                    contentAlignment = Alignment.Center,
                ) {
                    if (border && i == 0) {
                        Text("none", style = MaterialTheme.typography.labelSmall)
                    } else {
                        SizePreview(v, MaterialTheme.colorScheme.onSurface, text, inner = true)
                    }
                }
            }
        }
    }
}

@Composable
private fun SizePreview(width: Float, color: Color, text: Boolean, inner: Boolean = false) {
    val box = if (inner) 28.dp else 40.dp
    Canvas(Modifier.size(box)) {
        // a page is roughly 380dp across on a phone, so thickness * 380 gives an on-screen size in dp
        val px = (width * 380f).dp.toPx().coerceIn(1.5f, size.minDimension * 0.9f)
        if (text) {
            val h = px.coerceAtLeast(6f)
            drawRect(color, Offset(size.width * 0.2f, size.height / 2f - h / 2f), Size(size.width * 0.6f, h * 0.35f))
        } else {
            drawCircle(color, px / 2f, center)
        }
    }
}

@Composable
private fun Hint(text: String) {
    Text(
        text,
        Modifier.padding(horizontal = 12.dp, vertical = 2.dp),
        style = MaterialTheme.typography.bodySmall,
        color = MaterialTheme.colorScheme.onSurfaceVariant,
    )
}

@Composable
private fun ToolIcon(icon: ImageVector, label: String, selected: Boolean, onClick: () -> Unit) {
    IconButton(
        onClick = onClick,
        colors = if (selected) IconButtonDefaults.iconButtonColors(containerColor = MaterialTheme.colorScheme.primaryContainer)
        else IconButtonDefaults.iconButtonColors(),
    ) { Icon(icon, label) }
}

@Composable
private fun ToolGlyph(tool: Tool, label: String, selected: Boolean, onClick: () -> Unit) {
    IconButton(
        onClick = onClick,
        colors = if (selected) IconButtonDefaults.iconButtonColors(containerColor = MaterialTheme.colorScheme.primaryContainer)
        else IconButtonDefaults.iconButtonColors(),
    ) { ShapeGlyph(tool, MaterialTheme.colorScheme.onSurface, label) }
}

/** Small drawn icons for the shape tools (so they always match what the tool actually draws). */
@Composable
internal fun ShapeGlyph(tool: Tool, tint: Color, description: String? = null) {
    Canvas(Modifier.size(22.dp)) {
        val s = size.minDimension
        val sw = 2.dp.toPx()
        val stroke = Stroke(width = sw, cap = StrokeCap.Round, join = StrokeJoin.Round)
        val pad = sw * 1.2f
        val l = pad
        val r = s - pad
        val t = pad
        val b = s - pad
        fun head(from: Offset, tip: Offset) {
            val len = s * 0.3f
            val ang = kotlin.math.atan2(tip.y - from.y, tip.x - from.x)
            for (d in floatArrayOf(0.55f, -0.55f)) {
                drawLine(
                    tint, tip, Offset(tip.x - len * kotlin.math.cos(ang + d), tip.y - len * kotlin.math.sin(ang + d)),
                    sw, StrokeCap.Round,
                )
            }
        }
        when (tool) {
            Tool.LINE -> drawLine(tint, Offset(l, b), Offset(r, t), sw, StrokeCap.Round)
            Tool.ARROW -> {
                drawLine(tint, Offset(l, b), Offset(r, t), sw, StrokeCap.Round)
                head(Offset(l, b), Offset(r, t))
            }
            Tool.DOUBLE_ARROW -> {
                drawLine(tint, Offset(l, b), Offset(r, t), sw, StrokeCap.Round)
                head(Offset(l, b), Offset(r, t))
                head(Offset(r, t), Offset(l, b))
            }
            Tool.RECT -> drawRect(tint, Offset(l, t + s * 0.1f), Size(r - l, b - t - s * 0.2f), style = stroke)
            Tool.OVAL -> drawOval(tint, Offset(l, t + s * 0.1f), Size(r - l, b - t - s * 0.2f), style = stroke)
            Tool.TRIANGLE -> {
                val p = Path()
                p.moveTo(s / 2f, t)
                p.lineTo(r, b)
                p.lineTo(l, b)
                p.close()
                drawPath(p, tint, style = stroke)
            }
            Tool.DIAMOND -> {
                val p = Path()
                p.moveTo(s / 2f, t)
                p.lineTo(r, s / 2f)
                p.lineTo(s / 2f, b)
                p.lineTo(l, s / 2f)
                p.close()
                drawPath(p, tint, style = stroke)
            }
            Tool.UNDERLINE, Tool.STRIKE, Tool.SQUIGGLY -> {
                // a stub of text with the line the tool draws
                val top = t + s * 0.05f
                val textBottom = b - s * 0.3f
                drawLine(tint.copy(alpha = 0.55f), Offset(s * 0.3f, top), Offset(s * 0.3f, textBottom), sw, StrokeCap.Round)
                drawLine(tint.copy(alpha = 0.55f), Offset(s * 0.7f, top), Offset(s * 0.7f, textBottom), sw, StrokeCap.Round)
                drawLine(tint.copy(alpha = 0.55f), Offset(s * 0.3f, (top + textBottom) / 2f), Offset(s * 0.7f, (top + textBottom) / 2f), sw * 0.8f, StrokeCap.Round)
                when (tool) {
                    Tool.UNDERLINE -> drawLine(tint, Offset(l, b), Offset(r, b), sw, StrokeCap.Round)
                    Tool.STRIKE -> drawLine(tint, Offset(l, (top + textBottom) / 2f), Offset(r, (top + textBottom) / 2f), sw, StrokeCap.Round)
                    else -> {
                        val pts = com.example.pdfreader.data.wave(l, r, b - sw, sw * 0.9f, sw * 3.2f)
                        val path = Path()
                        path.moveTo(pts[0], pts[1])
                        for (k in 1 until pts.size / 2) path.lineTo(pts[2 * k], pts[2 * k + 1])
                        drawPath(path, tint, style = stroke)
                    }
                }
            }
            Tool.NOTE -> {
                val fold = s * 0.28f
                val p = Path()
                p.moveTo(l, t)
                p.lineTo(r, t)
                p.lineTo(r, b - fold)
                p.lineTo(r - fold, b)
                p.lineTo(l, b)
                p.close()
                drawPath(p, tint, style = stroke)
                drawLine(tint, Offset(l + s * 0.15f, t + s * 0.3f), Offset(r - s * 0.15f, t + s * 0.3f), sw * 0.8f, StrokeCap.Round)
                drawLine(tint, Offset(l + s * 0.15f, t + s * 0.5f), Offset(r - s * 0.15f, t + s * 0.5f), sw * 0.8f, StrokeCap.Round)
            }
            Tool.AREA -> {
                drawRect(tint.copy(alpha = 0.35f), Offset(l, t + s * 0.1f), Size(r - l, b - t - s * 0.2f))
                drawRect(tint, Offset(l, t + s * 0.1f), Size(r - l, b - t - s * 0.2f), style = Stroke(width = sw * 0.6f))
            }
            else -> Unit
        }
    }
}

@Composable
private fun SwatchRow(colors: List<Int>, selected: Int, onPick: (Int) -> Unit, onCustom: () -> Unit) {
    Row(
        Modifier.horizontalScroll(rememberScrollState()).padding(horizontal = 8.dp, vertical = 6.dp),
        horizontalArrangement = Arrangement.spacedBy(12.dp),
        verticalAlignment = Alignment.CenterVertically,
    ) {
        val all = if (selected in colors) colors else colors + selected
        all.forEach { c ->
            Box(
                Modifier
                    .size(30.dp)
                    .clip(CircleShape)
                    .background(Color(c))
                    .border(
                        BorderStroke(if (c == selected) 3.dp else 1.dp, if (c == selected) MaterialTheme.colorScheme.primary else Color.Gray),
                        CircleShape,
                    )
                    .clickable { onPick(c) },
            )
        }
        Box(
            Modifier
                .size(30.dp)
                .clip(CircleShape)
                .background(Brush.sweepGradient(listOf(Color.Red, Color.Yellow, Color.Green, Color.Cyan, Color.Blue, Color.Magenta, Color.Red)))
                .border(BorderStroke(1.dp, Color.Gray), CircleShape)
                .clickable(onClick = onCustom),
        )
    }
}

/** Pick any colour: hue / saturation / brightness sliders or a hex code. */
@Composable
private fun ColorPickerDialog(initial: Int, onPick: (Int) -> Unit, onDismiss: () -> Unit) {
    val start = remember(initial) {
        val hsv = FloatArray(3)
        android.graphics.Color.colorToHSV(initial, hsv)
        hsv
    }
    var hue by remember { mutableStateOf(start[0]) }
    var sat by remember { mutableStateOf(start[1]) }
    var value by remember { mutableStateOf(start[2]) }
    val color = Color.hsv(hue.coerceIn(0f, 360f), sat.coerceIn(0f, 1f), value.coerceIn(0f, 1f))
    var hex by remember { mutableStateOf("") }

    AlertDialog(
        onDismissRequest = onDismiss,
        title = { Text("Custom colour") },
        text = {
            Column(verticalArrangement = Arrangement.spacedBy(4.dp)) {
                Box(Modifier.fillMaxWidth().height(44.dp).clip(RoundedCornerShape(10.dp)).background(color))
                Text("Hue", style = MaterialTheme.typography.labelMedium)
                Slider(value = hue, onValueChange = { hue = it; hex = "" }, valueRange = 0f..360f)
                Text("Saturation", style = MaterialTheme.typography.labelMedium)
                Slider(value = sat, onValueChange = { sat = it; hex = "" }, valueRange = 0f..1f)
                Text("Brightness", style = MaterialTheme.typography.labelMedium)
                Slider(value = value, onValueChange = { value = it; hex = "" }, valueRange = 0f..1f)
                OutlinedTextField(
                    value = hex,
                    onValueChange = { input ->
                        val clean = input.removePrefix("#").take(6)
                        hex = clean
                        if (clean.length == 6 && clean.all { it.isDigit() || it.lowercaseChar() in 'a'..'f' }) {
                            val parsed = clean.toInt(16) or (0xFF shl 24)
                            val hsv = FloatArray(3)
                            android.graphics.Color.colorToHSV(parsed, hsv)
                            hue = hsv[0]
                            sat = hsv[1]
                            value = hsv[2]
                        }
                    },
                    label = { Text("Hex code, e.g. 1E88E5") },
                    singleLine = true,
                    keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Ascii),
                )
            }
        },
        confirmButton = { TextButton(onClick = { onPick(color.toArgb()) }) { Text("Use colour") } },
        dismissButton = { TextButton(onClick = onDismiss) { Text("Cancel") } },
    )
}
