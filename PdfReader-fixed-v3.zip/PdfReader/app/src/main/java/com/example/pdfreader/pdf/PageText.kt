package com.example.pdfreader.pdf

import com.example.pdfreader.data.NRect
import com.example.pdfreader.data.OcrWord
import com.example.pdfreader.data.SearchHit
import kotlin.math.abs
import kotlin.math.max
import kotlin.math.min

/**
 * The text of one page in *logical* reading order (so copy/paste and search work for right-to-left scripts such as
 * Arabic), with a bounding rectangle for every character that is drawn. Word gaps are ' ' and line breaks '\n'
 * (both have no rectangle). Rectangles are fractions of the displayed page, origin top-left.
 */
class PageText(val text: String, private val rects: List<NRect?>) {
    val isBlank: Boolean get() = text.isBlank()

    /** Index of the character nearest to (x, y); [aspect] = page height / width so distances are isotropic. */
    fun indexAt(x: Float, y: Float, aspect: Float, maxDist: Float = Float.MAX_VALUE): Int {
        var best = -1
        var bestD = Float.MAX_VALUE
        for (i in rects.indices) {
            val r = rects[i] ?: continue
            if (text[i].isWhitespace()) continue
            val dx = max(max(r.l - x, x - r.r), 0f)
            val dy = max(max(r.t - y, y - r.b), 0f) * aspect
            val d = dx * dx + dy * dy
            if (d < bestD) {
                bestD = d
                best = i
            }
        }
        if (best >= 0 && maxDist < Float.MAX_VALUE && bestD > maxDist * maxDist) return -1
        return best
    }

    /** The whitespace-delimited word around [i]. */
    fun wordRange(i: Int): IntRange {
        if (i !in text.indices || text[i].isWhitespace()) return i..i
        var a = i
        var b = i
        while (a > 0 && !text[a - 1].isWhitespace()) a--
        while (b < text.length - 1 && !text[b + 1].isWhitespace()) b++
        return a..b
    }

    /** One rectangle per visual line covering characters [a]..[b]. */
    fun rectsFor(a: Int, b: Int): List<NRect> {
        val out = ArrayList<NRect>()
        var cur: NRect? = null
        for (i in max(0, a)..min(b, rects.lastIndex)) {
            val r = rects[i] ?: continue
            val c = cur
            if (c == null) {
                cur = r
                continue
            }
            val h = c.b - c.t
            if (abs((r.t + r.b) / 2f - (c.t + c.b) / 2f) > h * 0.6f) {
                out += c
                cur = r
            } else {
                cur = NRect(min(c.l, r.l), min(c.t, r.t), max(c.r, r.r), max(c.b, r.b))
            }
        }
        cur?.let { out += it }
        return out
    }

    fun textFor(a: Int, b: Int): String = text.substring(max(0, a), min(text.length, b + 1))

    /** All case-insensitive occurrences of [query] (already whitespace-normalised). */
    fun find(query: String, page: Int): List<SearchHit> {
        if (query.isEmpty() || text.isEmpty()) return emptyList()
        val hay = text.replace('\n', ' ')
        val hits = ArrayList<SearchHit>()
        var from = 0
        while (true) {
            val idx = hay.indexOf(query, from, ignoreCase = true)
            if (idx < 0) break
            from = idx + query.length
            val snippet = hay.substring(max(0, idx - 30), min(hay.length, idx + query.length + 50))
                .replace(Regex("\\s+"), " ").trim()
            hits += SearchHit(page, snippet, rectsFor(idx, idx + query.length - 1))
        }
        return hits
    }

    companion object {
        val EMPTY = PageText("", emptyList())

        fun isRtl(c: Char): Boolean = c in '֐'..'ࣿ' || c in 'יִ'..'﻿'

        /** Builds page text from OCR words; characters share their word's box, split evenly. */
        fun fromWords(words: List<OcrWord>): PageText {
            val sb = StringBuilder()
            val rs = ArrayList<NRect?>()
            var prev: OcrWord? = null
            for (w in words) {
                if (w.t.isEmpty()) continue
                if (prev != null) {
                    val newLine = w.top > prev.top + (prev.b - prev.top) * 0.6f
                    sb.append(if (newLine) '\n' else ' ')
                    rs.add(null)
                }
                val n = w.t.length
                val rtl = w.t.any { isRtl(it) }
                for (k in 0 until n) {
                    sb.append(w.t[k])
                    val slot = if (rtl) n - 1 - k else k
                    val l = w.l + (w.r - w.l) * slot / n
                    val r = w.l + (w.r - w.l) * (slot + 1) / n
                    rs.add(NRect(l, w.top, r, w.b))
                }
                prev = w
            }
            return PageText(sb.toString(), rs)
        }
    }
}
