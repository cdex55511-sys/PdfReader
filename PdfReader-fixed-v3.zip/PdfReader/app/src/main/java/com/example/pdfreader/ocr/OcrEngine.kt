package com.example.pdfreader.ocr

import android.content.Context
import android.graphics.Bitmap
import com.example.pdfreader.data.OcrWord
import com.googlecode.tesseract.android.TessBaseAPI
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.withContext
import java.io.File
import java.io.IOException
import java.net.HttpURLConnection
import java.net.URL

data class OcrLang(val code: String, val label: String)

/** Language data for Tesseract: downloaded once from the official `tessdata_fast` repository and kept in app storage. */
object OcrData {
    val languages = listOf(
        OcrLang("eng", "English"),
        OcrLang("ara", "Arabic"),
        OcrLang("urd", "Urdu"),
        OcrLang("fas", "Persian"),
        OcrLang("hin", "Hindi"),
        OcrLang("ben", "Bengali"),
        OcrLang("tur", "Turkish"),
        OcrLang("ind", "Indonesian"),
        OcrLang("fra", "French"),
        OcrLang("deu", "German"),
        OcrLang("spa", "Spanish"),
        OcrLang("rus", "Russian"),
        OcrLang("chi_sim", "Chinese (Simplified)"),
        OcrLang("jpn", "Japanese"),
    )

    private fun root(ctx: Context) = File(ctx.filesDir, "tess")

    /** Tesseract wants the folder that *contains* `tessdata/`. */
    fun dataPath(ctx: Context): String = root(ctx).absolutePath

    private fun file(ctx: Context, code: String) = File(root(ctx), "tessdata/$code.traineddata")

    fun has(ctx: Context, code: String): Boolean = file(ctx, code).let { it.exists() && it.length() > 50_000 }

    suspend fun download(ctx: Context, code: String, onProgress: (Float) -> Unit) = withContext(Dispatchers.IO) {
        val dst = file(ctx, code)
        dst.parentFile?.mkdirs()
        val tmp = File(dst.parentFile, "$code.part")
        val conn = URL("https://raw.githubusercontent.com/tesseract-ocr/tessdata_fast/main/$code.traineddata")
            .openConnection() as HttpURLConnection
        try {
            conn.connectTimeout = 15_000
            conn.readTimeout = 30_000
            if (conn.responseCode != 200) throw IOException("HTTP ${conn.responseCode}")
            val total = conn.contentLengthLong.coerceAtLeast(1L)
            conn.inputStream.use { ins ->
                tmp.outputStream().use { out ->
                    val buf = ByteArray(32 * 1024)
                    var done = 0L
                    while (true) {
                        val n = ins.read(buf)
                        if (n < 0) break
                        out.write(buf, 0, n)
                        done += n
                        onProgress((done.toFloat() / total).coerceIn(0f, 1f))
                    }
                }
            }
            if (!tmp.renameTo(dst)) {
                tmp.copyTo(dst, overwrite = true)
            }
        } finally {
            conn.disconnect()
            tmp.delete()
        }
    }
}

/** One loaded Tesseract instance. Not thread-safe: use from a single coroutine at a time and [close] when done. */
class OcrRecognizer private constructor(private val api: TessBaseAPI) : AutoCloseable {

    fun recognize(bmp: Bitmap): List<OcrWord> {
        val w = bmp.width.toFloat()
        val h = bmp.height.toFloat()
        api.setImage(bmp)
        api.getUTF8Text() // runs recognition
        val iter = api.getResultIterator() ?: return emptyList()
        val level = TessBaseAPI.PageIteratorLevel.RIL_WORD
        val out = ArrayList<OcrWord>()
        try {
            iter.begin()
            do {
                val t = iter.getUTF8Text(level)?.trim()
                val r = iter.getBoundingRect(level)
                if (!t.isNullOrEmpty() && r != null && iter.confidence(level) > 30f) {
                    out += OcrWord(t, r.left / w, r.top / h, r.right / w, r.bottom / h)
                }
            } while (iter.next(level))
        } finally {
            iter.delete()
        }
        return out
    }

    override fun close() {
        api.recycle()
    }

    companion object {
        /** [languages] such as "ara" or "ara+eng". Throws IOException when the language data is missing. */
        fun create(ctx: Context, languages: String): OcrRecognizer {
            val api = TessBaseAPI()
            if (!api.init(OcrData.dataPath(ctx), languages)) {
                api.recycle()
                throw IOException("Could not load OCR language data for $languages")
            }
            api.setPageSegMode(TessBaseAPI.PageSegMode.PSM_AUTO)
            return OcrRecognizer(api)
        }
    }
}
