package com.example.pdfreader.pdf

import android.content.Context
import android.graphics.Bitmap
import android.graphics.Canvas
import android.graphics.Paint
import android.text.Layout
import android.text.StaticLayout
import android.text.TextPaint
import com.example.pdfreader.data.Annot
import com.example.pdfreader.data.AnnotType
import com.example.pdfreader.data.BrushType
import com.example.pdfreader.data.NRect
import com.example.pdfreader.data.OutlineEntry
import com.example.pdfreader.data.PageSpec
import com.example.pdfreader.data.wave
import com.example.pdfreader.data.PageTemplate
import com.example.pdfreader.data.Pt
import com.example.pdfreader.data.SearchHit
import com.example.pdfreader.data.alpha
import com.example.pdfreader.data.ribbon
import com.tom_roush.pdfbox.android.PDFBoxResourceLoader
import com.tom_roush.pdfbox.io.MemoryUsageSetting
import com.tom_roush.pdfbox.multipdf.PDFMergerUtility
import com.tom_roush.pdfbox.pdmodel.PDDocument
import com.tom_roush.pdfbox.pdmodel.PDPage
import com.tom_roush.pdfbox.pdmodel.PDPageContentStream
import com.tom_roush.pdfbox.pdmodel.common.PDRectangle
import com.tom_roush.pdfbox.pdmodel.encryption.AccessPermission
import com.tom_roush.pdfbox.pdmodel.encryption.StandardProtectionPolicy
import com.tom_roush.pdfbox.pdmodel.font.PDType1Font
import com.tom_roush.pdfbox.pdmodel.graphics.image.LosslessFactory
import com.tom_roush.pdfbox.pdmodel.graphics.state.PDExtendedGraphicsState
import com.tom_roush.pdfbox.pdmodel.interactive.action.PDActionGoTo
import com.tom_roush.pdfbox.pdmodel.interactive.annotation.PDAnnotationText
import com.tom_roush.pdfbox.pdmodel.interactive.documentnavigation.destination.PDNamedDestination
import com.tom_roush.pdfbox.pdmodel.interactive.documentnavigation.destination.PDPageDestination
import com.tom_roush.pdfbox.pdmodel.interactive.documentnavigation.outline.PDOutlineItem
import com.tom_roush.pdfbox.text.PDFTextStripper
import com.tom_roush.pdfbox.text.TextPosition
import com.tom_roush.pdfbox.util.Matrix
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.currentCoroutineContext
import kotlinx.coroutines.ensureActive
import kotlinx.coroutines.withContext
import java.io.File
import java.util.UUID
import kotlin.math.atan2
import kotlin.math.ceil
import kotlin.math.cos
import kotlin.math.max
import kotlin.math.min
import kotlin.math.sin

/** All PDFBox-based operations. Everything runs on Dispatchers.IO. */
object PdfEditor {
    private var inited = false

    fun init(context: Context) {
        if (!inited) {
            PDFBoxResourceLoader.init(context.applicationContext)
            inited = true
        }
    }

    private fun tempOnly() = MemoryUsageSetting.setupTempFileOnly()

    // ---------------------------------------------------------------- password

    /** Writes a copy of [src] with all security removed. Throws InvalidPasswordException on a wrong password. */
    suspend fun decrypt(context: Context, src: File, password: String, dst: File) = withContext(Dispatchers.IO) {
        init(context)
        PDDocument.load(src, password).use { doc ->
            doc.setAllSecurityToBeRemoved(true)
            doc.save(dst)
        }
    }

    // ---------------------------------------------------------------- page operations

    /**
     * Builds a new PDF from [plan] (reorder, delete, rotate, insert blank pages) by rearranging the pages of the
     * source document *in place*, so everything attached to the document rather than to a page survives: the
     * outline/bookmarks, form fields, metadata, named destinations and link targets.
     */
    suspend fun build(context: Context, src: File, plan: List<PageSpec>, dst: File) = withContext(Dispatchers.IO) {
        init(context)
        PDDocument.load(src, tempOnly()).use { doc ->
            val original = (0 until doc.numberOfPages).map { doc.getPage(it) }
            // Page size, rotation and resources may be inherited from the page tree; pin them to each page
            // before the tree is rebuilt, otherwise moved pages could lose them.
            original.forEach { p ->
                p.mediaBox = p.mediaBox
                p.cropBox = p.cropBox
                p.rotation = p.rotation
                p.resources?.let { p.resources = it }
            }
            for (i in original.indices.reversed()) doc.removePage(i)

            var lastBox: PDRectangle = original.firstOrNull()?.mediaBox ?: PDRectangle.A4
            plan.forEach { spec ->
                if (spec.src in original.indices) {
                    val p = original[spec.src]
                    if (spec.rotate != 0) p.rotation = ((p.rotation + spec.rotate) % 360 + 360) % 360
                    doc.addPage(p)
                    lastBox = p.mediaBox
                } else {
                    val blank = PDPage(lastBox)
                    doc.addPage(blank)
                    spec.template?.let { drawTemplate(doc, blank, it) }
                }
            }
            doc.save(dst)
        }
    }

    // ---------------------------------------------------------------- notebooks

    /** Creates a new PDF of [pages] blank sheets with the given paper pattern. */
    suspend fun createNotebook(
        context: Context, dst: File, title: String, widthPt: Float, heightPt: Float, template: PageTemplate, pages: Int,
    ) = withContext(Dispatchers.IO) {
        init(context)
        PDDocument().use { doc ->
            repeat(pages.coerceIn(1, 200)) {
                val page = PDPage(PDRectangle(widthPt, heightPt))
                doc.addPage(page)
                drawTemplate(doc, page, template)
            }
            // makes every notebook a different file, so two new notebooks never share an id
            doc.documentInformation.title = title
            doc.documentInformation.creationDate = java.util.Calendar.getInstance()
            doc.documentInformation.setCustomMetadataValue("notebookId", UUID.randomUUID().toString())
            doc.save(dst)
        }
    }

    /** Draws the ruling of a notebook page (light, so ink stands out). */
    internal fun drawTemplate(doc: PDDocument, page: PDPage, template: PageTemplate) {
        if (template == PageTemplate.BLANK) return
        val box = page.mediaBox
        val ox = box.lowerLeftX
        val oy = box.lowerLeftY
        val w = box.width
        val h = box.height
        PDPageContentStream(doc, page, PDPageContentStream.AppendMode.APPEND, true, true).use { cs ->
            cs.setStrokingColor(200, 206, 218)
            cs.setNonStrokingColor(170, 178, 192)
            when (template) {
                PageTemplate.LINED -> {
                    cs.setLineWidth(0.6f)
                    var y = h - 64f
                    while (y > 28f) {
                        cs.moveTo(ox + 24f, oy + y)
                        cs.lineTo(ox + w - 24f, oy + y)
                        cs.stroke()
                        y -= 26f
                    }
                }
                PageTemplate.GRID -> {
                    cs.setLineWidth(0.4f)
                    val step = 14.17f // 5 mm
                    var x = 0f
                    while (x <= w) {
                        cs.moveTo(ox + x, oy)
                        cs.lineTo(ox + x, oy + h)
                        cs.stroke()
                        x += step
                    }
                    var y = 0f
                    while (y <= h) {
                        cs.moveTo(ox, oy + y)
                        cs.lineTo(ox + w, oy + y)
                        cs.stroke()
                        y += step
                    }
                }
                PageTemplate.DOTS -> {
                    val step = 17f
                    var y = step
                    while (y < h) {
                        var x = step
                        while (x < w) {
                            cs.addRect(ox + x - 0.7f, oy + y - 0.7f, 1.4f, 1.4f)
                            x += step
                        }
                        y += step
                    }
                    cs.fill()
                }
                PageTemplate.BLANK -> Unit
            }
        }
    }

    suspend fun merge(context: Context, base: File, others: List<File>, dst: File) = withContext(Dispatchers.IO) {
        init(context)
        val merger = PDFMergerUtility()
        merger.addSource(base)
        others.forEach { merger.addSource(it) }
        merger.setDestinationFileName(dst.absolutePath)
        merger.mergeDocuments(tempOnly())
    }

    // ---------------------------------------------------------------- outline

    suspend fun outline(context: Context, file: File): List<OutlineEntry> = withContext(Dispatchers.IO) {
        init(context)
        runCatching {
            PDDocument.load(file, tempOnly()).use { doc ->
                val result = mutableListOf<OutlineEntry>()
                val root = doc.documentCatalog.documentOutline ?: return@use result

                fun pageOf(item: PDOutlineItem): Int {
                    val dest = item.destination ?: (item.action as? PDActionGoTo)?.destination
                    val pageDest: PDPageDestination? = when (dest) {
                        is PDPageDestination -> dest
                        is PDNamedDestination -> doc.documentCatalog.findNamedDestinationPage(dest)
                        else -> null
                    }
                    return pageDest?.retrievePageNumber() ?: -1
                }

                fun walk(first: PDOutlineItem?, level: Int) {
                    var cur = first
                    while (cur != null) {
                        val p = runCatching { pageOf(cur!!) }.getOrDefault(-1)
                        if (p >= 0) result += OutlineEntry(cur.title ?: "(untitled)", p, level)
                        walk(cur.firstChild, level + 1)
                        cur = cur.nextSibling
                    }
                }
                walk(root.firstChild, 0)
                result
            }
        }.getOrDefault(emptyList())
    }

    // ---------------------------------------------------------------- text, search

    /** Extracts one page (0-based) with the shared [stripper]. Pages without any text give [PageText.EMPTY]. */
    internal fun extractPage(doc: PDDocument, stripper: PageTextStripper, pageIndex: Int): PageText {
        stripper.result = null
        stripper.startPage = pageIndex + 1
        stripper.endPage = pageIndex + 1
        stripper.getText(doc)
        return stripper.result ?: PageText.EMPTY
    }

    /** Streams cumulative results through [onProgress] (called on the main thread) after each page with a match. */
    suspend fun search(
        context: Context,
        file: File,
        query: String,
        maxHits: Int = 500,
        onProgress: (List<SearchHit>) -> Unit,
    ) = withContext(Dispatchers.IO) {
        init(context)
        val q = query.trim().replace(Regex("\\s+"), " ")
        if (q.isEmpty()) return@withContext
        PDDocument.load(file, tempOnly()).use { doc ->
            val stripper = PageTextStripper()
            val acc = ArrayList<SearchHit>()
            for (p in 0 until doc.numberOfPages) {
                currentCoroutineContext().ensureActive()
                val found = extractPage(doc, stripper, p).find(q, p)
                if (found.isNotEmpty()) {
                    acc += found
                    val snapshot = acc.toList()
                    withContext(Dispatchers.Main) { onProgress(snapshot) }
                    if (acc.size >= maxHits) break
                }
            }
        }
    }

    // ---------------------------------------------------------------- flatten annotations into the PDF

    /** Bakes [annots] into a copy of [src]; with [password] the result is also encrypted. */
    suspend fun exportWithAnnotations(
        context: Context,
        src: File,
        annots: List<Annot>,
        dst: File,
        password: String? = null,
    ) = withContext(Dispatchers.IO) {
        init(context)
        PDDocument.load(src, tempOnly()).use { doc ->
            annots.groupBy { it.page }.forEach { (pageIndex, list) ->
                if (pageIndex !in 0 until doc.numberOfPages) return@forEach
                val page = doc.getPage(pageIndex)
                val geo = Geo(page)
                PDPageContentStream(doc, page, PDPageContentStream.AppendMode.APPEND, true, true).use { cs ->
                    list.forEach { drawAnnot(doc, cs, geo, it) }
                }
                // Sticky notes also become real PDF note annotations, so other apps can show their text
                list.filter { it.type == AnnotType.NOTE && it.text.isNotBlank() }.forEach { addNoteAnnotation(page, geo, it) }
            }
            if (!password.isNullOrEmpty()) {
                val policy = StandardProtectionPolicy(password, password, AccessPermission())
                policy.encryptionKeyLength = 128
                doc.protect(policy)
            }
            doc.save(dst)
        }
    }

    private fun drawAnnot(doc: PDDocument, cs: PDPageContentStream, g: Geo, a: Annot) {
        val r = (a.color shr 16) and 0xFF
        val gr = (a.color shr 8) and 0xFF
        val b = a.color and 0xFF
        when (a.type) {
            AnnotType.INK -> drawInk(cs, g, a, r, gr, b)
            AnnotType.HIGHLIGHT -> {
                val first = a.points.firstOrNull() ?: return
                val last = a.points.last()
                cs.saveGraphicsState()
                setAlpha(cs, a.alpha, a.alpha)
                cs.setStrokingColor(r, gr, b)
                cs.setLineWidth(a.width * g.minSide)
                cs.setLineCapStyle(0)
                cs.moveTo(g.x(first), g.y(first))
                cs.lineTo(g.x(last) + 0.01f, g.y(last))
                cs.stroke()
                cs.restoreGraphicsState()
            }
            AnnotType.AREA -> drawArea(cs, g, a, r, gr, b)
            AnnotType.TEXT -> drawText(doc, cs, g, a, r, gr, b)
            AnnotType.MARK_HIGHLIGHT, AnnotType.MARK_UNDERLINE, AnnotType.MARK_STRIKE, AnnotType.MARK_SQUIGGLY ->
                drawMarkup(cs, g, a, r, gr, b)
            AnnotType.NOTE -> drawNote(cs, g, a, r, gr, b)
            else -> drawShape(cs, g, a, r, gr, b)
        }
    }

    private fun setAlpha(cs: PDPageContentStream, stroke: Float, fill: Float) {
        val gs = PDExtendedGraphicsState()
        gs.setStrokingAlphaConstant(stroke)
        gs.setNonStrokingAlphaConstant(fill)
        cs.setGraphicsStateParameters(gs)
    }

    /** Dash pattern in points for a stroke of [strokePt]; mirrors the on-screen pattern. */
    private fun setDash(cs: PDPageContentStream, dash: Int, strokePt: Float) {
        val d = max(strokePt, 0.8f)
        when (dash) {
            1 -> cs.setLineDashPattern(floatArrayOf(4f * d, 3f * d), 0f)
            2 -> cs.setLineDashPattern(floatArrayOf(0.01f, 2.2f * d), 0f)
            else -> cs.setLineDashPattern(floatArrayOf(), 0f)
        }
    }

    private fun drawInk(cs: PDPageContentStream, g: Geo, a: Annot, r: Int, gr: Int, b: Int) {
        val pts = a.points
        val first = pts.firstOrNull() ?: return
        val base = a.width * g.minSide
        cs.saveGraphicsState()
        setAlpha(cs, a.alpha, a.alpha)
        cs.setLineJoinStyle(1)
        if (a.brush == BrushType.BRUSH && pts.size >= 2) {
            // variable width: fill the outline of the stroke
            val rb = ribbon(pts, a.widths, base, g.dispW, g.dispH)
            val outline = rb.left + rb.right.reversed()
            cs.setNonStrokingColor(r, gr, b)
            val o0 = Pt(outline[0].x / g.dispW, outline[0].y / g.dispH)
            cs.moveTo(g.x(o0), g.y(o0))
            for (k in 1 until outline.size) {
                val o = Pt(outline[k].x / g.dispW, outline[k].y / g.dispH)
                cs.lineTo(g.x(o), g.y(o))
            }
            cs.closePath()
            cs.fill()
            // rounded ends
            if (a.alpha >= 0.99f) {
                cs.setLineCapStyle(1)
                cs.setStrokingColor(r, gr, b)
                for ((pt, m) in listOf(pts.first() to a.widths.firstOrNull(), pts.last() to a.widths.lastOrNull())) {
                    cs.setLineWidth(base * (m ?: 1f))
                    cs.moveTo(g.x(pt), g.y(pt))
                    cs.lineTo(g.x(pt) + 0.01f, g.y(pt))
                    cs.stroke()
                }
            }
        } else {
            cs.setStrokingColor(r, gr, b)
            cs.setLineWidth(if (a.brush == BrushType.BRUSH) base * (a.widths.firstOrNull() ?: 1f) else base)
            cs.setLineCapStyle(if (a.brush == BrushType.MARKER) 2 else 1)
            cs.moveTo(g.x(first), g.y(first))
            if (pts.size == 1) {
                cs.lineTo(g.x(first) + 0.01f, g.y(first))
            } else {
                // same quadratic smoothing as on screen, written as cubic Béziers
                var sx = g.x(first)
                var sy = g.y(first)
                for (k in 1 until pts.size) {
                    val p0 = pts[k - 1]
                    val p1 = pts[k]
                    val cx = g.x(p0)
                    val cy = g.y(p0)
                    val m = Pt((p0.x + p1.x) / 2f, (p0.y + p1.y) / 2f)
                    val ex = g.x(m)
                    val ey = g.y(m)
                    cs.curveTo(
                        sx + 2f / 3f * (cx - sx), sy + 2f / 3f * (cy - sy),
                        ex + 2f / 3f * (cx - ex), ey + 2f / 3f * (cy - ey),
                        ex, ey,
                    )
                    sx = ex
                    sy = ey
                }
                cs.lineTo(g.x(pts.last()), g.y(pts.last()))
            }
            cs.stroke()
        }
        cs.restoreGraphicsState()
    }

    private fun rectPath(cs: PDPageContentStream, g: Geo, l: Float, t: Float, rt: Float, bt: Float) {
        val c = listOf(Pt(l, t), Pt(rt, t), Pt(rt, bt), Pt(l, bt))
        cs.moveTo(g.x(c[0]), g.y(c[0]))
        for (k in 1..3) cs.lineTo(g.x(c[k]), g.y(c[k]))
        cs.closePath()
    }

    private fun drawArea(cs: PDPageContentStream, g: Geo, a: Annot, r: Int, gr: Int, b: Int) {
        if (a.points.size < 2) return
        val p = a.points[0]
        val q = a.points[1]
        val l = min(p.x, q.x)
        val rt = max(p.x, q.x)
        val t = min(p.y, q.y)
        val bt = max(p.y, q.y)
        cs.saveGraphicsState()
        setAlpha(cs, 1f, a.alpha)
        cs.setNonStrokingColor(r, gr, b)
        rectPath(cs, g, l, t, rt, bt)
        cs.fill()
        if (a.width > 0f) {
            cs.setStrokingColor(r, gr, b)
            cs.setLineWidth(max(0.5f, a.width * g.minSide))
            cs.setLineJoinStyle(1)
            rectPath(cs, g, l, t, rt, bt)
            cs.stroke()
        }
        cs.restoreGraphicsState()
    }

    private fun drawMarkup(cs: PDPageContentStream, g: Geo, a: Annot, r: Int, gr: Int, b: Int) {
        cs.saveGraphicsState()
        setAlpha(cs, a.alpha, a.alpha)
        if (a.type == AnnotType.MARK_HIGHLIGHT) {
            cs.setNonStrokingColor(r, gr, b)
        } else {
            cs.setStrokingColor(r, gr, b)
            cs.setLineCapStyle(1)
            cs.setLineJoinStyle(1)
        }
        var i = 0
        while (i + 1 < a.points.size) {
            val p = a.points[i]
            val q = a.points[i + 1]
            i += 2
            val l = min(p.x, q.x)
            val rt = max(p.x, q.x)
            val t = min(p.y, q.y)
            val bt = max(p.y, q.y)
            if (a.type == AnnotType.MARK_HIGHLIGHT) {
                rectPath(cs, g, l, t, rt, bt)
                cs.fill()
                continue
            }
            val thick = if (a.width > 0f) max(0.5f, a.width * g.minSide) else max(0.6f, (bt - t) * g.dispH * 0.07f)
            cs.setLineWidth(thick)
            if (a.type == AnnotType.MARK_SQUIGGLY) {
                val amp = max(0.6f, thick * 1.2f)
                val w = wave(l * g.dispW, rt * g.dispW, bt * g.dispH + amp * 0.4f, amp, max(2.4f, amp * 4f))
                val first = Pt(w[0] / g.dispW, w[1] / g.dispH)
                cs.moveTo(g.x(first), g.y(first))
                for (k in 1 until w.size / 2) {
                    val pt = Pt(w[2 * k] / g.dispW, w[2 * k + 1] / g.dispH)
                    cs.lineTo(g.x(pt), g.y(pt))
                }
                cs.stroke()
            } else {
                val y = if (a.type == AnnotType.MARK_UNDERLINE) bt else (t + bt) / 2f
                val u = Pt(l, y)
                val v = Pt(rt, y)
                cs.moveTo(g.x(u), g.y(u))
                cs.lineTo(g.x(v), g.y(v))
                cs.stroke()
            }
        }
        cs.restoreGraphicsState()
    }

    private fun polyPath(cs: PDPageContentStream, g: Geo, v: List<Pt>) {
        cs.moveTo(g.x(v[0]), g.y(v[0]))
        for (k in 1 until v.size) cs.lineTo(g.x(v[k]), g.y(v[k]))
        cs.closePath()
    }

    /** The sticky-note icon, drawn like the on-screen one. */
    private fun drawNote(cs: PDPageContentStream, g: Geo, a: Annot, r: Int, gr: Int, b: Int) {
        val p = a.points.firstOrNull() ?: return
        val s = noteSize(g, a)
        val sx = s / g.dispW
        val sy = s / g.dispH
        fun at(u: Float, v: Float) = Pt(p.x + sx * u, p.y + sy * v)
        val fold = 0.28f
        val er = (r * 0.55f).toInt()
        val eg = (gr * 0.55f).toInt()
        val eb = (b * 0.55f).toInt()
        cs.saveGraphicsState()
        setAlpha(cs, a.alpha, a.alpha)
        cs.setNonStrokingColor(r, gr, b)
        cs.setStrokingColor(er, eg, eb)
        cs.setLineWidth(max(0.5f, s * 0.04f))
        cs.setLineJoinStyle(1)
        cs.setLineCapStyle(1)
        polyPath(cs, g, listOf(at(0f, 0f), at(1f, 0f), at(1f, 1f - fold), at(1f - fold, 1f), at(0f, 1f)))
        cs.fillAndStroke()
        cs.setNonStrokingColor(er, eg, eb)
        polyPath(cs, g, listOf(at(1f, 1f - fold), at(1f - fold, 1f), at(1f - fold, 1f - fold)))
        cs.fill()
        cs.setLineWidth(max(0.5f, s * 0.05f))
        for (k in 0..2) {
            val v = 0.28f + 0.2f * k
            val end = if (k == 2) 0.5f else 0.82f
            val u1 = at(0.18f, v)
            val u2 = at(end, v)
            cs.moveTo(g.x(u1), g.y(u1))
            cs.lineTo(g.x(u2), g.y(u2))
            cs.stroke()
        }
        cs.restoreGraphicsState()
    }

    private fun noteSize(g: Geo, a: Annot): Float = max(8f, a.width * g.minSide)

    private fun addNoteAnnotation(page: PDPage, g: Geo, a: Annot) {
        val p = a.points.firstOrNull() ?: return
        val s = noteSize(g, a)
        val corner = Pt(p.x + s / g.dispW, p.y + s / g.dispH)
        val x0 = g.x(p)
        val y0 = g.y(p)
        val x1 = g.x(corner)
        val y1 = g.y(corner)
        val note = PDAnnotationText()
        note.contents = a.text
        note.rectangle = PDRectangle(min(x0, x1), min(y0, y1), kotlin.math.abs(x1 - x0), kotlin.math.abs(y1 - y0))
        note.name = PDAnnotationText.NAME_NOTE
        page.annotations.add(note)
    }

    private fun drawShape(cs: PDPageContentStream, g: Geo, a: Annot, r: Int, gr: Int, b: Int) {
        if (a.points.size < 2) return
        val p = a.points[0]
        val q = a.points[1]
        val stroke = max(0.5f, a.width * g.minSide)
        cs.saveGraphicsState()
        val fillA = (a.fillAlpha * a.alpha).coerceIn(0f, 1f)
        setAlpha(cs, a.alpha, fillA)
        cs.setStrokingColor(r, gr, b)
        cs.setNonStrokingColor(r, gr, b)
        cs.setLineWidth(stroke)
        cs.setLineCapStyle(1)
        cs.setLineJoinStyle(1)

        fun seg(u: Pt, v: Pt) {
            cs.moveTo(g.x(u), g.y(u))
            cs.lineTo(g.x(v), g.y(v))
            cs.stroke()
        }

        /** Paints the path that was just built: fill (if any) and outline in one operation. */
        fun paint() {
            when {
                a.fillAlpha > 0f -> cs.fillAndStroke()
                else -> cs.stroke()
            }
        }

        when (a.type) {
            AnnotType.SHAPE_LINE, AnnotType.SHAPE_ARROW, AnnotType.SHAPE_DOUBLE_ARROW -> {
                setDash(cs, a.dash, stroke)
                seg(p, q)
                setDash(cs, 0, stroke)
                if (a.type != AnnotType.SHAPE_LINE) {
                    val (h1, h2) = arrowHead(g, p, q, stroke)
                    seg(q, h1)
                    seg(q, h2)
                }
                if (a.type == AnnotType.SHAPE_DOUBLE_ARROW) {
                    val (h1, h2) = arrowHead(g, q, p, stroke)
                    seg(p, h1)
                    seg(p, h2)
                }
            }
            AnnotType.SHAPE_RECT -> {
                setDash(cs, a.dash, stroke)
                rectPath(cs, g, min(p.x, q.x), min(p.y, q.y), max(p.x, q.x), max(p.y, q.y))
                paint()
            }
            AnnotType.SHAPE_TRIANGLE, AnnotType.SHAPE_DIAMOND -> {
                setDash(cs, a.dash, stroke)
                val l = min(p.x, q.x)
                val rt = max(p.x, q.x)
                val t = min(p.y, q.y)
                val bt = max(p.y, q.y)
                val cx = (l + rt) / 2f
                val cy = (t + bt) / 2f
                val v = if (a.type == AnnotType.SHAPE_TRIANGLE) {
                    listOf(Pt(cx, t), Pt(rt, bt), Pt(l, bt))
                } else {
                    listOf(Pt(cx, t), Pt(rt, cy), Pt(cx, bt), Pt(l, cy))
                }
                cs.moveTo(g.x(v[0]), g.y(v[0]))
                for (k in 1 until v.size) cs.lineTo(g.x(v[k]), g.y(v[k]))
                cs.closePath()
                paint()
            }
            AnnotType.SHAPE_OVAL -> {
                setDash(cs, a.dash, stroke)
                val cx = (p.x + q.x) / 2f
                val cy = (p.y + q.y) / 2f
                val rx = kotlin.math.abs(q.x - p.x) / 2f
                val ry = kotlin.math.abs(q.y - p.y) / 2f
                val k = 0.5523f
                fun cv(c1: Pt, c2: Pt, e: Pt) =
                    cs.curveTo(g.x(c1), g.y(c1), g.x(c2), g.y(c2), g.x(e), g.y(e))
                val start = Pt(cx + rx, cy)
                cs.moveTo(g.x(start), g.y(start))
                cv(Pt(cx + rx, cy + k * ry), Pt(cx + k * rx, cy + ry), Pt(cx, cy + ry))
                cv(Pt(cx - k * rx, cy + ry), Pt(cx - rx, cy + k * ry), Pt(cx - rx, cy))
                cv(Pt(cx - rx, cy - k * ry), Pt(cx - k * rx, cy - ry), Pt(cx, cy - ry))
                cv(Pt(cx + k * rx, cy - ry), Pt(cx + rx, cy - k * ry), Pt(cx + rx, cy))
                cs.closePath()
                paint()
            }
            else -> Unit
        }
        cs.restoreGraphicsState()
    }

    /** Two end points of an arrow head at [q]; computed in displayed-page points so it matches the on-screen shape. */
    private fun arrowHead(g: Geo, p: Pt, q: Pt, strokePt: Float): Pair<Pt, Pt> {
        val px = p.x * g.dispW
        val py = p.y * g.dispH
        val qx = q.x * g.dispW
        val qy = q.y * g.dispH
        val ang = atan2(qy - py, qx - px)
        val len = max(strokePt * 4f, g.minSide * 0.03f)
        fun at(delta: Float) = Pt((qx - len * cos(ang + delta)) / g.dispW, (qy - len * sin(ang + delta)) / g.dispH)
        return at(0.5f) to at(-0.5f)
    }

    private fun drawText(doc: PDDocument, cs: PDPageContentStream, g: Geo, a: Annot, r: Int, gr: Int, b: Int) {
        val anchor = a.points.firstOrNull() ?: return
        if (a.text.isBlank()) return
        val size = a.width * g.minSide
        val simple = a.text.all { it == '\n' || it.code in 32..126 }
        if (simple) {
            // Real, selectable text for plain Latin text
            cs.setNonStrokingColor(r, gr, b)
            cs.beginText()
            cs.setFont(PDType1Font.HELVETICA, size)
            a.text.split("\n").forEachIndexed { i, line ->
                cs.setTextMatrix(g.place(anchor, size * 0.85f + i * size * 1.2f))
                cs.showText(line)
            }
            cs.endText()
        } else {
            // Any other script (Arabic, Devanagari, CJK…): shape with Android's text engine, embed as an image
            val scale = 3f
            val paint = TextPaint(Paint.ANTI_ALIAS_FLAG).apply {
                color = a.color
                textSize = size * scale
            }
            val wPx = ceil(Layout.getDesiredWidth(a.text, paint)).toInt().coerceAtLeast(1) + 2
            val layout = StaticLayout.Builder.obtain(a.text, 0, a.text.length, paint, wPx).build()
            val bmp = Bitmap.createBitmap(wPx, layout.height.coerceAtLeast(1), Bitmap.Config.ARGB_8888)
            layout.draw(Canvas(bmp))
            val img = LosslessFactory.createFromImage(doc, bmp)
            val wPt = wPx / scale
            val hPt = bmp.height / scale
            cs.saveGraphicsState()
            cs.transform(g.place(anchor, hPt))
            cs.drawImage(img, 0f, 0f, wPt, hPt)
            cs.restoreGraphicsState()
        }
    }
}

/**
 * Collects one page's text in logical order with a rectangle per character.
 *
 * PDFBox delivers text one *word* at a time, with the characters already re-ordered into logical order
 * (important for Arabic/Hebrew) but the glyph positions still in drawing order, so for right-to-left words the
 * position list is walked backwards. Word and line gaps are recorded as ' ' and '\n' so phrases can match across them.
 */
internal class PageTextStripper : PDFTextStripper() {
    var result: PageText? = null
    private val buf = StringBuilder()
    private val pos = ArrayList<TextPosition?>()

    override fun startPage(page: PDPage) {
        buf.setLength(0)
        pos.clear()
        super.startPage(page)
    }

    override fun writeString(text: String, textPositions: MutableList<TextPosition>) {
        if (text.isEmpty() || textPositions.isEmpty()) return
        val n = text.length
        val m = textPositions.size
        val rtl = text.any { PageText.isRtl(it) }
        for (k in 0 until n) {
            var pi = when {
                n == m -> k
                n == 1 -> 0
                else -> ((k.toLong() * (m - 1)) / (n - 1)).toInt()
            }
            if (rtl) pi = m - 1 - pi
            buf.append(text[k])
            pos.add(textPositions[pi.coerceIn(0, m - 1)])
        }
    }

    override fun writeWordSeparator() {
        buf.append(' ')
        pos.add(null)
    }

    override fun writeLineSeparator() {
        buf.append('\n')
        pos.add(null)
    }

    override fun endPage(page: PDPage) {
        super.endPage(page)
        if (buf.isEmpty()) return
        val box = page.cropBox
        val rot = ((page.rotation % 360) + 360) % 360
        val dw = if (rot == 90 || rot == 270) box.height else box.width
        val dh = if (rot == 90 || rot == 270) box.width else box.height
        val rects = pos.map { tp ->
            tp?.let {
                NRect(
                    (it.xDirAdj / dw).coerceIn(0f, 1f),
                    ((it.yDirAdj - it.heightDir) / dh).coerceIn(0f, 1f),
                    ((it.xDirAdj + it.widthDirAdj) / dw).coerceIn(0f, 1f),
                    ((it.yDirAdj + it.heightDir * 0.25f) / dh).coerceIn(0f, 1f),
                )
            }
        }
        result = PageText(buf.toString(), rects)
    }
}

/**
 * Maps normalised display coordinates (origin top-left, as seen by the reader) to PDF user space and back,
 * taking the page's /CropBox and /Rotate into account.
 */
internal class Geo(page: PDPage) {
    private val rot = ((page.rotation % 360) + 360) % 360
    private val box = page.cropBox
    private val w = box.width
    private val h = box.height
    val dispW = if (rot == 90 || rot == 270) h else w
    val dispH = if (rot == 90 || rot == 270) w else h
    val minSide = min(dispW, dispH)

    // [rightX, rightY, downX, downY] unit vectors of the displayed page axes in PDF space
    private val vec: FloatArray = when (rot) {
        90 -> floatArrayOf(0f, 1f, 1f, 0f)
        180 -> floatArrayOf(-1f, 0f, 0f, 1f)
        270 -> floatArrayOf(0f, -1f, -1f, 0f)
        else -> floatArrayOf(1f, 0f, 0f, -1f)
    }
    private val ox = when (rot) {
        90 -> box.lowerLeftX
        180 -> box.lowerLeftX + w
        270 -> box.lowerLeftX + w
        else -> box.lowerLeftX
    }
    private val oy = when (rot) {
        90 -> box.lowerLeftY
        180 -> box.lowerLeftY
        270 -> box.lowerLeftY + h
        else -> box.lowerLeftY + h
    }

    fun x(p: Pt) = ox + vec[0] * p.x * dispW + vec[2] * p.y * dispH
    fun y(p: Pt) = oy + vec[1] * p.x * dispW + vec[3] * p.y * dispH

    /** PDF user-space point -> normalised display point. */
    fun toNorm(px: Float, py: Float): Pt {
        val dx = px - ox
        val dy = py - oy
        return Pt((dx * vec[0] + dy * vec[1]) / dispW, (dx * vec[2] + dy * vec[3]) / dispH)
    }

    /** Matrix that puts upright content with its top-left at [anchor], origin moved [offDown] points down. */
    fun place(anchor: Pt, offDown: Float) = Matrix(
        vec[0], vec[1], -vec[2], -vec[3],
        x(anchor) + vec[2] * offDown, y(anchor) + vec[3] * offDown,
    )
}
