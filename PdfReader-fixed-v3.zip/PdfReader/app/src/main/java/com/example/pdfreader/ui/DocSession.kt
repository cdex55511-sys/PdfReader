package com.example.pdfreader.ui

import android.content.Context
import androidx.compose.runtime.Stable
import androidx.compose.runtime.derivedStateOf
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableFloatStateOf
import androidx.compose.runtime.mutableIntStateOf
import androidx.compose.runtime.mutableStateMapOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.setValue
import com.example.pdfreader.data.Annot
import com.example.pdfreader.data.AnnotType
import com.example.pdfreader.data.BrushType
import com.example.pdfreader.data.DEFAULT_MARKUP_ALPHA
import com.example.pdfreader.data.Bookmark
import com.example.pdfreader.data.ColorMode
import com.example.pdfreader.data.DocMeta
import com.example.pdfreader.data.NRect
import com.example.pdfreader.data.OcrState
import com.example.pdfreader.data.OcrWord
import com.example.pdfreader.data.OutlineEntry
import com.example.pdfreader.data.PageLink
import com.example.pdfreader.data.PageSpec
import com.example.pdfreader.data.Pt
import com.example.pdfreader.data.SearchHit
import com.example.pdfreader.data.Store
import com.example.pdfreader.data.TextSelection
import com.example.pdfreader.data.alpha
import com.example.pdfreader.data.isClosedShape
import com.example.pdfreader.data.isLineShape
import com.example.pdfreader.data.translated
import com.example.pdfreader.data.ViewMode
import com.example.pdfreader.ocr.OcrData
import com.example.pdfreader.ocr.OcrRecognizer
import com.example.pdfreader.pdf.PageText
import com.example.pdfreader.pdf.PdfEditor
import com.example.pdfreader.pdf.PdfEngine
import com.example.pdfreader.pdf.PdfIndex
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.Job
import kotlinx.coroutines.NonCancellable
import kotlinx.coroutines.delay
import kotlinx.coroutines.ensureActive
import kotlinx.coroutines.flow.MutableSharedFlow
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext
import java.io.File
import java.util.UUID
import kotlin.coroutines.cancellation.CancellationException
import kotlin.math.max
import kotlin.math.min

enum class Tool {
    NONE, SELECT, PEN, HIGHLIGHT, AREA, TEXT, ERASER,
    LINE, ARROW, DOUBLE_ARROW, RECT, OVAL, TRIANGLE, DIAMOND,
    UNDERLINE, STRIKE, SQUIGGLY, NOTE,
}

/** Underline / strikethrough / squiggly: dragged across text, they mark the words under the finger. */
val Tool.isTextMarkup: Boolean get() = this == Tool.UNDERLINE || this == Tool.STRIKE || this == Tool.SQUIGGLY

fun Tool.markType(): AnnotType = when (this) {
    Tool.UNDERLINE -> AnnotType.MARK_UNDERLINE
    Tool.STRIKE -> AnnotType.MARK_STRIKE
    else -> AnnotType.MARK_SQUIGGLY
}

fun markStyleKey(type: AnnotType): StyleKey = when (type) {
    AnnotType.MARK_HIGHLIGHT -> StyleKey.HIGHLIGHT
    AnnotType.MARK_UNDERLINE -> StyleKey.UNDERLINE
    AnnotType.MARK_STRIKE -> StyleKey.STRIKE
    else -> StyleKey.SQUIGGLY
}

val Tool.isShape: Boolean
    get() = this == Tool.LINE || this == Tool.ARROW || this == Tool.DOUBLE_ARROW || this == Tool.RECT ||
        this == Tool.OVAL || this == Tool.TRIANGLE || this == Tool.DIAMOND

/** Tools that create something by dragging out two points (shapes and the area highlight). */
val Tool.isDragShape: Boolean get() = isShape || this == Tool.AREA

/** Which remembered style a tool uses; all shapes share one so colour and thickness carry between them. */
enum class StyleKey { PEN, HIGHLIGHT, AREA, TEXT, SHAPE, UNDERLINE, STRIKE, SQUIGGLY, NOTE }

val Tool.styleKey: StyleKey?
    get() = when {
        this == Tool.PEN -> StyleKey.PEN
        this == Tool.HIGHLIGHT -> StyleKey.HIGHLIGHT
        this == Tool.AREA -> StyleKey.AREA
        this == Tool.TEXT -> StyleKey.TEXT
        this == Tool.UNDERLINE -> StyleKey.UNDERLINE
        this == Tool.STRIKE -> StyleKey.STRIKE
        this == Tool.SQUIGGLY -> StyleKey.SQUIGGLY
        this == Tool.NOTE -> StyleKey.NOTE
        isShape -> StyleKey.SHAPE
        else -> null
    }

fun Tool.shapeType(): AnnotType = when (this) {
    Tool.LINE -> AnnotType.SHAPE_LINE
    Tool.ARROW -> AnnotType.SHAPE_ARROW
    Tool.DOUBLE_ARROW -> AnnotType.SHAPE_DOUBLE_ARROW
    Tool.RECT -> AnnotType.SHAPE_RECT
    Tool.TRIANGLE -> AnnotType.SHAPE_TRIANGLE
    Tool.DIAMOND -> AnnotType.SHAPE_DIAMOND
    Tool.AREA -> AnnotType.AREA
    else -> AnnotType.SHAPE_OVAL
}

/** Everything the style panel edits. [width] is a fraction of the page's shorter side. */
data class ToolStyle(
    val color: Int,
    val width: Float,
    val opacity: Float = 1f,
    val dash: Int = 0,
    val fill: Float = 0f,
    val brush: BrushType = BrushType.PEN,
)

private val DefaultStyles: Map<StyleKey, ToolStyle> = mapOf(
    StyleKey.PEN to ToolStyle(0xFF1E88E5.toInt(), 0.004f),
    StyleKey.HIGHLIGHT to ToolStyle(0xFFFFEB3B.toInt(), 0.032f, opacity = DEFAULT_MARKUP_ALPHA),
    StyleKey.AREA to ToolStyle(0xFFFFEB3B.toInt(), 0f, opacity = DEFAULT_MARKUP_ALPHA),
    StyleKey.TEXT to ToolStyle(0xFF111111.toInt(), 0.026f),
    StyleKey.SHAPE to ToolStyle(0xFFE53935.toInt(), 0.004f),
    StyleKey.UNDERLINE to ToolStyle(0xFF1E88E5.toInt(), 0.003f),
    StyleKey.STRIKE to ToolStyle(0xFFE53935.toInt(), 0.003f),
    StyleKey.SQUIGGLY to ToolStyle(0xFF43A047.toInt(), 0.003f),
    StyleKey.NOTE to ToolStyle(0xFFFFD54F.toInt(), 0.045f),
)

/** Sensible thickness range for the size slider. */
fun widthRange(key: StyleKey, brush: BrushType = BrushType.PEN): ClosedFloatingPointRange<Float> = when (key) {
    StyleKey.PEN -> when (brush) {
        BrushType.PEN -> 0.0015f..0.016f
        BrushType.BRUSH -> 0.004f..0.03f
        BrushType.MARKER -> 0.01f..0.05f
    }
    StyleKey.HIGHLIGHT -> 0.014f..0.06f
    StyleKey.AREA -> 0f..0.012f
    StyleKey.TEXT -> 0.012f..0.06f
    StyleKey.SHAPE -> 0.001f..0.02f
    StyleKey.UNDERLINE, StyleKey.STRIKE, StyleKey.SQUIGGLY -> 0.001f..0.012f
    StyleKey.NOTE -> 0.025f..0.09f
}

/** Switching brush also jumps to that brush's usual thickness and opacity. */
fun ToolStyle.withBrush(b: BrushType): ToolStyle = when (b) {
    BrushType.PEN -> copy(brush = b, width = 0.004f, opacity = 1f)
    BrushType.BRUSH -> copy(brush = b, width = 0.012f, opacity = 1f)
    BrushType.MARKER -> copy(brush = b, width = 0.024f, opacity = 0.55f)
}

fun Annot.styleKey(): StyleKey? = when (type) {
    AnnotType.INK -> StyleKey.PEN
    AnnotType.HIGHLIGHT -> StyleKey.HIGHLIGHT
    AnnotType.AREA -> StyleKey.AREA
    AnnotType.TEXT -> StyleKey.TEXT
    AnnotType.MARK_HIGHLIGHT -> null
    AnnotType.MARK_UNDERLINE -> StyleKey.UNDERLINE
    AnnotType.MARK_STRIKE -> StyleKey.STRIKE
    AnnotType.MARK_SQUIGGLY -> StyleKey.SQUIGGLY
    AnnotType.NOTE -> StyleKey.NOTE
    else -> StyleKey.SHAPE
}

fun Annot.toStyle() = ToolStyle(color, width, alpha, dash, fillAlpha, brush)

fun Annot.withStyle(s: ToolStyle): Annot = copy(
    color = s.color,
    width = if (styleKey() == null) width else s.width,
    opacity = if (type == AnnotType.TEXT) opacity else s.opacity,
    dash = if (type.isClosedShape || type.isLineShape) s.dash else dash,
    fillAlpha = if (type.isClosedShape) s.fill else fillAlpha,
    brush = if (type == AnnotType.INK) s.brush else brush,
)

data class TextEdit(val page: Int, val at: Pt, val existing: Annot?)

/** A sticky note being created ([existing] == null) or read / edited. */
data class NoteEdit(val page: Int, val at: Pt, val existing: Annot?)

/** Settings that follow the user across documents. */
object PenPrefs {
    /** How far above the fingertip a finger-drawn line is placed, in dp, so the fingertip doesn't hide it. */
    var fingerOffsetDp by mutableFloatStateOf(20f)
        private set

    private var loaded = false

    fun load(context: Context) {
        if (loaded) return
        loaded = true
        fingerOffsetDp = context.getSharedPreferences("prefs", Context.MODE_PRIVATE).getFloat("finger_offset", 20f)
    }

    fun setFingerOffset(context: Context, dp: Float) {
        fingerOffsetDp = dp
        context.getSharedPreferences("prefs", Context.MODE_PRIVATE).edit().putFloat("finger_offset", dp).apply()
    }
}

private const val OCR_WIDTH = 2000

/** Everything about one open document (= one tab). */
@Stable
class DocSession(
    initialMeta: DocMeta,
    initialEngine: PdfEngine,
    initialAnnots: List<Annot>,
    initialOcr: Map<Int, List<OcrWord>>,
    private val appContext: Context,
    private val store: Store,
    private val scope: CoroutineScope,
) {
    var meta by mutableStateOf(initialMeta); private set
    var engine by mutableStateOf(initialEngine); private set
    var annots by mutableStateOf(initialAnnots); private set

    val id: String get() = meta.id
    val annotsByPage: Map<Int, List<Annot>> by derivedStateOf { annots.groupBy { it.page } }

    val zoom = ZoomState()

    init {
        PenPrefs.load(appContext)
    }

    // ------------------------------------------------------------ navigation
    var currentPage by mutableIntStateOf(initialMeta.lastPage.coerceIn(0, (initialEngine.pageCount - 1).coerceAtLeast(0)))
        private set
    val jumps = MutableSharedFlow<Int>(extraBufferCapacity = 8)

    fun jump(page: Int) {
        val p = page.coerceIn(0, engine.pageCount - 1)
        currentPage = p
        jumps.tryEmit(p)
        scheduleSave()
    }

    fun stepPage(delta: Int) = jump(currentPage + delta)

    fun onPageChanged(page: Int) {
        if (page != currentPage && page in 0 until engine.pageCount) {
            currentPage = page
            meta = meta.copy(lastPage = page)
            scheduleSave()
        }
    }

    /** Set when a link was followed, so the reader can offer a way back to where it was. */
    var returnPage by mutableStateOf<Int?>(null); private set

    fun followLink(page: Int) {
        returnPage = currentPage
        jump(page)
    }

    fun goBackFromLink() {
        returnPage?.let { jump(it) }
        returnPage = null
    }

    fun dismissReturn() {
        returnPage = null
    }

    // ------------------------------------------------------------ auto-scroll
    var autoScroll by mutableStateOf(false)
    var autoSpeed by mutableFloatStateOf(0.35f)

    // ------------------------------------------------------------ view preferences
    fun setViewMode(mode: ViewMode) {
        meta = meta.copy(viewMode = mode, lastPage = currentPage)
        zoom.reset()
        scheduleSave()
    }

    fun rename(name: String) {
        meta = meta.copy(name = name)
        scheduleSave()
    }

    fun setFavorite(value: Boolean) {
        meta = meta.copy(favorite = value)
        scheduleSave()
    }

    fun setColorMode(mode: ColorMode) {
        meta = meta.copy(colorMode = mode)
        scheduleSave()
    }

    // ------------------------------------------------------------ bookmarks
    val isBookmarked: Boolean get() = meta.bookmarks.any { it.page == currentPage }

    fun toggleBookmark() {
        val existing = meta.bookmarks.firstOrNull { it.page == currentPage }
        meta = if (existing != null) {
            meta.copy(bookmarks = meta.bookmarks - existing)
        } else {
            meta.copy(
                bookmarks = (meta.bookmarks + Bookmark(currentPage, "Page ${currentPage + 1}", System.currentTimeMillis()))
                    .sortedBy { it.page },
            )
        }
        scheduleSave()
    }

    fun removeBookmark(b: Bookmark) {
        meta = meta.copy(bookmarks = meta.bookmarks - b)
        scheduleSave()
    }

    // ------------------------------------------------------------ annotation tools
    private var currentTool by mutableStateOf(Tool.NONE)
    var tool: Tool
        get() = currentTool
        set(value) {
            if (value != currentTool) {
                currentTool = value
                if (value != Tool.SELECT) selectedId = null
            }
        }
    var textEdit by mutableStateOf<TextEdit?>(null)
    var noteEdit by mutableStateOf<NoteEdit?>(null)

    /** Remembered look of each tool (colour, thickness, opacity, brush, fill, dash). */
    var styles by mutableStateOf(DefaultStyles)
        private set

    fun styleOf(key: StyleKey): ToolStyle = styles.getValue(key)

    fun updateStyle(key: StyleKey, change: (ToolStyle) -> ToolStyle) {
        styles = styles + (key to change(styles.getValue(key)))
    }

    /** Eraser radius in dp, and whether it cuts strokes apart (true) or removes whole annotations (false). */
    var eraserSize by mutableFloatStateOf(16f)
    var eraserPartial by mutableStateOf(true)

    /** Shapes: constrain lines to 45 degree steps and boxes/ovals to squares/circles. */
    var snapShapes by mutableStateOf(false)

    /** Builds a new annotation in the look of the current style for [key]. */
    fun styledAnnot(page: Int, type: AnnotType, key: StyleKey, points: List<Pt>, widths: List<Float> = emptyList(), text: String = ""): Annot {
        val st = styleOf(key)
        return Annot(
            id = UUID.randomUUID().toString(),
            page = page,
            type = type,
            color = st.color,
            width = st.width,
            points = points,
            text = text,
            opacity = st.opacity,
            fillAlpha = if (type.isClosedShape) st.fill else 0f,
            dash = if (type.isClosedShape || type.isLineShape) st.dash else 0,
            brush = if (type == AnnotType.INK) st.brush else BrushType.PEN,
            widths = widths,
        )
    }

    // ---- selecting and editing what has already been drawn
    var selectedId by mutableStateOf<String?>(null)
    val selectedAnnot: Annot? get() = selectedId?.let { id -> annots.firstOrNull { it.id == id } }

    private var coalesceId: String? = null
    private var coalesceAt = 0L

    /** Changes an annotation's look; quick successive changes (dragging a slider) become one undo step. */
    fun restyle(a: Annot) {
        val now = System.currentTimeMillis()
        val same = coalesceId == a.id && now - coalesceAt < 1500 && undoStack.isNotEmpty()
        if (same) {
            annots = annots.map { if (it.id == a.id) a else it }
            scheduleSave()
        } else {
            commit(annots.map { if (it.id == a.id) a else it })
        }
        coalesceId = a.id
        coalesceAt = now
    }

    /** Replaces annotations by id (an empty list deletes) as a single undo step; used by the part-eraser. */
    fun edit(replacements: Map<String, List<Annot>>) {
        if (replacements.isEmpty()) return
        commit(annots.flatMap { replacements[it.id] ?: listOf(it) })
    }

    fun deleteSelected() {
        val id = selectedId ?: return
        selectedId = null
        removeAnnots(setOf(id))
    }

    fun duplicateSelected() {
        val a = selectedAnnot ?: return
        val copy = a.translated(0.03f, 0.03f).copy(id = UUID.randomUUID().toString())
        commit(annots + copy)
        selectedId = copy.id
    }

    fun bringSelectedToFront() {
        val a = selectedAnnot ?: return
        commit(annots.filterNot { it.id == a.id } + a)
    }

    fun sendSelectedToBack() {
        val a = selectedAnnot ?: return
        commit(listOf(a) + annots.filterNot { it.id == a.id })
    }

    /** Opens the page holding [a] and selects it, ready to move or restyle. */
    fun revealAnnot(a: Annot) {
        tool = Tool.SELECT
        selectedId = a.id
        jump(a.page)
    }

    fun clearAnnotsOnPage(page: Int) {
        selectedId = null
        commit(annots.filterNot { it.page == page })
    }

    fun clearAllAnnots() {
        selectedId = null
        commit(emptyList())
    }

    private val undoStack = ArrayDeque<List<Annot>>()
    private val redoStack = ArrayDeque<List<Annot>>()
    var canUndo by mutableStateOf(false); private set
    var canRedo by mutableStateOf(false); private set

    private fun refreshUndo() {
        canUndo = undoStack.isNotEmpty()
        canRedo = redoStack.isNotEmpty()
    }

    private fun commit(newList: List<Annot>) {
        coalesceId = null
        undoStack.addLast(annots)
        if (undoStack.size > 100) undoStack.removeFirst()
        redoStack.clear()
        annots = newList
        refreshUndo()
        scheduleSave()
    }

    fun addAnnot(a: Annot) = commit(annots + a)

    fun replaceAnnot(a: Annot) = commit(annots.map { if (it.id == a.id) a else it })

    fun removeAnnots(ids: Set<String>) = commit(annots.filterNot { it.id in ids })

    fun undo() {
        val prev = undoStack.removeLastOrNull() ?: return
        redoStack.addLast(annots)
        annots = prev
        refreshUndo()
        scheduleSave()
    }

    fun redo() {
        val next = redoStack.removeLastOrNull() ?: return
        undoStack.addLast(annots)
        annots = next
        refreshUndo()
        scheduleSave()
    }

    // ------------------------------------------------------------ text, selection, links
    private var index = PdfIndex(appContext, store.pdf(initialMeta.id))
    private val texts = mutableStateMapOf<Int, PageText>()
    val links = mutableStateMapOf<Int, List<PageLink>>()

    fun textOf(page: Int): PageText? = texts[page]

    /** The page's text: the PDF's own text layer, or the OCR result for scanned pages. */
    private suspend fun loadText(page: Int): PageText {
        texts[page]?.let { return it }
        val idx = index
        val own = idx.text(page)
        val pt = if (!own.isBlank) own else ocr[page]?.let { PageText.fromWords(it) } ?: own
        if (idx === index) texts[page] = pt
        return pt
    }

    suspend fun ensureLinks(page: Int) {
        if (links.containsKey(page)) return
        val idx = index
        val l = idx.links(page)
        if (idx === index) links[page] = l
    }

    var selection by mutableStateOf<TextSelection?>(null); private set

    fun beginSelection(page: Int, nx: Float, ny: Float) {
        scope.launch {
            val pt = loadText(page)
            val aspect = engine.sizeOf(page)?.aspect ?: 1.4f
            val i = pt.indexAt(nx, ny, aspect)
            if (i < 0) return@launch
            val r = pt.wordRange(i)
            selection = TextSelection(page, r.first, r.last)
        }
    }

    /** Drag one end of the selection to the character nearest (nx, ny). */
    fun moveSelection(isStart: Boolean, nx: Float, ny: Float) {
        val s = selection ?: return
        val pt = texts[s.page] ?: return
        val aspect = engine.sizeOf(s.page)?.aspect ?: 1.4f
        val i = pt.indexAt(nx, ny, aspect)
        if (i < 0) return
        selection = if (isStart) s.copy(start = min(i, s.end)) else s.copy(end = max(i, s.start))
    }

    fun clearSelection() {
        selection = null
    }

    fun selectedText(): String? {
        val s = selection ?: return null
        return texts[s.page]?.textFor(s.start, s.end)
    }

    /** Makes an editable text-markup annotation from [rects] (one per line of text) in the current style. */
    fun addMarkup(page: Int, type: AnnotType, rects: List<NRect>) {
        if (rects.isEmpty()) return
        val st = styleOf(markStyleKey(type))
        addAnnot(
            Annot(
                id = UUID.randomUUID().toString(),
                page = page,
                type = type,
                color = st.color,
                width = if (type == AnnotType.MARK_HIGHLIGHT) 0f else st.width,
                points = rects.flatMap { listOf(Pt(it.l, it.t), Pt(it.r, it.b)) },
                opacity = st.opacity,
            ),
        )
    }

    /** Turns the selection into an editable text-markup annotation. */
    fun markSelection(type: AnnotType) {
        val s = selection ?: return
        val rects: List<NRect> = texts[s.page]?.rectsFor(s.start, s.end).orEmpty()
        if (rects.isEmpty()) return
        addMarkup(s.page, type, rects)
        selection = null
    }

    /** Reads the page's text so markup tools can snap to words. */
    suspend fun ensureText(page: Int) {
        if (!texts.containsKey(page)) loadText(page)
    }

    // ------------------------------------------------------------ OCR
    var ocr by mutableStateOf(initialOcr); private set
    var ocrState by mutableStateOf<OcrState?>(null); private set
    var ocrMessage by mutableStateOf<String?>(null); private set
    private var ocrJob: Job? = null

    /** Recognises every page that has no text layer of its own. Results are kept and used by search and selection. */
    fun startOcr(language: String) {
        if (ocrJob?.isActive == true) return
        ocrMessage = null
        val spec = if (language != "eng" && OcrData.has(appContext, "eng")) "$language+eng" else language
        ocrJob = scope.launch {
            val total = engine.pageCount
            ocrState = OcrState(0, total, language)
            var recognizer: OcrRecognizer? = null
            try {
                val rec = withContext(Dispatchers.Default) { OcrRecognizer.create(appContext, spec) }
                recognizer = rec
                val result = HashMap(ocr)
                var added = 0
                for (p in 0 until total) {
                    ensureActive()
                    ocrState = OcrState(p, total, language)
                    if (result.containsKey(p)) continue
                    if (!index.text(p).isBlank) continue
                    val bmp = engine.renderUncached(p, OCR_WIDTH)
                    val words = try {
                        withContext(Dispatchers.Default) { rec.recognize(bmp) }
                    } finally {
                        bmp.recycle()
                    }
                    result[p] = words
                    added++
                    ocr = HashMap(result)
                    texts.remove(p)
                }
                ocrMessage = if (added == 0) "Nothing to recognise: every page already has text." else "Recognised $added page(s)."
            } catch (e: CancellationException) {
                ocrMessage = "Stopped."
                throw e
            } catch (t: Throwable) {
                ocrMessage = t.message ?: "OCR failed."
            } finally {
                recognizer?.close()
                withContext(NonCancellable + Dispatchers.IO) {
                    store.saveOcr(id, ocr)
                }
                meta = meta.copy(ocrLang = language)
                scheduleSave()
                ocrState = null
            }
        }
    }

    fun cancelOcr() {
        ocrJob?.cancel()
    }

    fun clearOcr() {
        ocrJob?.cancel()
        ocr = emptyMap()
        texts.clear()
        scope.launch(Dispatchers.IO) { store.saveOcr(id, emptyMap()) }
    }

    // ------------------------------------------------------------ persistence
    private var saveJob: Job? = null

    private fun scheduleSave() {
        saveJob?.cancel()
        saveJob = scope.launch {
            delay(600)
            val m = meta
            val a = annots
            withContext(Dispatchers.IO) {
                store.saveMeta(m)
                store.saveAnnots(m.id, a)
            }
        }
    }

    /** Synchronous save; used when leaving the document or the app. */
    fun flush() {
        saveJob?.cancel()
        runCatching {
            store.saveMeta(meta.copy(lastPage = currentPage))
            store.saveAnnots(id, annots)
        }
    }

    fun close() {
        searchJob?.cancel()
        ocrJob?.cancel()
        flush()
        val e = engine
        val ix = index
        scope.launch {
            e.close()
            ix.close()
        }
    }

    // ------------------------------------------------------------ outline
    var outline by mutableStateOf<List<OutlineEntry>?>(null); private set

    suspend fun ensureOutline(context: Context) {
        if (outline == null) outline = PdfEditor.outline(context, store.pdf(id))
    }

    // ------------------------------------------------------------ search
    var searchQuery by mutableStateOf("")
    var searchHits by mutableStateOf<List<SearchHit>>(emptyList()); private set
    var searchIndex by mutableIntStateOf(-1); private set
    var searching by mutableStateOf(false); private set
    private var searchJob: Job? = null

    fun search(context: Context, query: String) {
        searchJob?.cancel()
        searchQuery = query
        searchHits = emptyList()
        searchIndex = -1
        val q = query.trim()
        if (q.isEmpty()) {
            searching = false
            return
        }
        searching = true
        searchJob = scope.launch {
            var pdfHits: List<SearchHit> = emptyList()
            try {
                PdfEditor.search(context, store.pdf(id), q) { hits ->
                    pdfHits = hits
                    searchHits = hits
                    if (searchIndex < 0 && hits.isNotEmpty()) searchIndex = 0
                }
                // Scanned pages have no text layer, so search the OCR results as well
                val normalized = q.replace(Regex("\\s+"), " ")
                val ocrHits = withContext(Dispatchers.Default) {
                    ocr.entries.sortedBy { it.key }.flatMap { (p, words) -> PageText.fromWords(words).find(normalized, p) }
                }
                if (ocrHits.isNotEmpty()) {
                    searchHits = (pdfHits + ocrHits).sortedBy { it.page }
                    if (searchIndex < 0) searchIndex = 0
                }
            } catch (e: CancellationException) {
                throw e
            } catch (_: Throwable) {
                // text extraction can fail on damaged files; keep what we have
            } finally {
                searching = false
            }
        }
    }

    fun clearSearch() {
        searchJob?.cancel()
        searchQuery = ""
        searchHits = emptyList()
        searchIndex = -1
        searching = false
    }

    fun gotoHit(i: Int) {
        if (searchHits.isEmpty()) return
        val n = ((i % searchHits.size) + searchHits.size) % searchHits.size
        searchIndex = n
        jump(searchHits[n].page)
    }

    // ------------------------------------------------------------ page operations
    private fun replaceFile(tmp: File) {
        val dst = store.pdf(id)
        if (!tmp.renameTo(dst)) {
            tmp.copyTo(dst, overwrite = true)
            tmp.delete()
        }
        meta = meta.copy(sizeBytes = dst.length())
    }

    private suspend fun reopenEngine() {
        val old = engine
        val oldIndex = index
        engine = PdfEngine.open(store.pdf(id))
        index = PdfIndex(appContext, store.pdf(id))
        texts.clear()
        links.clear()
        selection = null
        scope.launch {
            old.close()
            oldIndex.close()
        }
        outline = null
        clearSearch()
    }

    /** Applies reorder / delete / rotate / blank-insert in one go and remaps annotations, OCR and bookmarks. */
    suspend fun applyPlan(context: Context, plan: List<PageSpec>) {
        require(plan.isNotEmpty()) { "A document needs at least one page" }
        val tmp = File(store.dir(id), "edit.tmp")
        PdfEditor.build(context, store.pdf(id), plan, tmp)
        replaceFile(tmp)

        val newIndexOf = HashMap<Int, Int>()
        val rotationOf = HashMap<Int, Int>()
        plan.forEachIndexed { i, s ->
            if (s.src >= 0) {
                newIndexOf[s.src] = i
                rotationOf[s.src] = s.rotate
            }
        }
        annots = annots.mapNotNull { a ->
            val n = newIndexOf[a.page] ?: return@mapNotNull null
            val rot = rotationOf[a.page] ?: 0
            a.copy(page = n, points = a.points.map { rotatePt(it, rot) })
        }
        // Recognised text is dropped for rotated pages (its boxes would no longer line up); it can simply be re-run
        val remappedOcr = HashMap<Int, List<OcrWord>>()
        ocr.forEach { (old, words) ->
            val n = newIndexOf[old]
            if (n != null && (rotationOf[old] ?: 0) == 0) remappedOcr[n] = words
        }
        ocr = remappedOcr
        withContext(Dispatchers.IO) { store.saveOcr(id, remappedOcr) }

        val bookmarks = meta.bookmarks.mapNotNull { b -> newIndexOf[b.page]?.let { b.copy(page = it) } }
            .sortedBy { it.page }

        reopenEngine()
        undoStack.clear()
        redoStack.clear()
        refreshUndo()
        meta = meta.copy(bookmarks = bookmarks, pageCount = engine.pageCount)
        currentPage = currentPage.coerceIn(0, engine.pageCount - 1)
        zoom.reset()
        scheduleSave()
    }

    suspend fun merge(context: Context, others: List<File>) {
        val tmp = File(store.dir(id), "merge.tmp")
        PdfEditor.merge(context, store.pdf(id), others, tmp)
        replaceFile(tmp)
        reopenEngine()
        meta = meta.copy(pageCount = engine.pageCount)
        scheduleSave()
    }

    /** Writes the PDF (with annotations baked in, and encrypted when [password] is given) to [dst]. */
    suspend fun exportTo(context: Context, dst: File, password: String? = null) {
        withContext(Dispatchers.IO) {
            if (annots.isEmpty() && password.isNullOrEmpty()) {
                store.pdf(id).copyTo(dst, overwrite = true)
            } else {
                PdfEditor.exportWithAnnotations(context, store.pdf(id), annots, dst, password)
            }
        }
    }

    private fun rotatePt(p: Pt, clockwiseDegrees: Int): Pt = when (((clockwiseDegrees % 360) + 360) % 360) {
        90 -> Pt(1f - p.y, p.x)
        180 -> Pt(1f - p.x, 1f - p.y)
        270 -> Pt(p.y, 1f - p.x)
        else -> p
    }
}
