package com.example.pdfreader.ui

import androidx.compose.foundation.horizontalScroll
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.verticalScroll
import androidx.compose.material3.AlertDialog
import androidx.compose.material3.FilterChip
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableIntStateOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Modifier
import androidx.compose.ui.unit.dp
import com.example.pdfreader.data.NotebookPaper
import com.example.pdfreader.data.PageTemplate
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale

/** Asks what kind of blank notebook to create. */
@Composable
fun NewNotebookDialog(
    onCreate: (name: String, paper: NotebookPaper, landscape: Boolean, template: PageTemplate, pages: Int) -> Unit,
    onDismiss: () -> Unit,
) {
    var name by remember { mutableStateOf("Notebook " + SimpleDateFormat("d MMM, HH:mm", Locale.getDefault()).format(Date())) }
    var paper by remember { mutableStateOf(NotebookPaper.A4) }
    var landscape by remember { mutableStateOf(false) }
    var template by remember { mutableStateOf(PageTemplate.GRID) }
    var pages by remember { mutableIntStateOf(1) }

    AlertDialog(
        onDismissRequest = onDismiss,
        title = { Text("New notebook") },
        text = {
            Column(Modifier.verticalScroll(rememberScrollState()), verticalArrangement = Arrangement.spacedBy(8.dp)) {
                Text(
                    "A blank PDF for rough work and sketches. Write with the pen, add pages as you need them, and export it as a PDF any time.",
                    style = MaterialTheme.typography.bodySmall,
                    color = MaterialTheme.colorScheme.onSurfaceVariant,
                )
                OutlinedTextField(value = name, onValueChange = { name = it }, label = { Text("Name") }, singleLine = true)
                Text("Paper pattern", style = MaterialTheme.typography.labelLarge)
                Row(Modifier.horizontalScroll(rememberScrollState()), horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                    PageTemplate.entries.forEach { t ->
                        FilterChip(selected = template == t, onClick = { template = t }, label = { Text(t.label) })
                    }
                }
                Text("Paper size", style = MaterialTheme.typography.labelLarge)
                Row(Modifier.horizontalScroll(rememberScrollState()), horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                    NotebookPaper.entries.forEach { p ->
                        FilterChip(selected = paper == p, onClick = { paper = p }, label = { Text(p.label) })
                    }
                }
                Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                    FilterChip(selected = !landscape, onClick = { landscape = false }, label = { Text("Portrait") })
                    FilterChip(selected = landscape, onClick = { landscape = true }, label = { Text("Landscape") })
                }
                Text("Starting pages", style = MaterialTheme.typography.labelLarge)
                Row(Modifier.horizontalScroll(rememberScrollState()), horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                    listOf(1, 3, 5, 10, 20).forEach { n ->
                        FilterChip(selected = pages == n, onClick = { pages = n }, label = { Text("$n") })
                    }
                }
            }
        },
        confirmButton = {
            TextButton(onClick = { onCreate(name, paper, landscape, template, pages) }) { Text("Create") }
        },
        dismissButton = { TextButton(onClick = onDismiss) { Text("Cancel") } },
    )
}
