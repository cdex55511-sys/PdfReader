package com.example.pdfreader.data

import kotlinx.serialization.Serializable

@Serializable
data class Bookmark(val page: Int, val title: String, val createdAt: Long)

@Serializable
enum class ViewMode(val label: String) {
    CONTINUOUS("Continuous scroll"),
    PAGED_HORIZONTAL("Page by page (swipe sideways)"),
    PAGED_VERTICAL("Page by page (swipe up/down)"),
}

@Serializable
enum class ColorMode(val label: String) {
    DAY("Day"),
    NIGHT("Night"),
    SEPIA("Sepia"),
    WARM("Warm"),
    GRAY("Grayscale"),
}

/** Persisted per-document state. The working copy of the PDF lives next to it in the library folder. */
@Serializable
data class DocMeta(
    val id: String,
    val name: String,
    val sizeBytes: Long,
    val pageCount: Int = 0,
    val lastOpened: Long,
    val lastPage: Int = 0,
    val favorite: Boolean = false,
    val viewMode: ViewMode = ViewMode.CONTINUOUS,
    val colorMode: ColorMode = ColorMode.DAY,
    val bookmarks: List<Bookmark> = emptyList(),
    val ocrLang: String? = null,
    /** Set for notebooks created in the app: the paper pattern used when pages are added. */
    val template: PageTemplate? = null,
)

/** Paper pattern of a notebook page. */
@Serializable
enum class PageTemplate(val label: String) {
    BLANK("Blank"),
    LINED("Lined"),
    GRID("Grid"),
    DOTS("Dotted"),
}

/** Paper sizes for new notebooks, in PDF points. */
enum class NotebookPaper(val label: String, val width: Float, val height: Float) {
    A4("A4", 595f, 842f),
    A5("A5", 420f, 595f),
    LETTER("Letter", 612f, 792f),
    SQUARE("Square", 600f, 600f),
}

@Serializable
enum class AnnotType {
    INK, HIGHLIGHT, TEXT,

    /** Text markup made from a selection; [Annot.points] holds (top-left, bottom-right) pairs, one pair per line. */
    MARK_HIGHLIGHT, MARK_UNDERLINE, MARK_STRIKE, MARK_SQUIGGLY,

    /** Shapes; [Annot.points] holds the two corner / end points. */
    SHAPE_LINE, SHAPE_ARROW, SHAPE_RECT, SHAPE_OVAL,
    SHAPE_DOUBLE_ARROW, SHAPE_TRIANGLE, SHAPE_DIAMOND,

    /** A translucent filled rectangle (area highlight); [Annot.width] > 0 adds an outline. Points = two corners. */
    AREA,

    /** A sticky note: an icon whose top-left is the single point, [Annot.width] its size, [Annot.text] its content. */
    NOTE,
}

/** How a freehand INK stroke is drawn. */
@Serializable
enum class BrushType(val label: String) {
    /** Even round line. */
    PEN("Pen"),

    /** Width follows speed (slow = thick, fast = thin) or stylus pressure, like a calligraphy brush. */
    BRUSH("Brush"),

    /** Wide, flat-ended and translucent, like a felt marker. */
    MARKER("Marker"),
}

/** Point normalised to the displayed page: x, y in 0..1, origin top-left. */
@Serializable
data class Pt(val x: Float, val y: Float)

/**
 * An annotation stored as an editable overlay (not yet baked into the PDF).
 * [width] is a fraction of the page's shorter side (stroke width, or font size for TEXT),
 * which keeps it stable when a page is rotated.
 */
@Serializable
data class Annot(
    val id: String,
    val page: Int,
    val type: AnnotType,
    val color: Int,
    val width: Float,
    val points: List<Pt>,
    val text: String = "",
    /** Stroke/fill opacity 0..1; negative = the type's default (see [alpha]). */
    val opacity: Float = -1f,
    /** Interior fill of closed shapes: 0 = none, otherwise the fill's opacity (multiplied by [opacity]). */
    val fillAlpha: Float = 0f,
    /** 0 solid, 1 dashed, 2 dotted (lines and shapes). */
    val dash: Int = 0,
    val brush: BrushType = BrushType.PEN,
    /** BRUSH strokes: width multiplier per point (parallel to [points]); empty = uniform. */
    val widths: List<Float> = emptyList(),
)

const val DEFAULT_MARKUP_ALPHA = 0.35f

/** The opacity actually used for drawing and export. */
val Annot.alpha: Float
    get() = if (opacity >= 0f) opacity.coerceIn(0.05f, 1f) else when (type) {
        AnnotType.HIGHLIGHT, AnnotType.MARK_HIGHLIGHT, AnnotType.AREA -> DEFAULT_MARKUP_ALPHA
        else -> 1f
    }

/** Text markup made from rectangles (one pair of points per line of text). */
val AnnotType.isMarkup: Boolean
    get() = this == AnnotType.MARK_HIGHLIGHT || this == AnnotType.MARK_UNDERLINE ||
        this == AnnotType.MARK_STRIKE || this == AnnotType.MARK_SQUIGGLY

val AnnotType.isClosedShape: Boolean
    get() = this == AnnotType.SHAPE_RECT || this == AnnotType.SHAPE_OVAL ||
        this == AnnotType.SHAPE_TRIANGLE || this == AnnotType.SHAPE_DIAMOND

val AnnotType.isLineShape: Boolean
    get() = this == AnnotType.SHAPE_LINE || this == AnnotType.SHAPE_ARROW || this == AnnotType.SHAPE_DOUBLE_ARROW

data class OutlineEntry(val title: String, val page: Int, val level: Int)

data class NRect(val l: Float, val t: Float, val r: Float, val b: Float)

data class SearchHit(val page: Int, val snippet: String, val rects: List<NRect>)

/** One page of a rebuilt document. [src] = index in the current file, or -1 for a new blank page. */
data class PageSpec(val src: Int, val rotate: Int, val template: PageTemplate? = null)

/** A tappable link on a page: [page] >= 0 is an internal jump, otherwise [uri] is external. */
data class PageLink(val rect: NRect, val page: Int, val uri: String?)

/** One recognised word. Coordinates are fractions of the page (0..1, origin top-left). */
@Serializable
data class OcrWord(val t: String, val l: Float, val top: Float, val r: Float, val b: Float)

/** Inclusive character range selected on [page] (indices into that page's PageText). */
data class TextSelection(val page: Int, val start: Int, val end: Int)

data class OcrState(val done: Int, val total: Int, val language: String)
