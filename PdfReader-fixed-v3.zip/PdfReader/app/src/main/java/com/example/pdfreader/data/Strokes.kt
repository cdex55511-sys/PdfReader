package com.example.pdfreader.data

import kotlin.math.hypot
import kotlin.math.PI
import kotlin.math.max
import kotlin.math.min
import kotlin.math.sin
import kotlin.math.sqrt

/**
 * Geometry helpers for annotations that don't depend on Compose or PDFBox, so the on-screen drawing and the PDF
 * export use exactly the same numbers.
 */

internal fun segDist(px: Float, py: Float, ax: Float, ay: Float, bx: Float, by: Float): Float {
    val dx = bx - ax
    val dy = by - ay
    val len2 = dx * dx + dy * dy
    if (len2 == 0f) return hypot(px - ax, py - ay)
    val t = (((px - ax) * dx + (py - ay) * dy) / len2).coerceIn(0f, 1f)
    return hypot(px - (ax + t * dx), py - (ay + t * dy))
}

/** Both edges of a variable-width stroke, in the pixel (or point) space given by [w] x [h]. */
class Ribbon(val left: List<Pt>, val right: List<Pt>)

/**
 * Turns a centre line plus per-point width multipliers into the two outline edges of a stroke whose full width at a
 * point is [base] * multiplier.
 */
fun ribbon(pts: List<Pt>, mult: List<Float>, base: Float, w: Float, h: Float): Ribbon {
    val left = ArrayList<Pt>(pts.size)
    val right = ArrayList<Pt>(pts.size)
    var nx = 0f
    var ny = -1f
    for (i in pts.indices) {
        val a = pts[max(i - 1, 0)]
        val b = pts[min(i + 1, pts.size - 1)]
        val dx = (b.x - a.x) * w
        val dy = (b.y - a.y) * h
        val len = sqrt(dx * dx + dy * dy)
        if (len > 1e-4f) {
            nx = -dy / len
            ny = dx / len
        }
        val half = base * mult.getOrElse(i) { 1f } / 2f
        val cx = pts[i].x * w
        val cy = pts[i].y * h
        left += Pt(cx + nx * half, cy + ny * half)
        right += Pt(cx - nx * half, cy - ny * half)
    }
    return Ribbon(left, right)
}

/**
 * Removes the part of a freehand stroke inside the circle ([cx], [cy], [r]) (pixels of a [w] x [h] page) and returns
 * what is left as separate strokes. Returns `listOf(a)` (the same instance) when nothing was touched.
 */
fun splitStroke(a: Annot, cx: Float, cy: Float, r: Float, w: Float, h: Float): List<Annot> {
    val pts = a.points
    if (pts.size < 2) return listOf(a)
    val out = ArrayList<Annot>()
    var run = ArrayList<Int>()
    var touched = false

    fun flush() {
        if (run.size >= 2) {
            out += a.copy(
                points = run.map { pts[it] },
                widths = if (a.widths.size == pts.size) run.map { a.widths[it] } else emptyList(),
            )
        }
        run = ArrayList()
    }

    for (i in pts.indices) {
        val x = pts[i].x * w
        val y = pts[i].y * h
        val keep = hypot(x - cx, y - cy) > r
        if (!keep) {
            touched = true
            flush()
            continue
        }
        if (run.isNotEmpty()) {
            val p = pts[run.last()]
            if (segDist(cx, cy, p.x * w, p.y * h, x, y) <= r) {
                touched = true
                flush()
            }
        }
        run.add(i)
    }
    flush()
    return if (touched) out else listOf(a)
}

/** Bounding box of the annotation's points (normalised); TEXT is measured by the UI instead. */
fun Annot.pointBounds(): NRect? {
    if (points.isEmpty()) return null
    var l = Float.MAX_VALUE
    var t = Float.MAX_VALUE
    var r = -Float.MAX_VALUE
    var b = -Float.MAX_VALUE
    for (p in points) {
        l = min(l, p.x); r = max(r, p.x)
        t = min(t, p.y); b = max(b, p.y)
    }
    return NRect(l, t, r, b)
}

fun Annot.translated(dx: Float, dy: Float): Annot = copy(points = points.map { Pt(it.x + dx, it.y + dy) })

/** Scales the geometry about ([ax], [ay]); TEXT grows its font size by the average factor instead of distorting. */
fun Annot.scaledAbout(ax: Float, ay: Float, sx: Float, sy: Float): Annot {
    val moved = points.map { Pt(ax + (it.x - ax) * sx, ay + (it.y - ay) * sy) }
    return if (type == AnnotType.TEXT || type == AnnotType.NOTE) {
        copy(points = moved, width = (width * (sx + sy) / 2f).coerceIn(0.006f, 0.2f))
    } else {
        copy(points = moved)
    }
}

/** Keeps a moved annotation from being dragged completely off its page. */
fun Annot.clampedInto(b: NRect, dx: Float, dy: Float): Pair<Float, Float> {
    val ndx = dx.coerceIn(-b.r + 0.02f, 1f - b.l - 0.02f)
    val ndy = dy.coerceIn(-b.b + 0.02f, 1f - b.t - 0.02f)
    return ndx to ndy
}

/**
 * Points of a sine wave from [x0] to [x1] around the baseline [y], as x0,y0,x1,y1,... in the caller's units
 * (the squiggly underline); the same samples are used on screen and in the exported PDF.
 */
fun wave(x0: Float, x1: Float, y: Float, amp: Float, wavelength: Float): FloatArray {
    val length = max(x1 - x0, 0f)
    val n = max(2, (length / (max(wavelength, 1f) / 6f)).toInt() + 1)
    val out = FloatArray(n * 2)
    for (i in 0 until n) {
        val x = x0 + length * i / (n - 1f)
        out[2 * i] = x
        out[2 * i + 1] = y + amp * sin((x - x0) / max(wavelength, 1f) * 2f * PI.toFloat())
    }
    return out
}
