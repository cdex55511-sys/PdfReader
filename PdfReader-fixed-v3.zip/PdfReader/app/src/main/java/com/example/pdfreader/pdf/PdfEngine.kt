package com.example.pdfreader.pdf

import android.graphics.Bitmap
import android.graphics.Color
import android.graphics.pdf.PdfRenderer
import android.os.ParcelFileDescriptor
import android.util.LruCache
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableIntStateOf
import androidx.compose.runtime.setValue
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.sync.Mutex
import kotlinx.coroutines.sync.withLock
import kotlinx.coroutines.withContext
import java.io.File
import kotlin.coroutines.cancellation.CancellationException
import kotlin.math.roundToInt

/**
 * Rendering engine on top of the platform PdfRenderer (PDFium).
 *
 * - Page sizes are known up-front for normal documents (see [sizeOf] for how huge ones are handled).
 * - Rendering happens off the main thread; PdfRenderer allows one open page at a time, so renders are serialised.
 * - Bitmaps are cached in a size-bounded LRU keyed by (page, width).
 */
class PdfEngine private constructor(
    private val pfd: ParcelFileDescriptor,
    private val renderer: PdfRenderer,
    private val widths: FloatArray,
    private val heights: FloatArray,
    private val known: BooleanArray,
) {
    data class PageSize(val width: Float, val height: Float) {
        val aspect: Float get() = height / width
    }

    val pageCount: Int get() = widths.size

    /**
     * Small documents have every page size read up-front. For very large ones only the first page is read and the
     * rest are assumed equal until they are rendered, at which point the real size replaces the guess and
     * [sizeVersion] changes so layouts re-read it. This keeps opening a 5000-page PDF instant.
     */
    private var sizeVersion by mutableIntStateOf(0)

    fun sizeOf(page: Int): PageSize? {
        sizeVersion // read so Compose recomposes when a guessed size is corrected
        if (page !in widths.indices) return null
        return PageSize(widths[page], heights[page])
    }

    private val mutex = Mutex()
    @Volatile private var closed = false

    private val cache = object : LruCache<String, Bitmap>((Runtime.getRuntime().maxMemory() / 5).toInt()) {
        override fun sizeOf(key: String, value: Bitmap): Int = value.byteCount
    }

    private fun key(page: Int, widthPx: Int) = "$page:$widthPx"

    fun cached(page: Int, widthPx: Int): Bitmap? = cache.get(key(page, widthPx))

    /** Drops cached bitmaps (called when the system reports memory pressure); pages simply re-render. */
    fun trimMemory() {
        cache.evictAll()
    }

    suspend fun render(page: Int, widthPx: Int): Bitmap {
        val k = key(page, widthPx)
        cache.get(k)?.let { return it }
        return withContext(Dispatchers.Default) {
            mutex.withLock {
                cache.get(k) ?: run {
                    if (closed) throw CancellationException("engine closed")
                    val bmp = try {
                        renderLocked(page, widthPx)
                    } catch (e: OutOfMemoryError) {
                        // Free every cached bitmap and try once more before giving up on this page
                        cache.evictAll()
                        renderLocked(page, widthPx)
                    }
                    bmp.also { cache.put(k, it) }
                }
            }
        }
    }

    /** Renders without caching (for OCR, where large one-off bitmaps would only evict useful ones). */
    suspend fun renderUncached(page: Int, widthPx: Int): Bitmap = withContext(Dispatchers.Default) {
        mutex.withLock {
            if (closed) throw CancellationException("engine closed")
            renderLocked(page, widthPx)
        }
    }

    private fun renderLocked(page: Int, widthPx: Int): Bitmap =
        renderer.openPage(page).use { p ->
            val pw = p.width.toFloat()
            val ph = p.height.toFloat()
            val h = (widthPx * ph / pw).roundToInt().coerceAtLeast(1)
            val bmp = Bitmap.createBitmap(widthPx, h, Bitmap.Config.ARGB_8888)
            bmp.eraseColor(Color.WHITE) // PdfRenderer requires an opaque white background
            p.render(bmp, null, null, PdfRenderer.Page.RENDER_MODE_FOR_DISPLAY)
            if (!known[page] || widths[page] != pw || heights[page] != ph) {
                widths[page] = pw
                heights[page] = ph
                known[page] = true
                sizeVersion++
            }
            bmp
        }

    suspend fun close() {
        mutex.withLock {
            if (closed) return
            closed = true
            cache.evictAll()
            runCatching { renderer.close() }
            runCatching { pfd.close() }
        }
    }

    companion object {
        const val THUMB_WIDTH = 240
        private const val EAGER_SIZE_LIMIT = 300

        /**
         * @throws SecurityException if the file is password protected
         * @throws java.io.IOException if the file is corrupt
         */
        suspend fun open(file: File): PdfEngine = withContext(Dispatchers.IO) {
            val pfd = ParcelFileDescriptor.open(file, ParcelFileDescriptor.MODE_READ_ONLY)
            try {
                val r = PdfRenderer(pfd)
                val n = r.pageCount
                val w = FloatArray(n)
                val h = FloatArray(n)
                val known = BooleanArray(n)
                val eager = if (n <= EAGER_SIZE_LIMIT) n else 1
                for (i in 0 until eager) {
                    r.openPage(i).use {
                        w[i] = it.width.toFloat()
                        h[i] = it.height.toFloat()
                        known[i] = true
                    }
                }
                for (i in eager until n) {
                    w[i] = w[0]
                    h[i] = h[0]
                }
                PdfEngine(pfd, r, w, h, known)
            } catch (t: Throwable) {
                runCatching { pfd.close() }
                throw t
            }
        }
    }
}
