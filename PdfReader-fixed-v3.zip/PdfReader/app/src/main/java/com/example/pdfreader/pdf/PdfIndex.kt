package com.example.pdfreader.pdf

import android.content.Context
import android.util.LruCache
import com.example.pdfreader.data.NRect
import com.example.pdfreader.data.PageLink
import com.tom_roush.pdfbox.io.MemoryUsageSetting
import com.tom_roush.pdfbox.pdmodel.PDDocument
import com.tom_roush.pdfbox.pdmodel.interactive.action.PDActionGoTo
import com.tom_roush.pdfbox.pdmodel.interactive.action.PDActionURI
import com.tom_roush.pdfbox.pdmodel.interactive.annotation.PDAnnotationLink
import com.tom_roush.pdfbox.pdmodel.interactive.documentnavigation.destination.PDDestination
import com.tom_roush.pdfbox.pdmodel.interactive.documentnavigation.destination.PDNamedDestination
import com.tom_roush.pdfbox.pdmodel.interactive.documentnavigation.destination.PDPageDestination
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.sync.Mutex
import kotlinx.coroutines.sync.withLock
import kotlinx.coroutines.withContext
import java.io.File
import kotlin.math.max
import kotlin.math.min

/**
 * Lazily opened PDFBox view of one document, used for per-page text (selection, copy) and links.
 * PDFBox documents are not thread-safe, so every call is serialised by a mutex and cached per page.
 * It is separate from [PdfEngine] (rendering) so the two never block each other.
 */
class PdfIndex(private val context: Context, private val file: File) {
    private val mutex = Mutex()
    private var doc: PDDocument? = null
    private var stripper: PageTextStripper? = null
    private var closed = false
    private val texts = LruCache<Int, PageText>(32)
    private val linkCache = HashMap<Int, List<PageLink>>()

    private fun document(): PDDocument {
        doc?.let { return it }
        PdfEditor.init(context)
        val d = PDDocument.load(file, MemoryUsageSetting.setupTempFileOnly())
        doc = d
        return d
    }

    /** Text layer of the PDF itself (blank for scanned pages). */
    suspend fun text(page: Int): PageText = withContext(Dispatchers.IO) {
        mutex.withLock {
            if (closed) return@withLock PageText.EMPTY
            texts.get(page) ?: run {
                val st = stripper ?: PageTextStripper().also { stripper = it }
                val pt = runCatching { PdfEditor.extractPage(document(), st, page) }.getOrDefault(PageText.EMPTY)
                texts.put(page, pt)
                pt
            }
        }
    }

    suspend fun links(page: Int): List<PageLink> = withContext(Dispatchers.IO) {
        mutex.withLock {
            if (closed) return@withLock emptyList<PageLink>()
            linkCache[page] ?: run {
                val l = runCatching { readLinks(document(), page) }.getOrDefault(emptyList())
                linkCache[page] = l
                l
            }
        }
    }

    private fun readLinks(doc: PDDocument, pageIndex: Int): List<PageLink> {
        val page = doc.getPage(pageIndex)
        val geo = Geo(page)
        val out = ArrayList<PageLink>()
        for (a in page.annotations) {
            if (a !is PDAnnotationLink) continue
            val r = a.rectangle ?: continue
            val p1 = geo.toNorm(r.lowerLeftX, r.lowerLeftY)
            val p2 = geo.toNorm(r.upperRightX, r.upperRightY)
            val rect = NRect(min(p1.x, p2.x), min(p1.y, p2.y), max(p1.x, p2.x), max(p1.y, p2.y))

            var dest: PDDestination? = a.destination
            var uri: String? = null
            if (dest == null) {
                when (val act = a.action) {
                    is PDActionGoTo -> dest = act.destination
                    is PDActionURI -> uri = act.uri
                    else -> Unit
                }
            }
            var target = -1
            if (dest != null) {
                val pd: PDPageDestination? = when (dest) {
                    is PDPageDestination -> dest
                    is PDNamedDestination -> doc.documentCatalog.findNamedDestinationPage(dest)
                    else -> null
                }
                target = runCatching { pd?.retrievePageNumber() ?: -1 }.getOrDefault(-1)
            }
            if (target >= 0 || !uri.isNullOrBlank()) out += PageLink(rect, target, uri)
        }
        return out
    }

    suspend fun close() {
        mutex.withLock {
            closed = true
            runCatching { doc?.close() }
            doc = null
        }
    }
}
