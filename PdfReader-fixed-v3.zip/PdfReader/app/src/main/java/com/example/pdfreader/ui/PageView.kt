package com.example.pdfreader.ui

import android.content.Context
import android.content.Intent
import android.graphics.Bitmap
import android.net.Uri
import android.widget.Toast
import androidx.compose.foundation.Canvas
import androidx.compose.foundation.Image
import androidx.compose.foundation.background
import androidx.compose.foundation.gestures.awaitEachGesture
import androidx.compose.foundation.gestures.awaitFirstDown
import androidx.compose.foundation.gestures.awaitLongPressOrCancellation
import androidx.compose.foundation.gestures.detectTapGestures
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.size
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateListOf
import androidx.compose.runtime.mutableStateMapOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.rememberUpdatedState
import androidx.compose.runtime.setValue
import androidx.compose.ui.Modifier
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.geometry.Rect
import androidx.compose.ui.geometry.Size
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.ColorFilter
import androidx.compose.ui.graphics.ColorMatrix
import androidx.compose.ui.graphics.FilterQuality
import androidx.compose.ui.graphics.Path
import androidx.compose.ui.graphics.PathEffect
import androidx.compose.ui.graphics.StrokeCap
import androidx.compose.ui.graphics.StrokeJoin
import androidx.compose.ui.graphics.asImageBitmap
import androidx.compose.ui.graphics.drawscope.DrawScope
import androidx.compose.ui.graphics.drawscope.Fill
import androidx.compose.ui.graphics.drawscope.Stroke
import androidx.compose.ui.input.pointer.PointerType
import androidx.compose.ui.input.pointer.pointerInput
import androidx.compose.ui.input.pointer.positionChanged
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.platform.LocalDensity
import androidx.compose.ui.text.TextMeasurer
import androidx.compose.ui.text.TextStyle
import androidx.compose.ui.text.drawText
import androidx.compose.ui.text.rememberTextMeasurer
import androidx.compose.ui.unit.Density
import com.example.pdfreader.data.wave
import com.example.pdfreader.data.isMarkup
import androidx.compose.ui.input.pointer.PointerInputChange
import androidx.compose.ui.unit.dp
import com.example.pdfreader.data.Annot
import com.example.pdfreader.data.AnnotType
import com.example.pdfreader.data.BrushType
import com.example.pdfreader.data.ColorMode
import com.example.pdfreader.data.NRect
import com.example.pdfreader.data.Pt
import com.example.pdfreader.data.alpha
import com.example.pdfreader.data.clampedInto
import com.example.pdfreader.data.isClosedShape
import com.example.pdfreader.data.isLineShape
import com.example.pdfreader.data.pointBounds
import com.example.pdfreader.data.ribbon
import com.example.pdfreader.data.scaledAbout
import com.example.pdfreader.data.segDist
import com.example.pdfreader.data.splitStroke
import com.example.pdfreader.data.translated
import com.example.pdfreader.pdf.PdfEngine
import java.util.UUID
import kotlin.coroutines.cancellation.CancellationException
import kotlin.math.PI
import kotlin.math.abs
import kotlin.math.atan2
import kotlin.math.ceil
import kotlin.math.cos
import kotlin.math.hypot
import kotlin.math.max
import kotlin.math.min
import kotlin.math.round
import kotlin.math.sin
import kotlin.math.sqrt

private const val MAX_PIXELS = 12_000_000f
const val HIGHLIGHT_WIDTH = 0.032f
private val SelectionColor = Color(0xFF3D7BFF)

// ------------------------------------------------------------------ reading modes

fun colorFilterFor(mode: ColorMode): ColorFilter? = when (mode) {
    ColorMode.DAY -> null
    // inverted, slightly softened so pure white/black don't glare
    ColorMode.NIGHT -> ColorFilter.colorMatrix(
        ColorMatrix(
            floatArrayOf(
                -0.86f, 0f, 0f, 0f, 238f,
                0f, -0.86f, 0f, 0f, 238f,
                0f, 0f, -0.86f, 0f, 238f,
                0f, 0f, 0f, 1f, 0f,
            ),
        ),
    )
    ColorMode.SEPIA -> ColorFilter.colorMatrix(
        ColorMatrix(
            floatArrayOf(
                0.393f, 0.769f, 0.189f, 0f, 0f,
                0.349f, 0.686f, 0.168f, 0f, 0f,
                0.272f, 0.534f, 0.131f, 0f, 0f,
                0f, 0f, 0f, 1f, 0f,
            ),
        ),
    )
    ColorMode.WARM -> ColorFilter.colorMatrix(
        ColorMatrix(
            floatArrayOf(
                1f, 0f, 0f, 0f, 0f,
                0f, 0.94f, 0f, 0f, 0f,
                0f, 0f, 0.78f, 0f, 0f,
                0f, 0f, 0f, 1f, 0f,
            ),
        ),
    )
    ColorMode.GRAY -> ColorFilter.colorMatrix(ColorMatrix().apply { setToSaturation(0f) })
}

fun pageBackground(mode: ColorMode): Color = when (mode) {
    ColorMode.NIGHT -> Color(0xFF121212)
    ColorMode.SEPIA -> Color(0xFFF4ECD8)
    ColorMode.WARM -> Color(0xFFFBF1E0)
    else -> Color.White
}

fun deskBackground(mode: ColorMode): Color = when (mode) {
    ColorMode.NIGHT -> Color(0xFF0B0B0C)
    ColorMode.SEPIA -> Color(0xFFD9CDB0)
    ColorMode.WARM -> Color(0xFFE6DCCB)
    ColorMode.GRAY -> Color(0xFFD7D7D7)
    ColorMode.DAY -> Color(0xFFE4E5EA)
}

// ------------------------------------------------------------------ page

/**
 * One rendered page plus its annotation overlay.
 * [fit] = true fits the whole page inside the box (paged modes); false = fill the box width (continuous).
 */
@Composable
fun PdfPage(session: DocSession, index: Int, boxWidthPx: Int, boxHeightPx: Int, fit: Boolean) {
    val engine = session.engine
    val size = engine.sizeOf(index) ?: return
    val density = LocalDensity.current

    val wPx: Float
    val hPx: Float
    if (fit) {
        val s = min(boxWidthPx / size.width, boxHeightPx / size.height)
        wPx = size.width * s
        hPx = size.height * s
    } else {
        wPx = boxWidthPx.toFloat()
        hPx = wPx * size.aspect
    }

    // Render at the on-screen size times the settled zoom (1.0 at rest, then 0.5 steps), capped by a pixel budget,
    // and quantised to 32px so small layout changes reuse the cached bitmap.
    val renderScale = (ceil((session.zoom.settledScale - 0.01f) * 2f) / 2f).coerceAtLeast(1f)
    val maxW = sqrt(MAX_PIXELS / size.aspect)
    val target = (ceil(min(wPx * renderScale, maxW) / 32f) * 32f).toInt().coerceAtLeast(64)

    var bmp by remember(engine, index) {
        mutableStateOf<Bitmap?>(engine.cached(index, target) ?: engine.cached(index, PdfEngine.THUMB_WIDTH))
    }
    LaunchedEffect(engine, index, target) {
        if (bmp?.width != target) {
            try {
                if (bmp == null) bmp = engine.render(index, PdfEngine.THUMB_WIDTH) // instant low-res preview
                bmp = engine.render(index, target)
            } catch (e: CancellationException) {
                throw e
            } catch (_: Throwable) {
                // out of memory or render failure: keep whatever is already shown
            }
        }
    }
    // Links are read lazily, a page at a time, so they are ready by the time the reader taps
    LaunchedEffect(engine, index) { session.ensureLinks(index) }

    val mode = session.meta.colorMode
    val filter = remember(mode) { colorFilterFor(mode) }

    Box(
        Modifier
            .size(with(density) { wPx.toDp() }, with(density) { hPx.toDp() })
            .background(pageBackground(mode)),
    ) {
        val current = bmp
        if (current != null) {
            val image = remember(current) { current.asImageBitmap() }
            Image(
                bitmap = image,
                contentDescription = "Page ${index + 1}",
                modifier = Modifier.fillMaxSize(),
                contentScale = ContentScale.FillBounds,
                colorFilter = filter,
                filterQuality = FilterQuality.High,
            )
        }
        AnnotLayer(session, index, wPx, hPx)
    }
}

private val SafeSchemes = setOf("http", "https", "mailto", "tel")

private fun openExternal(context: Context, uri: String) {
    val parsed = Uri.parse(uri)
    // Only ordinary web/mail/phone links: PDFs can carry intent:, file: and other schemes that must not be launched
    if (parsed.scheme?.lowercase() !in SafeSchemes) {
        Toast.makeText(context, "This link type isn't supported", Toast.LENGTH_SHORT).show()
        return
    }
    try {
        context.startActivity(Intent(Intent.ACTION_VIEW, parsed).addFlags(Intent.FLAG_ACTIVITY_NEW_TASK))
    } catch (_: Exception) {
        Toast.makeText(context, "No app can open this link", Toast.LENGTH_SHORT).show()
    }
}

// ------------------------------------------------------------------ geometry helpers (pixel space)

/**
 * Where a drawing tool acts for this touch: a finger is placed [lift] px above its contact point so the fingertip
 * doesn't hide what is being drawn; stylus and mouse act exactly where they are.
 */
private fun PointerInputChange.tip(lift: Float, h: Float): Offset =
    if (type == PointerType.Touch && lift > 0f) Offset(position.x, (position.y - lift).coerceIn(0f, h)) else position

private const val HANDLE_CORNER_BASE = 0
private const val HANDLE_ENDPOINT_BASE = 10

private fun isLineTool(t: Tool) = t == Tool.LINE || t == Tool.ARROW || t == Tool.DOUBLE_ARROW

/** Lines snap to 45 degree steps around [start]. */
private fun snapLine(start: Pt, p: Pt, w: Float, h: Float): Pt {
    val dx = (p.x - start.x) * w
    val dy = (p.y - start.y) * h
    val len = hypot(dx, dy)
    if (len < 1f) return p
    val step = (PI / 4).toFloat()
    val ang = round(atan2(dy, dx) / step) * step
    return Pt(start.x + len * cos(ang) / w, start.y + len * sin(ang) / h)
}

/** Boxes and ovals snap to squares / circles. */
private fun snapBox(start: Pt, p: Pt, w: Float, h: Float): Pt {
    val dx = (p.x - start.x) * w
    val dy = (p.y - start.y) * h
    val m = max(abs(dx), abs(dy))
    val sx = if (dx < 0f) -1f else 1f
    val sy = if (dy < 0f) -1f else 1f
    return Pt(start.x + sx * m / w, start.y + sy * m / h)
}

/** Slow ends of a brush stroke thin out a little, like lifting the brush. */
private fun taper(widths: List<Float>): List<Float> {
    if (widths.size < 4) return widths
    val out = widths.toMutableList()
    val n = out.size
    out[n - 1] = out[n - 1] * 0.45f
    out[n - 2] = out[n - 2] * 0.65f
    out[n - 3] = out[n - 3] * 0.85f
    return out
}

private fun shapeVerts(type: AnnotType, l: Float, t: Float, r: Float, b: Float): List<Offset> {
    val cx = (l + r) / 2f
    val cy = (t + b) / 2f
    return when (type) {
        AnnotType.SHAPE_TRIANGLE -> listOf(Offset(cx, t), Offset(r, b), Offset(l, b))
        AnnotType.SHAPE_DIAMOND -> listOf(Offset(cx, t), Offset(r, cy), Offset(cx, b), Offset(l, cy))
        else -> listOf(Offset(l, t), Offset(r, t), Offset(r, b), Offset(l, b))
    }
}

private fun insidePolygon(p: Offset, v: List<Offset>): Boolean {
    var inside = false
    var j = v.size - 1
    for (i in v.indices) {
        val a = v[i]
        val b = v[j]
        if ((a.y > p.y) != (b.y > p.y) && p.x < (b.x - a.x) * (p.y - a.y) / (b.y - a.y) + a.x) inside = !inside
        j = i
    }
    return inside
}

private fun Density.textRect(a: Annot, m: TextMeasurer, w: Float, h: Float): Rect {
    val p = a.points.firstOrNull() ?: return Rect.Zero
    val size = m.measure(a.text, TextStyle(fontSize = (a.width * min(w, h)).toSp()), softWrap = false).size
    return Rect(p.x * w, p.y * h, p.x * w + size.width, p.y * h + size.height)
}

/** The annotation's own bounds, normalised to the page (text is measured, everything else uses its points). */
private fun Density.boxNorm(a: Annot, m: TextMeasurer, w: Float, h: Float): NRect {
    if (a.type == AnnotType.TEXT) {
        val r = textRect(a, m, w, h)
        return NRect(r.left / w, r.top / h, r.right / w, r.bottom / h)
    }
    if (a.type == AnnotType.NOTE) {
        val p = a.points.firstOrNull() ?: return NRect(0f, 0f, 0f, 0f)
        val sz = max(12f, a.width * min(w, h))
        return NRect(p.x, p.y, p.x + sz / w, p.y + sz / h)
    }
    return a.pointBounds() ?: NRect(0f, 0f, 0f, 0f)
}

/** The box drawn around a selected annotation: its bounds plus half the stroke, never smaller than a finger target. */
private fun Density.selectionBox(a: Annot, m: TextMeasurer, w: Float, h: Float): Rect {
    val b = boxNorm(a, m, w, h)
    val pad = when (a.type) {
        AnnotType.TEXT, AnnotType.NOTE -> 4f
        else -> if (a.type.isMarkup) 4f else a.width * min(w, h) * (if (a.brush == BrushType.BRUSH) 0.75f else 0.5f) + 4f
    }
    var r = Rect(b.l * w, b.t * h, b.r * w, b.b * h).inflate(pad)
    if (r.width < 28f) r = Rect(r.center.x - 14f, r.top, r.center.x + 14f, r.bottom)
    if (r.height < 28f) r = Rect(r.left, r.center.y - 14f, r.right, r.center.y + 14f)
    return r
}

private fun Density.hitAnnot(a: Annot, pos: Offset, w: Float, h: Float, tol: Float, m: TextMeasurer): Boolean =
    if (a.type == AnnotType.TEXT) textRect(a, m, w, h).inflate(tol).contains(pos) else a.hit(pos, w, h, tol)

/** Which handle of the selected annotation [pos] is on: corner 0..3 (TL, TR, BR, BL), line end 10/11, or -1. */
private fun Density.handleAt(a: Annot, pos: Offset, w: Float, h: Float, m: TextMeasurer, reach: Float): Int {
    if (a.type.isLineShape) {
        a.points.take(2).forEachIndexed { i, pt ->
            if (hypot(pos.x - pt.x * w, pos.y - pt.y * h) <= reach) return HANDLE_ENDPOINT_BASE + i
        }
        return -1
    }
    if (a.type.isMarkup) return -1
    val box = selectionBox(a, m, w, h)
    val corners = listOf(box.topLeft, box.topRight, box.bottomRight, box.bottomLeft)
    corners.forEachIndexed { i, c -> if (hypot(pos.x - c.x, pos.y - c.y) <= reach) return HANDLE_CORNER_BASE + i }
    return -1
}

private fun ratio(now: Float, old: Float): Float = if (abs(old) < 1e-4f) 1f else (now / old).coerceAtLeast(0.05f)

/** The annotation as it should look after the drag ([dxN], [dyN] are normalised offsets from where the drag began). */
private fun Density.transformAnnot(
    a: Annot, handle: Int, dxN: Float, dyN: Float, w: Float, h: Float, m: TextMeasurer, snap: Boolean,
): Annot {
    if (handle < 0) {
        val (mx, my) = a.clampedInto(boxNorm(a, m, w, h), dxN, dyN)
        return a.translated(mx, my)
    }
    if (handle >= HANDLE_ENDPOINT_BASE) {
        if (a.points.size < 2) return a
        val i = handle - HANDLE_ENDPOINT_BASE
        val other = a.points[1 - i]
        val moved = Pt(a.points[i].x + dxN, a.points[i].y + dyN)
        val np = if (snap) snapLine(other, moved, w, h) else moved
        return a.copy(points = if (i == 0) listOf(np, other) else listOf(other, np))
    }
    val b = boxNorm(a, m, w, h)
    val corners = listOf(Pt(b.l, b.t), Pt(b.r, b.t), Pt(b.r, b.b), Pt(b.l, b.b))
    val old = corners[handle]
    val anchor = corners[(handle + 2) % 4]
    var sx = ratio(old.x + dxN - anchor.x, old.x - anchor.x)
    var sy = ratio(old.y + dyN - anchor.y, old.y - anchor.y)
    if (snap || a.type == AnnotType.TEXT) {
        val s = max(sx, sy)
        sx = s
        sy = s
    }
    return a.scaledAbout(anchor.x, anchor.y, sx, sy)
}

// ------------------------------------------------------------------ annotation overlay + input

@Composable
private fun AnnotLayer(session: DocSession, index: Int, wPx: Float, hPx: Float) {
    val context = LocalContext.current
    val tool = session.tool
    val list = session.annotsByPage[index].orEmpty()
    val latestList by rememberUpdatedState(list)
    val hits = session.searchHits.filter { it.page == index }
    val currentHit = session.searchHits.getOrNull(session.searchIndex)
    val live = remember(index) { mutableStateListOf<Pt>() }
    val liveW = remember(index) { mutableStateListOf<Float>() }
    var erasing by remember(index) { mutableStateOf(emptySet<String>()) }
    val cut = remember(index) { mutableStateMapOf<String, List<Annot>>() }
    var eraserAt by remember(index) { mutableStateOf<Offset?>(null) }
    var liveSel by remember(index) { mutableStateOf<Annot?>(null) }
    var penTip by remember(index) { mutableStateOf<Offset?>(null) }
    var markLive by remember(index) { mutableStateOf<List<NRect>>(emptyList()) }
    val measurer = rememberTextMeasurer()

    // markup tools snap to words, so the page's text has to be read before they're used
    LaunchedEffect(tool, index) { if (tool.isTextMarkup) session.ensureText(index) }

    val selected = if (tool == Tool.SELECT) session.selectedAnnot?.takeIf { it.page == index } else null
    val latestSelected by rememberUpdatedState(selected)

    val links = session.links[index].orEmpty()
    val latestLinks by rememberUpdatedState(links)
    val sel = session.selection?.takeIf { it.page == index }
    val pageText = session.textOf(index)
    val selRects = remember(sel, pageText) {
        if (sel != null && pageText != null) pageText.rectsFor(sel.start, sel.end) else emptyList()
    }
    val latestSelRects by rememberUpdatedState(selRects)
    val latestSelection by rememberUpdatedState(session.selection)

    val input: Modifier = when {
        // Freehand pen / highlighter band / two-point shapes and area highlights
        tool == Tool.PEN || tool == Tool.HIGHLIGHT || tool.isDragShape -> Modifier.pointerInput(tool, wPx, hPx) {
            awaitEachGesture {
                val down = awaitFirstDown(requireUnconsumed = true)
                val lift = PenPrefs.fingerOffsetDp.dp.toPx()
                val t0 = down.tip(lift, hPx)
                penTip = if (t0 != down.position) t0 else null
                val start = Pt(t0.x / wPx, t0.y / hPx)
                val brush = if (tool == Tool.PEN) session.styleOf(StyleKey.PEN).brush else BrushType.PEN
                live.clear()
                liveW.clear()
                live.add(start)
                if (brush == BrushType.BRUSH) liveW.add(0.8f)
                down.consume()
                var ok = true
                var lastX = t0.x
                var lastY = t0.y
                var lastT = down.uptimeMillis
                var smooth = 0.8f
                while (true) {
                    val ev = awaitPointerEvent()
                    if (ev.changes.count { it.pressed } > 1) { ok = false; break }
                    val ch = ev.changes.firstOrNull { it.id == down.id } ?: break
                    if (ch.isConsumed && ch.positionChanged()) { ok = false; break }
                    if (!ch.pressed) { ch.consume(); break }
                    val tp = ch.tip(lift, hPx)
                    penTip = if (tp != ch.position) tp else null
                    val p = Pt(tp.x / wPx, tp.y / hPx)
                    when {
                        tool == Tool.PEN -> {
                            val moved = abs(tp.x - lastX) + abs(tp.y - lastY)
                            if (moved > 1.5f) {
                                if (brush == BrushType.BRUSH) {
                                    val dt = max(ch.uptimeMillis - lastT, 1L)
                                    val target = if (ch.type == PointerType.Stylus) {
                                        0.25f + 1.1f * ch.pressure.coerceIn(0f, 1f)
                                    } else {
                                        // slow = thick, fast = thin
                                        1.35f - 0.95f * min(moved / dt / 2f, 1f)
                                    }
                                    smooth = smooth * 0.65f + target * 0.35f
                                    liveW.add(smooth)
                                }
                                live.add(p)
                                lastX = tp.x
                                lastY = tp.y
                                lastT = ch.uptimeMillis
                            }
                        }
                        tool == Tool.HIGHLIGHT -> {
                            // straight highlighter band; snaps horizontal when the drag is nearly level
                            val y = if (abs(p.y - start.y) < 0.02f) start.y else p.y
                            if (live.size == 1) live.add(Pt(p.x, y)) else live[1] = Pt(p.x, y)
                        }
                        else -> {
                            val end = when {
                                !session.snapShapes -> p
                                isLineTool(tool) -> snapLine(start, p, wPx, hPx)
                                else -> snapBox(start, p, wPx, hPx)
                            }
                            if (live.size == 1) live.add(end) else live[1] = end
                        }
                    }
                    ch.consume()
                }
                val last = live.lastOrNull()
                val moved = last != null && abs(last.x - start.x) * wPx + abs(last.y - start.y) * hPx > 6f
                val valid = ok && live.isNotEmpty() && (tool == Tool.PEN || moved)
                if (valid) {
                    val pts = live.toList()
                    session.addAnnot(
                        when {
                            tool == Tool.PEN -> session.styledAnnot(
                                index, AnnotType.INK, StyleKey.PEN, pts,
                                if (brush == BrushType.BRUSH) taper(liveW.toList()) else emptyList(),
                            )
                            tool == Tool.HIGHLIGHT -> session.styledAnnot(index, AnnotType.HIGHLIGHT, StyleKey.HIGHLIGHT, pts)
                            tool == Tool.AREA -> session.styledAnnot(index, AnnotType.AREA, StyleKey.AREA, pts)
                            else -> session.styledAnnot(index, tool.shapeType(), StyleKey.SHAPE, pts)
                        },
                    )
                }
                live.clear()
                liveW.clear()
                penTip = null
            }
        }

        // Underline / strikethrough / squiggly: drag across text to mark it; a tap marks the word.
        tool.isTextMarkup -> Modifier.pointerInput(tool, wPx, hPx) {
            awaitEachGesture {
                val down = awaitFirstDown(requireUnconsumed = true)
                val lift = PenPrefs.fingerOffsetDp.dp.toPx()
                val aspect = session.engine.sizeOf(index)?.aspect ?: 1.4f
                var anchor = -1
                var lo = -1
                var hi = -1
                var fallback: Pt? = null
                var fallbackMoved = false

                fun update(tp: Offset) {
                    val nx = tp.x / wPx
                    val ny = tp.y / hPx
                    val pt = session.textOf(index)
                    if (pt != null && !pt.isBlank) {
                        val i = pt.indexAt(nx, ny, aspect, 0.06f)
                        if (i >= 0) {
                            if (anchor < 0) anchor = i
                            lo = min(anchor, i)
                            hi = max(anchor, i)
                        }
                        markLive = if (lo >= 0) {
                            val r = if (lo == hi) pt.wordRange(lo) else lo..hi
                            pt.rectsFor(r.first, r.last)
                        } else {
                            emptyList()
                        }
                    } else {
                        // no text layer (a scan without OCR): mark along the dragged line
                        val s0 = fallback ?: Pt(nx, ny).also { fallback = it }
                        if (abs(nx - s0.x) * wPx > 6f) fallbackMoved = true
                        markLive = listOf(NRect(min(s0.x, nx), s0.y - 0.012f, max(s0.x, nx), s0.y + 0.012f))
                    }
                }

                val t0 = down.tip(lift, hPx)
                penTip = if (t0 != down.position) t0 else null
                update(t0)
                down.consume()
                var ok = true
                while (true) {
                    val ev = awaitPointerEvent()
                    if (ev.changes.count { it.pressed } > 1) { ok = false; break }
                    val ch = ev.changes.firstOrNull { it.id == down.id } ?: break
                    if (ch.isConsumed && ch.positionChanged()) { ok = false; break }
                    if (!ch.pressed) { ch.consume(); break }
                    val tp = ch.tip(lift, hPx)
                    penTip = if (tp != ch.position) tp else null
                    update(tp)
                    ch.consume()
                }
                val rects = markLive
                val usable = anchor >= 0 || (fallback != null && fallbackMoved)
                if (ok && usable && rects.isNotEmpty()) session.addMarkup(index, tool.markType(), rects)
                markLive = emptyList()
                penTip = null
            }
        }

        tool == Tool.NOTE -> Modifier.pointerInput(tool, wPx, hPx) {
            detectTapGestures { pos ->
                val existing = latestList.lastOrNull { it.type == AnnotType.NOTE && it.hit(pos, wPx, hPx, 10f) }
                val size = max(12f, session.styleOf(StyleKey.NOTE).width * min(wPx, hPx))
                val at = existing?.points?.firstOrNull()
                    ?: Pt(((pos.x - size / 2f) / wPx).coerceIn(0f, 0.97f), ((pos.y - size / 2f) / hPx).coerceIn(0f, 0.97f))
                session.noteEdit = NoteEdit(index, at, existing)
            }
        }

        tool == Tool.ERASER -> Modifier.pointerInput(tool, wPx, hPx) {
            awaitEachGesture {
                val down = awaitFirstDown(requireUnconsumed = true)
                val lift = PenPrefs.fingerOffsetDp.dp.toPx()
                val radius = session.eraserSize.dp.toPx()
                val partial = session.eraserPartial
                val removed = mutableSetOf<String>()
                cut.clear()
                fun probe(pos: Offset) {
                    eraserAt = pos
                    latestList.forEach { a ->
                        if (a.id in removed) return@forEach
                        if (partial && a.type == AnnotType.INK && a.points.size >= 2) {
                            val pieces = cut[a.id] ?: listOf(a)
                            val next = pieces.flatMap { splitStroke(it, pos.x, pos.y, radius, wPx, hPx) }
                            val changed = next.size != pieces.size || next.indices.any { next[it] !== pieces[it] }
                            if (changed) cut[a.id] = next
                        } else if (hitAnnot(a, pos, wPx, hPx, radius, measurer)) {
                            removed += a.id
                        }
                    }
                    erasing = removed.toSet()
                }
                probe(down.tip(lift, hPx))
                down.consume()
                var ok = true
                while (true) {
                    val ev = awaitPointerEvent()
                    if (ev.changes.count { it.pressed } > 1) { ok = false; break }
                    val ch = ev.changes.firstOrNull { it.id == down.id } ?: break
                    if (!ch.pressed) { ch.consume(); break }
                    probe(ch.tip(lift, hPx))
                    ch.consume()
                }
                if (ok) {
                    val changes = HashMap<String, List<Annot>>()
                    cut.forEach { (id, pieces) ->
                        if (id !in removed) changes[id] = pieces.map { it.copy(id = UUID.randomUUID().toString()) }
                    }
                    removed.forEach { changes[it] = emptyList() }
                    session.edit(changes)
                }
                cut.clear()
                erasing = emptySet()
                eraserAt = null
            }
        }

        tool == Tool.TEXT -> Modifier.pointerInput(tool, wPx, hPx) {
            detectTapGestures { pos ->
                val existing = latestList.lastOrNull { it.type == AnnotType.TEXT && hitAnnot(it, pos, wPx, hPx, 12f, measurer) }
                session.textEdit = TextEdit(index, Pt(pos.x / wPx, pos.y / hPx), existing)
            }
        }

        // Select: tap picks an annotation; drag moves it; corner / end handles resize it.
        tool == Tool.SELECT -> Modifier.pointerInput(tool, wPx, hPx) {
            val reach = 24.dp.toPx()
            val slop = 8.dp.toPx()
            awaitEachGesture {
                val down = awaitFirstDown(requireUnconsumed = true)
                val pos0 = down.position
                val before = latestSelected
                var target: Annot? = before
                var handle = -1
                var grabbed = false
                if (target != null) {
                    handle = handleAt(target, pos0, wPx, hPx, measurer, reach)
                    grabbed = handle >= 0 ||
                        selectionBox(target, measurer, wPx, hPx).inflate(6f).contains(pos0) ||
                        hitAnnot(target, pos0, wPx, hPx, 18f, measurer)
                }
                if (!grabbed) {
                    val picked = latestList.lastOrNull { hitAnnot(it, pos0, wPx, hPx, 18f, measurer) }
                    if (picked != null) {
                        target = picked
                        session.selectedId = picked.id
                        grabbed = true
                    } else {
                        target = null
                    }
                }
                down.consume()
                var dragging = false
                var ok = true
                while (true) {
                    val ev = awaitPointerEvent()
                    if (ev.changes.count { it.pressed } > 1) { ok = false; break }
                    val ch = ev.changes.firstOrNull { it.id == down.id } ?: break
                    if (ch.isConsumed && ch.positionChanged()) { ok = false; break }
                    if (!ch.pressed) { ch.consume(); break }
                    val dx = ch.position.x - pos0.x
                    val dy = ch.position.y - pos0.y
                    if (!dragging && hypot(dx, dy) > slop) dragging = true
                    if (dragging && grabbed && target != null) {
                        liveSel = transformAnnot(target, handle, dx / wPx, dy / hPx, wPx, hPx, measurer, session.snapShapes)
                    }
                    ch.consume()
                }
                val result = liveSel
                liveSel = null
                if (ok && dragging && result != null) {
                    session.replaceAnnot(result)
                } else if (ok && !dragging) {
                    if (!grabbed) {
                        session.selectedId = null
                    } else if (target != null && target.id == before?.id) {
                        if (target.type == AnnotType.TEXT) session.textEdit = TextEdit(index, target.points[0], target)
                        if (target.type == AnnotType.NOTE) session.noteEdit = NoteEdit(index, target.points[0], target)
                    }
                }
            }
        }

        // Reading: long-press selects a word, handles extend it, a tap on a link follows it.
        // Anything else is left unconsumed so scrolling, zooming and "tap to toggle the bars" keep working.
        else -> Modifier.pointerInput(wPx, hPx) {
            val handleReach = 36.dp.toPx()
            val handleLift = 22.dp.toPx()
            awaitEachGesture {
                val down = awaitFirstDown(requireUnconsumed = false)

                val rects = latestSelRects
                if (rects.isNotEmpty()) {
                    val first = rects.first()
                    val last = rects.last()
                    val dStart = hypot(down.position.x - first.l * wPx, down.position.y - first.b * hPx)
                    val dEnd = hypot(down.position.x - last.r * wPx, down.position.y - last.b * hPx)
                    if (min(dStart, dEnd) <= handleReach) {
                        val isStart = dStart <= dEnd
                        down.consume()
                        while (true) {
                            val ev = awaitPointerEvent()
                            val ch = ev.changes.firstOrNull { it.id == down.id } ?: break
                            if (!ch.pressed) { ch.consume(); break }
                            session.moveSelection(isStart, ch.position.x / wPx, (ch.position.y - handleLift) / hPx)
                            ch.consume()
                        }
                        return@awaitEachGesture
                    }
                }

                val pressed = awaitLongPressOrCancellation(down.id)
                if (pressed != null) {
                    session.beginSelection(index, pressed.position.x / wPx, pressed.position.y / hPx)
                    pressed.consume()
                    while (true) {
                        val ev = awaitPointerEvent()
                        ev.changes.forEach { it.consume() }
                        if (ev.changes.none { it.pressed }) break
                    }
                } else {
                    val up = currentEvent.changes.firstOrNull { it.id == down.id }
                    if (up != null && !up.pressed && !up.isConsumed) {
                        val nx = down.position.x / wPx
                        val ny = down.position.y / hPx
                        val link = latestLinks.firstOrNull {
                            nx >= it.rect.l - 0.004f && nx <= it.rect.r + 0.004f &&
                                ny >= it.rect.t - 0.004f && ny <= it.rect.b + 0.004f
                        }
                        val note = latestList.lastOrNull { it.type == AnnotType.NOTE && it.hit(down.position, wPx, hPx, 10f) }
                        if (note != null) {
                            up.consume()
                            session.noteEdit = NoteEdit(index, note.points[0], note)
                        } else if (link != null) {
                            up.consume()
                            if (link.page >= 0) session.followLink(link.page)
                            else link.uri?.let { openExternal(context, it) }
                        } else if (latestSelection != null) {
                            up.consume()
                            session.clearSelection()
                        }
                    }
                }
            }
        }
    }

    Canvas(Modifier.fillMaxSize().then(input)) {
        hits.forEach { hit ->
            val isCurrent = hit === currentHit
            hit.rects.forEach { r ->
                drawRect(
                    color = if (isCurrent) Color(0x99FF9800) else Color(0x66FFEB3B),
                    topLeft = Offset(r.l * size.width, r.t * size.height),
                    size = Size((r.r - r.l) * size.width, (r.b - r.t) * size.height),
                )
            }
        }
        val moving = liveSel
        list.forEach { a ->
            if (a.id in erasing) return@forEach
            val pieces = cut[a.id]
            when {
                pieces != null -> pieces.forEach { drawAnnot(it, measurer) }
                moving != null && moving.id == a.id -> drawAnnot(moving, measurer)
                else -> drawAnnot(a, measurer)
            }
        }
        if (live.isNotEmpty()) {
            val key = tool.styleKey
            if (key != null && tool != Tool.TEXT) {
                val st = session.styleOf(key)
                val type = when {
                    tool == Tool.PEN -> AnnotType.INK
                    tool == Tool.HIGHLIGHT -> AnnotType.HIGHLIGHT
                    else -> tool.shapeType()
                }
                drawAnnot(
                    Annot(
                        id = "live", page = index, type = type, color = st.color, width = st.width, points = live.toList(),
                        opacity = st.opacity, fillAlpha = if (type.isClosedShape) st.fill else 0f,
                        dash = if (type.isClosedShape || type.isLineShape) st.dash else 0,
                        brush = if (type == AnnotType.INK) st.brush else BrushType.PEN,
                        widths = if (type == AnnotType.INK) liveW.toList() else emptyList(),
                    ),
                    measurer,
                )
            }
        }
        if (markLive.isNotEmpty() && tool.isTextMarkup) {
            val type = tool.markType()
            val st = session.styleOf(tool.styleKey ?: StyleKey.UNDERLINE)
            drawAnnot(
                Annot(
                    id = "live", page = index, type = type, color = st.color, width = st.width,
                    points = markLive.flatMap { listOf(Pt(it.l, it.t), Pt(it.r, it.b)) }, opacity = st.opacity,
                ),
                measurer,
            )
        }
        penTip?.let {
            // ring at the spot where the line is really being drawn (the finger is below it)
            val st = tool.styleKey?.let { k -> session.styleOf(k) }
            val r = max(4.dp.toPx(), (st?.width ?: 0f) * min(size.width, size.height) / 2f)
            drawCircle(Color.White, r + 1.5.dp.toPx(), it, style = Stroke(2.dp.toPx()))
            drawCircle(Color(0xFF3D7BFF), r, it, style = Stroke(1.5.dp.toPx()))
        }
        eraserAt?.let {
            val r = session.eraserSize.dp.toPx()
            drawCircle(Color(0x33808080), r, it)
            drawCircle(Color(0xCC606060), r, it, style = Stroke(1.5.dp.toPx()))
        }
        // Selected annotation: dashed frame plus handles
        val shown = moving ?: selected
        if (shown != null) {
            val box = selectionBox(shown, measurer, size.width, size.height)
            val frame = Stroke(1.5.dp.toPx(), pathEffect = PathEffect.dashPathEffect(floatArrayOf(6.dp.toPx(), 4.dp.toPx())))
            drawRect(SelectionColor, box.topLeft, box.size, style = frame)
            val handles: List<Offset> = when {
                shown.type.isLineShape -> shown.points.take(2).map { Offset(it.x * size.width, it.y * size.height) }
                shown.type.isMarkup -> emptyList()
                else -> listOf(box.topLeft, box.topRight, box.bottomRight, box.bottomLeft)
            }
            handles.forEach {
                drawCircle(Color.White, 8.dp.toPx(), it)
                drawCircle(SelectionColor, 8.dp.toPx(), it, style = Stroke(2.dp.toPx()))
            }
        }
        // Text selection: tinted lines plus a teardrop handle at each end
        if (selRects.isNotEmpty()) {
            selRects.forEach { r ->
                drawRect(
                    color = SelectionColor.copy(alpha = 0.3f),
                    topLeft = Offset(r.l * size.width, r.t * size.height),
                    size = Size((r.r - r.l) * size.width, (r.b - r.t) * size.height),
                )
            }
            val f = selRects.first()
            val l = selRects.last()
            val radius = 8.dp.toPx()
            val stem = 2.dp.toPx()
            drawLine(SelectionColor, Offset(f.l * size.width, f.t * size.height), Offset(f.l * size.width, f.b * size.height), stem)
            drawCircle(SelectionColor, radius, Offset(f.l * size.width, f.b * size.height + radius))
            drawLine(SelectionColor, Offset(l.r * size.width, l.t * size.height), Offset(l.r * size.width, l.b * size.height), stem)
            drawCircle(SelectionColor, radius, Offset(l.r * size.width, l.b * size.height + radius))
        }
    }
}

// ------------------------------------------------------------------ drawing

private fun dashEffect(dash: Int, sw: Float): PathEffect? {
    val d = max(sw, 2.5f)
    return when (dash) {
        1 -> PathEffect.dashPathEffect(floatArrayOf(4f * d, 3f * d))
        2 -> PathEffect.dashPathEffect(floatArrayOf(0.01f, 2.2f * d))
        else -> null
    }
}

private fun DrawScope.drawAnnot(a: Annot, measurer: TextMeasurer) {
    val ms = min(size.width, size.height)
    val solid = Color(a.color)
    val tinted = solid.copy(alpha = a.alpha)
    when (a.type) {
        AnnotType.INK -> when (a.brush) {
            BrushType.PEN -> drawInk(a.points, tinted, a.width * ms, StrokeCap.Round)
            BrushType.MARKER -> drawInk(a.points, tinted, a.width * ms, StrokeCap.Square)
            BrushType.BRUSH -> drawBrush(a.points, a.widths, tinted, a.width * ms)
        }
        AnnotType.HIGHLIGHT -> if (a.points.size >= 2) {
            drawLine(
                tinted,
                Offset(a.points.first().x * size.width, a.points.first().y * size.height),
                Offset(a.points.last().x * size.width, a.points.last().y * size.height),
                strokeWidth = a.width * ms,
                cap = StrokeCap.Butt,
            )
        }
        AnnotType.AREA -> if (a.points.size >= 2) {
            val p = a.points[0]
            val q = a.points[1]
            val topLeft = Offset(min(p.x, q.x) * size.width, min(p.y, q.y) * size.height)
            val extent = Size(abs(q.x - p.x) * size.width, abs(q.y - p.y) * size.height)
            drawRect(tinted, topLeft, extent)
            if (a.width > 0f) drawRect(solid, topLeft, extent, style = Stroke(width = max(1f, a.width * ms), join = StrokeJoin.Round))
        }
        AnnotType.TEXT -> {
            val p = a.points.firstOrNull() ?: return
            drawText(
                textMeasurer = measurer,
                text = a.text,
                topLeft = Offset(p.x * size.width, p.y * size.height),
                style = TextStyle(color = solid, fontSize = (a.width * ms).toSp()),
                softWrap = false,
            )
        }
        AnnotType.MARK_HIGHLIGHT, AnnotType.MARK_UNDERLINE, AnnotType.MARK_STRIKE, AnnotType.MARK_SQUIGGLY -> {
            var i = 0
            while (i + 1 < a.points.size) {
                val p = a.points[i]
                val q = a.points[i + 1]
                i += 2
                val l = min(p.x, q.x) * size.width
                val r = max(p.x, q.x) * size.width
                val t = min(p.y, q.y) * size.height
                val b = max(p.y, q.y) * size.height
                val thick = if (a.width > 0f) max(1f, a.width * ms) else max(1.5f, (b - t) * 0.07f)
                when (a.type) {
                    AnnotType.MARK_HIGHLIGHT -> drawRect(tinted, Offset(l, t), Size(r - l, b - t))
                    AnnotType.MARK_UNDERLINE -> drawLine(tinted, Offset(l, b), Offset(r, b), thick, StrokeCap.Round)
                    AnnotType.MARK_STRIKE -> drawLine(tinted, Offset(l, (t + b) / 2f), Offset(r, (t + b) / 2f), thick, StrokeCap.Round)
                    else -> {
                        val amp = max(1f, thick * 1.2f)
                        val pts = wave(l, r, b + amp * 0.4f, amp, max(4f, amp * 4f))
                        val path = Path()
                        path.moveTo(pts[0], pts[1])
                        for (k in 1 until pts.size / 2) path.lineTo(pts[2 * k], pts[2 * k + 1])
                        drawPath(path, tinted, style = Stroke(width = thick, cap = StrokeCap.Round, join = StrokeJoin.Round))
                    }
                }
            }
        }
        AnnotType.NOTE -> drawNote(a)
        else -> drawShape(a)
    }
}

/** A sticky-note icon: folded-corner square with a few lines of "text". */
private fun DrawScope.drawNote(a: Annot) {
    val p = a.points.firstOrNull() ?: return
    val s = max(12f, a.width * min(size.width, size.height))
    val x = p.x * size.width
    val y = p.y * size.height
    val base = Color(a.color)
    val body = base.copy(alpha = a.alpha)
    val edge = Color(base.red * 0.55f, base.green * 0.55f, base.blue * 0.55f, a.alpha)
    val fold = s * 0.28f
    val shape = Path()
    shape.moveTo(x, y)
    shape.lineTo(x + s, y)
    shape.lineTo(x + s, y + s - fold)
    shape.lineTo(x + s - fold, y + s)
    shape.lineTo(x, y + s)
    shape.close()
    drawPath(shape, body)
    drawPath(shape, edge, style = Stroke(width = max(1f, s * 0.04f), join = StrokeJoin.Round))
    val corner = Path()
    corner.moveTo(x + s, y + s - fold)
    corner.lineTo(x + s - fold, y + s)
    corner.lineTo(x + s - fold, y + s - fold)
    corner.close()
    drawPath(corner, edge.copy(alpha = a.alpha * 0.5f))
    for (k in 0..2) {
        val ly = y + s * (0.28f + 0.2f * k)
        val end = if (k == 2) 0.5f else 0.82f
        drawLine(edge, Offset(x + s * 0.18f, ly), Offset(x + s * end, ly), max(1f, s * 0.05f), StrokeCap.Round)
    }
}

private fun DrawScope.drawArrowHead(from: Offset, tip: Offset, sw: Float, ms: Float, color: Color) {
    val ang = atan2(tip.y - from.y, tip.x - from.x)
    val len = max(sw * 4f, ms * 0.03f)
    for (delta in floatArrayOf(0.5f, -0.5f)) {
        val e = Offset(tip.x - len * cos(ang + delta), tip.y - len * sin(ang + delta))
        drawLine(color, tip, e, sw, StrokeCap.Round)
    }
}

private fun DrawScope.drawShape(a: Annot) {
    if (a.points.size < 2) return
    val w = size.width
    val h = size.height
    val ms = min(w, h)
    val p = Offset(a.points[0].x * w, a.points[0].y * h)
    val q = Offset(a.points[1].x * w, a.points[1].y * h)
    val sw = max(1f, a.width * ms)
    val color = Color(a.color).copy(alpha = a.alpha)
    val effect = dashEffect(a.dash, sw)
    when (a.type) {
        AnnotType.SHAPE_LINE, AnnotType.SHAPE_ARROW, AnnotType.SHAPE_DOUBLE_ARROW -> {
            drawLine(color, p, q, sw, StrokeCap.Round, pathEffect = effect)
            if (a.type != AnnotType.SHAPE_LINE) drawArrowHead(p, q, sw, ms, color)
            if (a.type == AnnotType.SHAPE_DOUBLE_ARROW) drawArrowHead(q, p, sw, ms, color)
        }
        AnnotType.SHAPE_RECT, AnnotType.SHAPE_OVAL, AnnotType.SHAPE_TRIANGLE, AnnotType.SHAPE_DIAMOND -> {
            val l = min(p.x, q.x)
            val r = max(p.x, q.x)
            val t = min(p.y, q.y)
            val b = max(p.y, q.y)
            val path = Path()
            when (a.type) {
                AnnotType.SHAPE_RECT -> path.addRect(Rect(l, t, r, b))
                AnnotType.SHAPE_OVAL -> path.addOval(Rect(l, t, r, b))
                else -> {
                    val v = shapeVerts(a.type, l, t, r, b)
                    path.moveTo(v[0].x, v[0].y)
                    for (i in 1 until v.size) path.lineTo(v[i].x, v[i].y)
                    path.close()
                }
            }
            if (a.fillAlpha > 0f) {
                drawPath(path, Color(a.color).copy(alpha = (a.fillAlpha * a.alpha).coerceIn(0f, 1f)), style = Fill)
            }
            drawPath(path, color, style = Stroke(width = sw, cap = StrokeCap.Round, join = StrokeJoin.Round, pathEffect = effect))
        }
        else -> Unit
    }
}

private fun DrawScope.drawInk(pts: List<Pt>, color: Color, strokePx: Float, cap: StrokeCap) {
    if (pts.isEmpty()) return
    val w = size.width
    val h = size.height
    if (pts.size == 1) {
        drawCircle(color, strokePx / 2f, Offset(pts[0].x * w, pts[0].y * h))
        return
    }
    val path = Path()
    path.moveTo(pts[0].x * w, pts[0].y * h)
    for (i in 1 until pts.size) {
        val p0 = pts[i - 1]
        val p1 = pts[i]
        path.quadraticBezierTo(p0.x * w, p0.y * h, (p0.x + p1.x) / 2f * w, (p0.y + p1.y) / 2f * h)
    }
    path.lineTo(pts.last().x * w, pts.last().y * h)
    drawPath(path, color, style = Stroke(width = strokePx, cap = cap, join = StrokeJoin.Round))
}

/** A variable-width stroke drawn as one filled outline, so translucent brushes don't darken where segments meet. */
private fun DrawScope.drawBrush(pts: List<Pt>, mult: List<Float>, color: Color, basePx: Float) {
    if (pts.isEmpty()) return
    val w = size.width
    val h = size.height
    if (pts.size < 2) {
        drawCircle(color, basePx * mult.getOrElse(0) { 1f } / 2f, Offset(pts[0].x * w, pts[0].y * h))
        return
    }
    val rb = ribbon(pts, mult, basePx, w, h)
    val l = rb.left
    val r = rb.right
    val path = Path()
    path.moveTo(l[0].x, l[0].y)
    for (i in 1 until l.size) path.quadraticBezierTo(l[i - 1].x, l[i - 1].y, (l[i - 1].x + l[i].x) / 2f, (l[i - 1].y + l[i].y) / 2f)
    path.lineTo(l.last().x, l.last().y)
    path.lineTo(r.last().x, r.last().y)
    for (i in r.size - 2 downTo 0) path.quadraticBezierTo(r[i + 1].x, r[i + 1].y, (r[i + 1].x + r[i].x) / 2f, (r[i + 1].y + r[i].y) / 2f)
    path.lineTo(r[0].x, r[0].y)
    path.close()
    drawPath(path, color, style = Fill)
    if (color.alpha >= 0.99f) {
        // round the two ends (skipped when translucent so they don't show as darker dots)
        drawCircle(color, basePx * mult.first() / 2f, Offset(pts.first().x * w, pts.first().y * h))
        drawCircle(color, basePx * mult.last() / 2f, Offset(pts.last().x * w, pts.last().y * h))
    }
}

// ------------------------------------------------------------------ hit testing (pixel space)

private fun distToSegment(p: Offset, a: Offset, b: Offset): Float = segDist(p.x, p.y, a.x, a.y, b.x, b.y)

internal fun Annot.hit(p: Offset, w: Float, h: Float, tol: Float): Boolean {
    val ms = min(w, h)
    val first = points.firstOrNull() ?: return false
    return when (type) {
        AnnotType.TEXT -> {
            val lines = text.split("\n")
            val tw = (lines.maxOfOrNull { it.length } ?: 1) * width * ms * 0.55f
            val th = lines.size * width * ms * 1.25f
            p.x in (first.x * w - tol)..(first.x * w + tol + tw) &&
                p.y in (first.y * h - tol)..(first.y * h + th + tol)
        }
        AnnotType.NOTE -> {
            val sz = max(12f, width * ms)
            p.x in (first.x * w - tol)..(first.x * w + sz + tol) && p.y in (first.y * h - tol)..(first.y * h + sz + tol)
        }
        AnnotType.MARK_HIGHLIGHT, AnnotType.MARK_UNDERLINE, AnnotType.MARK_STRIKE, AnnotType.MARK_SQUIGGLY -> {
            var inside = false
            var i = 0
            while (i + 1 < points.size && !inside) {
                val a = points[i]
                val b = points[i + 1]
                i += 2
                inside = p.x in (min(a.x, b.x) * w - tol)..(max(a.x, b.x) * w + tol) &&
                    p.y in (min(a.y, b.y) * h - tol)..(max(a.y, b.y) * h + tol)
            }
            inside
        }
        AnnotType.SHAPE_LINE, AnnotType.SHAPE_ARROW, AnnotType.SHAPE_DOUBLE_ARROW -> {
            points.size >= 2 && distToSegment(
                p,
                Offset(points[0].x * w, points[0].y * h),
                Offset(points[1].x * w, points[1].y * h),
            ) <= tol + width * ms / 2f
        }
        AnnotType.AREA, AnnotType.SHAPE_RECT -> {
            if (points.size < 2) {
                false
            } else {
                val l = min(points[0].x, points[1].x) * w
                val r = max(points[0].x, points[1].x) * w
                val t = min(points[0].y, points[1].y) * h
                val b = max(points[0].y, points[1].y) * h
                val outer = p.x in (l - tol)..(r + tol) && p.y in (t - tol)..(b + tol)
                val inner = p.x in (l + tol)..(r - tol) && p.y in (t + tol)..(b - tol)
                // area highlights and filled boxes are solid targets; plain outlines only react near the edge
                outer && (type == AnnotType.AREA || fillAlpha > 0f || !inner)
            }
        }
        AnnotType.SHAPE_OVAL -> {
            if (points.size < 2) {
                false
            } else {
                val cx = (points[0].x + points[1].x) / 2f * w
                val cy = (points[0].y + points[1].y) / 2f * h
                val rx = max(abs(points[1].x - points[0].x) / 2f * w, 1f)
                val ry = max(abs(points[1].y - points[0].y) / 2f * h, 1f)
                val d = sqrt(((p.x - cx) / rx) * ((p.x - cx) / rx) + ((p.y - cy) / ry) * ((p.y - cy) / ry))
                if (fillAlpha > 0f && d <= 1f) true else abs(d - 1f) * min(rx, ry) <= tol + width * ms / 2f
            }
        }
        AnnotType.SHAPE_TRIANGLE, AnnotType.SHAPE_DIAMOND -> {
            if (points.size < 2) {
                false
            } else {
                val l = min(points[0].x, points[1].x) * w
                val r = max(points[0].x, points[1].x) * w
                val t = min(points[0].y, points[1].y) * h
                val b = max(points[0].y, points[1].y) * h
                val v = shapeVerts(type, l, t, r, b)
                if (fillAlpha > 0f && insidePolygon(p, v)) {
                    true
                } else {
                    v.indices.any { i -> distToSegment(p, v[i], v[(i + 1) % v.size]) <= tol + width * ms / 2f }
                }
            }
        }
        AnnotType.INK, AnnotType.HIGHLIGHT -> {
            val reach = tol + width * ms * (if (brush == BrushType.BRUSH) 0.75f else 0.5f)
            if (points.size == 1) {
                hypot(p.x - first.x * w, p.y - first.y * h) <= reach
            } else {
                points.zipWithNext().any { (a, b) ->
                    distToSegment(p, Offset(a.x * w, a.y * h), Offset(b.x * w, b.y * h)) <= reach
                }
            }
        }
    }
}
