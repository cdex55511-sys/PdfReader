package com.example.pdfreader.ui

import android.os.Bundle
import android.os.CancellationSignal
import android.os.ParcelFileDescriptor
import android.print.PageRange
import android.print.PrintAttributes
import android.print.PrintDocumentAdapter
import android.print.PrintDocumentInfo
import androidx.compose.foundation.clickable
import androidx.compose.foundation.horizontalScroll
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.heightIn
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.itemsIndexed
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.text.KeyboardActions
import androidx.compose.foundation.text.KeyboardOptions
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Close
import androidx.compose.material.icons.filled.Delete
import androidx.compose.material3.AlertDialog
import androidx.compose.material3.CircularProgressIndicator
import androidx.compose.material3.ExperimentalMaterial3Api
import androidx.compose.material3.FilterChip
import androidx.compose.material3.HorizontalDivider
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.ListItem
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.ModalBottomSheet
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.Slider
import androidx.compose.material3.Switch
import androidx.compose.material3.Tab
import androidx.compose.material3.TabRow
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableIntStateOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.focus.FocusRequester
import androidx.compose.ui.focus.focusRequester
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.input.ImeAction
import androidx.compose.ui.text.input.KeyboardType
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import com.example.pdfreader.data.Annot
import com.example.pdfreader.data.AnnotType
import com.example.pdfreader.data.ColorMode
import com.example.pdfreader.data.ViewMode
import java.io.File
import java.io.FileInputStream
import java.io.FileOutputStream
import java.util.UUID

// ------------------------------------------------------------------ bookmarks + table of contents

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun ContentsSheet(session: DocSession, onDismiss: () -> Unit) {
    val context = LocalContext.current
    var tab by remember { mutableIntStateOf(0) }
    LaunchedEffect(Unit) { session.ensureOutline(context) }

    ModalBottomSheet(onDismissRequest = onDismiss) {
        TabRow(selectedTabIndex = tab) {
            Tab(selected = tab == 0, onClick = { tab = 0 }, text = { Text("Bookmarks") })
            Tab(selected = tab == 1, onClick = { tab = 1 }, text = { Text("Contents") })
        }
        if (tab == 0) {
            if (session.meta.bookmarks.isEmpty()) {
                EmptyNote("No bookmarks yet. Tap the bookmark icon in the top bar to save your place.")
            } else {
                LazyColumn(Modifier.heightIn(max = 480.dp)) {
                    items(session.meta.bookmarks, key = { it.page }) { b ->
                        ListItem(
                            headlineContent = { Text(b.title) },
                            supportingContent = { Text(relativeTime(b.createdAt)) },
                            trailingContent = {
                                IconButton(onClick = { session.removeBookmark(b) }) { Icon(Icons.Default.Delete, "Remove bookmark") }
                            },
                            modifier = Modifier.clickable { session.jump(b.page); onDismiss() },
                        )
                        HorizontalDivider()
                    }
                }
            }
        } else {
            val outline = session.outline
            when {
                outline == null -> Row(Modifier.fillMaxWidth().padding(24.dp), horizontalArrangement = Arrangement.Center) { CircularProgressIndicator() }
                outline.isEmpty() -> EmptyNote("This PDF has no table of contents.")
                else -> LazyColumn(Modifier.heightIn(max = 480.dp)) {
                    items(outline) { e ->
                        Row(
                            Modifier.fillMaxWidth().clickable { session.jump(e.page); onDismiss() }
                                .padding(start = (16 + e.level * 16).dp, end = 16.dp, top = 12.dp, bottom = 12.dp),
                            verticalAlignment = Alignment.CenterVertically,
                        ) {
                            Text(e.title, Modifier.weight(1f), maxLines = 2, overflow = TextOverflow.Ellipsis)
                            Text("${e.page + 1}", style = MaterialTheme.typography.labelMedium, color = MaterialTheme.colorScheme.onSurfaceVariant)
                        }
                    }
                }
            }
        }
        androidx.compose.foundation.layout.Spacer(Modifier.size(24.dp))
    }
}

@Composable
private fun EmptyNote(text: String) {
    Text(text, Modifier.padding(24.dp), style = MaterialTheme.typography.bodyMedium, color = MaterialTheme.colorScheme.onSurfaceVariant)
}

// ------------------------------------------------------------------ search

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun SearchSheet(session: DocSession, onDismiss: () -> Unit) {
    val context = LocalContext.current
    var query by remember { mutableStateOf(session.searchQuery) }
    val focus = remember { FocusRequester() }
    LaunchedEffect(Unit) { if (session.searchHits.isEmpty()) focus.requestFocus() }

    ModalBottomSheet(onDismissRequest = onDismiss) {
        OutlinedTextField(
            value = query,
            onValueChange = { query = it },
            modifier = Modifier.fillMaxWidth().padding(horizontal = 16.dp).focusRequester(focus),
            singleLine = true,
            label = { Text("Search in document") },
            trailingIcon = {
                if (query.isNotEmpty()) IconButton(onClick = { query = ""; session.clearSearch() }) { Icon(Icons.Default.Close, "Clear") }
            },
            keyboardOptions = KeyboardOptions(imeAction = ImeAction.Search),
            keyboardActions = KeyboardActions(onSearch = { session.search(context, query) }),
        )
        if (session.searching) {
            Row(Modifier.fillMaxWidth().padding(12.dp), horizontalArrangement = Arrangement.Center) {
                CircularProgressIndicator(Modifier.size(24.dp), strokeWidth = 2.dp)
            }
        }
        if (!session.searching && session.searchHits.isEmpty() && session.searchQuery.isNotBlank()) {
            EmptyNote("No matches. Scanned PDFs without a text layer can't be searched.")
        }
        LazyColumn(Modifier.heightIn(max = 460.dp)) {
            itemsIndexed(session.searchHits) { i, hit ->
                ListItem(
                    headlineContent = { Text(hit.snippet, maxLines = 2, overflow = TextOverflow.Ellipsis) },
                    supportingContent = { Text("Page ${hit.page + 1}") },
                    modifier = Modifier.clickable { session.gotoHit(i); onDismiss() },
                )
                HorizontalDivider()
            }
        }
        androidx.compose.foundation.layout.Spacer(Modifier.size(24.dp))
    }
}

// ------------------------------------------------------------------ view + reading mode

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun ViewSheet(vm: AppViewModel, session: DocSession, onDismiss: () -> Unit) {
    ModalBottomSheet(onDismissRequest = onDismiss) {
        Column(Modifier.padding(horizontal = 20.dp).verticalScroll(rememberScrollState()), verticalArrangement = Arrangement.spacedBy(10.dp)) {
            Text("Page layout", style = MaterialTheme.typography.titleSmall)
            ViewMode.entries.forEach { mode ->
                FilterChip(
                    selected = session.meta.viewMode == mode,
                    onClick = { session.setViewMode(mode) },
                    label = { Text(mode.label) },
                )
            }
            Text("Reading mode", style = MaterialTheme.typography.titleSmall, modifier = Modifier.padding(top = 8.dp))
            Row(horizontalArrangement = Arrangement.spacedBy(8.dp), modifier = Modifier.horizontalScrollCompat()) {
                ColorMode.entries.forEach { mode ->
                    FilterChip(
                        selected = session.meta.colorMode == mode,
                        onClick = { session.setColorMode(mode) },
                        label = { Text(mode.label) },
                    )
                }
            }
            SwitchRow("Keep screen on", vm.keepScreenOnEnabled) { vm.setKeepScreenOn(it) }
            SwitchRow("Volume keys turn pages", vm.volumePagingEnabled) { vm.setVolumePaging(it) }
            SwitchRow("Auto-scroll", session.autoScroll) { session.autoScroll = it }
            if (session.autoScroll) {
                Text("Auto-scroll speed", style = MaterialTheme.typography.labelLarge)
                Slider(value = session.autoSpeed, onValueChange = { session.autoSpeed = it })
            }
            androidx.compose.foundation.layout.Spacer(Modifier.size(24.dp))
        }
    }
}

@Composable
private fun Modifier.horizontalScrollCompat(): Modifier = this.then(Modifier.horizontalScroll(rememberScrollState()))

@Composable
private fun SwitchRow(label: String, checked: Boolean, onChange: (Boolean) -> Unit) {
    Row(Modifier.fillMaxWidth(), verticalAlignment = Alignment.CenterVertically) {
        Text(label, Modifier.weight(1f))
        Switch(checked = checked, onCheckedChange = onChange)
    }
}

// ------------------------------------------------------------------ dialogs

@Composable
fun GoToPageDialog(session: DocSession, onDismiss: () -> Unit) {
    var text by remember { mutableStateOf("") }
    val total = session.engine.pageCount
    AlertDialog(
        onDismissRequest = onDismiss,
        title = { Text("Go to page") },
        text = {
            OutlinedTextField(
                value = text,
                onValueChange = { text = it.filter(Char::isDigit).take(6) },
                singleLine = true,
                label = { Text("1 – $total") },
                keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Number, imeAction = ImeAction.Go),
                keyboardActions = KeyboardActions(onGo = {
                    text.toIntOrNull()?.let { session.jump(it - 1) }
                    onDismiss()
                }),
            )
        },
        confirmButton = {
            TextButton(onClick = {
                text.toIntOrNull()?.let { session.jump(it - 1) }
                onDismiss()
            }) { Text("Go") }
        },
        dismissButton = { TextButton(onClick = onDismiss) { Text("Cancel") } },
    )
}

private val textSizes = listOf("Small" to 0.018f, "Medium" to 0.026f, "Large" to 0.038f)

@Composable
fun TextAnnotDialog(session: DocSession, edit: TextEdit) {
    var text by remember(edit) { mutableStateOf(edit.existing?.text.orEmpty()) }
    var size by remember(edit) { mutableStateOf(edit.existing?.width ?: session.styleOf(StyleKey.TEXT).width) }
    val close = { session.textEdit = null }

    AlertDialog(
        onDismissRequest = close,
        title = { Text(if (edit.existing == null) "Add text" else "Edit text") },
        text = {
            Column(verticalArrangement = Arrangement.spacedBy(12.dp)) {
                OutlinedTextField(
                    value = text,
                    onValueChange = { text = it },
                    label = { Text("Text (use new lines to wrap)") },
                    minLines = 2,
                    maxLines = 6,
                )
                Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                    textSizes.forEach { (label, value) ->
                        FilterChip(selected = kotlin.math.abs(size - value) < 0.002f, onClick = { size = value }, label = { Text(label) })
                    }
                }
                Slider(value = size.coerceIn(0.012f, 0.06f), onValueChange = { size = it }, valueRange = 0.012f..0.06f)
            }
        },
        confirmButton = {
            TextButton(
                enabled = text.isNotBlank(),
                onClick = {
                    val existing = edit.existing
                    if (existing == null) {
                        session.updateStyle(StyleKey.TEXT) { it.copy(width = size) }
                        session.addAnnot(session.styledAnnot(edit.page, AnnotType.TEXT, StyleKey.TEXT, listOf(edit.at), text = text))
                    } else {
                        session.replaceAnnot(existing.copy(text = text, width = size))
                    }
                    close()
                },
            ) { Text("Save") }
        },
        dismissButton = {
            Row {
                edit.existing?.let { ex ->
                    TextButton(onClick = { session.removeAnnots(setOf(ex.id)); close() }) { Text("Delete") }
                }
                TextButton(onClick = close) { Text("Cancel") }
            }
        },
    )
}

// ------------------------------------------------------------------ printing

class FilePrintAdapter(private val file: File, private val name: String) : PrintDocumentAdapter() {
    override fun onLayout(
        oldAttributes: PrintAttributes?,
        newAttributes: PrintAttributes?,
        cancellationSignal: CancellationSignal?,
        callback: LayoutResultCallback,
        extras: Bundle?,
    ) {
        if (cancellationSignal?.isCanceled == true) {
            callback.onLayoutCancelled()
            return
        }
        val info = PrintDocumentInfo.Builder("$name.pdf")
            .setContentType(PrintDocumentInfo.CONTENT_TYPE_DOCUMENT)
            .setPageCount(PrintDocumentInfo.PAGE_COUNT_UNKNOWN)
            .build()
        callback.onLayoutFinished(info, true)
    }

    override fun onWrite(
        pages: Array<out PageRange>?,
        destination: ParcelFileDescriptor,
        cancellationSignal: CancellationSignal?,
        callback: WriteResultCallback,
    ) {
        try {
            FileInputStream(file).use { input ->
                FileOutputStream(destination.fileDescriptor).use { output -> input.copyTo(output) }
            }
            callback.onWriteFinished(arrayOf(PageRange.ALL_PAGES))
        } catch (e: Exception) {
            callback.onWriteFailed(e.message)
        }
    }
}

/** Read, write or delete the text of a sticky note. */
@Composable
fun NoteDialog(session: DocSession, edit: NoteEdit) {
    var text by remember(edit) { mutableStateOf(edit.existing?.text ?: "") }
    val existing = edit.existing
    AlertDialog(
        onDismissRequest = { session.noteEdit = null },
        title = { Text(if (existing == null) "New note" else "Note") },
        text = {
            OutlinedTextField(
                value = text,
                onValueChange = { text = it },
                modifier = Modifier.fillMaxWidth(),
                minLines = 3,
                maxLines = 8,
                placeholder = { Text("Write your note…") },
            )
        },
        confirmButton = {
            TextButton(
                enabled = text.isNotBlank(),
                onClick = {
                    if (existing == null) {
                        session.addAnnot(session.styledAnnot(edit.page, AnnotType.NOTE, StyleKey.NOTE, listOf(edit.at), text = text.trim()))
                    } else {
                        session.replaceAnnot(existing.copy(text = text.trim()))
                    }
                    session.noteEdit = null
                },
            ) { Text("Save") }
        },
        dismissButton = {
            Row {
                if (existing != null) {
                    TextButton(onClick = { session.removeAnnots(setOf(existing.id)); session.noteEdit = null }) { Text("Delete") }
                }
                TextButton(onClick = { session.noteEdit = null }) { Text("Cancel") }
            }
        },
    )
}
