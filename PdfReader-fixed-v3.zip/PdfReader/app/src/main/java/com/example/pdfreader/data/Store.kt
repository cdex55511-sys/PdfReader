package com.example.pdfreader.data

import android.content.Context
import kotlinx.serialization.decodeFromString
import kotlinx.serialization.encodeToString
import kotlinx.serialization.json.Json
import java.io.File

/**
 * Tiny file-based persistence. Each document gets a folder:
 *   library/<id>/doc.pdf      working copy (imported once, edited in place by page operations)
 *   library/<id>/meta.json    DocMeta (last page, bookmarks, view prefs…)
 *   library/<id>/annots.json  editable annotation overlay
 *   library/<id>/ocr.json     recognised text for scanned pages
 *   library/<id>/thumb.jpg    first-page thumbnail
 */
class Store(context: Context) {
    private val json = Json { ignoreUnknownKeys = true; encodeDefaults = true }
    private val root = File(context.filesDir, "library").apply { mkdirs() }

    fun dir(id: String): File = File(root, id).apply { mkdirs() }
    fun pdf(id: String): File = File(dir(id), "doc.pdf")
    fun thumb(id: String): File = File(dir(id), "thumb.jpg")

    fun loadAll(): List<DocMeta> =
        root.listFiles().orEmpty()
            .filter { it.isDirectory && File(it, "doc.pdf").exists() }
            .mapNotNull { loadMeta(it.name) }
            .sortedByDescending { it.lastOpened }

    fun loadMeta(id: String): DocMeta? =
        runCatching { json.decodeFromString<DocMeta>(File(root, "$id/meta.json").readText()) }.getOrNull()

    fun saveMeta(meta: DocMeta) = write(File(dir(meta.id), "meta.json"), json.encodeToString(meta))

    fun loadAnnots(id: String): List<Annot> =
        runCatching { json.decodeFromString<List<Annot>>(File(root, "$id/annots.json").readText()) }
            .getOrDefault(emptyList())

    fun saveAnnots(id: String, list: List<Annot>) =
        write(File(dir(id), "annots.json"), json.encodeToString(list))

    fun loadOcr(id: String): Map<Int, List<OcrWord>> =
        runCatching { json.decodeFromString<Map<Int, List<OcrWord>>>(File(root, "$id/ocr.json").readText()) }
            .getOrDefault(emptyMap())

    fun saveOcr(id: String, map: Map<Int, List<OcrWord>>) {
        val f = File(dir(id), "ocr.json")
        if (map.isEmpty()) f.delete() else write(f, json.encodeToString(map))
    }

    fun delete(id: String) {
        File(root, id).deleteRecursively()
    }

    private fun write(f: File, text: String) {
        val tmp = File(f.parentFile, f.name + ".tmp")
        tmp.writeText(text)
        if (!tmp.renameTo(f)) {
            f.writeText(text)
            tmp.delete()
        }
    }
}
