package com.example.pdfreader.ui

import androidx.compose.animation.core.animate
import androidx.compose.animation.core.tween
import androidx.compose.foundation.gestures.awaitEachGesture
import androidx.compose.foundation.gestures.awaitFirstDown
import androidx.compose.foundation.gestures.calculateCentroid
import androidx.compose.foundation.gestures.calculatePan
import androidx.compose.foundation.gestures.calculateZoom
import androidx.compose.foundation.gestures.detectTapGestures
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.BoxScope
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.runtime.Composable
import androidx.compose.runtime.Stable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableFloatStateOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.rememberCoroutineScope
import androidx.compose.runtime.rememberUpdatedState
import androidx.compose.runtime.setValue
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clipToBounds
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.graphics.TransformOrigin
import androidx.compose.ui.graphics.graphicsLayer
import androidx.compose.ui.input.pointer.PointerEventPass
import androidx.compose.ui.input.pointer.pointerInput
import androidx.compose.ui.input.pointer.positionChanged
import androidx.compose.ui.input.pointer.util.VelocityTracker
import androidx.compose.ui.layout.onSizeChanged
import androidx.compose.ui.unit.IntSize
import kotlinx.coroutines.launch

private const val MAX_ZOOM = 6f

/**
 * [scale]/[offset] drive the instant (GPU) transform while pinching.
 * [settledScale] only changes when the gesture ends; pages use it to re-render at a sharper resolution.
 */
@Stable
class ZoomState {
    var scale by mutableFloatStateOf(1f)
    var offsetX by mutableFloatStateOf(0f)
    var offsetY by mutableFloatStateOf(0f)
    var settledScale by mutableFloatStateOf(1f)

    fun reset() {
        scale = 1f
        offsetX = 0f
        offsetY = 0f
        settledScale = 1f
    }
}

/**
 * Pinch-to-zoom, pan and double-tap-zoom wrapper.
 *
 * - [scrollBy] != null (continuous mode): vertical movement is delegated to the list's scroll state, so the
 *   list keeps its native scrolling/fling at 1x and we only add horizontal panning when zoomed.
 * - [scrollBy] == null (paged modes): both axes are panned with [ZoomState.offsetX]/[ZoomState.offsetY].
 * - [onFling]: called when a one-finger pan of a zoomed page is released, with the list-space velocity
 *   (positive = scroll forward) so the host can continue the motion; this is what keeps fast flicks fast while zoomed.
 * - [drawingActive]: a single finger belongs to the annotation tool; only two-finger gestures are handled here.
 */
@Composable
fun ZoomContainer(
    zoom: ZoomState,
    drawingActive: Boolean,
    scrollBy: ((Float) -> Unit)?,
    onTap: (Offset, IntSize) -> Unit,
    modifier: Modifier = Modifier,
    onFling: ((Float) -> Unit)? = null,
    content: @Composable BoxScope.() -> Unit,
) {
    var boxSize by remember { mutableStateOf(IntSize.Zero) }
    val scope = rememberCoroutineScope()
    val currentScrollBy by rememberUpdatedState(scrollBy)
    val currentOnTap by rememberUpdatedState(onTap)
    val currentOnFling by rememberUpdatedState(onFling)
    val drawing by rememberUpdatedState(drawingActive)
    val tracker = remember { VelocityTracker() }

    fun clamp() {
        val w = boxSize.width.toFloat()
        val h = boxSize.height.toFloat()
        zoom.offsetX = zoom.offsetX.coerceIn(w * (1f - zoom.scale), 0f)
        zoom.offsetY = if (currentScrollBy != null) 0f else zoom.offsetY.coerceIn(h * (1f - zoom.scale), 0f)
    }

    fun zoomAround(target: Float, cx: Float, cy: Float) {
        val old = zoom.scale
        val ns = target.coerceIn(1f, MAX_ZOOM)
        if (ns == old) return
        val f = ns / old
        zoom.offsetX = cx - (cx - zoom.offsetX) * f
        val sb = currentScrollBy
        if (sb != null) sb(cy / old - cy / ns) else zoom.offsetY = cy - (cy - zoom.offsetY) * f
        zoom.scale = ns
        clamp()
    }

    Box(
        modifier
            .fillMaxSize()
            .clipToBounds()
            .onSizeChanged { boxSize = it }
            .pointerInput(drawingActive) {
                if (!drawingActive) {
                    detectTapGestures(
                        onTap = { currentOnTap(it, boxSize) },
                        onDoubleTap = { pos ->
                            scope.launch {
                                val from = zoom.scale
                                val to = if (from > 1.05f) 1f else 2.5f
                                animate(from, to, animationSpec = tween(220)) { v, _ -> zoomAround(v, pos.x, pos.y) }
                                zoom.settledScale = zoom.scale
                            }
                        },
                    )
                }
            }
            .pointerInput(Unit) {
                awaitEachGesture {
                    awaitFirstDown(requireUnconsumed = false, pass = PointerEventPass.Initial)
                    tracker.resetTracking()
                    var panned = false
                    do {
                        val event = awaitPointerEvent(PointerEventPass.Initial)
                        val pressed = event.changes.count { it.pressed }
                        val zoomed = zoom.scale > 1.01f
                        if (pressed >= 2 || (zoomed && !drawing)) {
                            val z = event.calculateZoom()
                            val pan = event.calculatePan()
                            val c = event.calculateCentroid()
                            if (z != 1f || pan != Offset.Zero) {
                                if (z != 1f && c != Offset.Unspecified) zoomAround(zoom.scale * z, c.x, c.y)
                                zoom.offsetX += pan.x
                                val sb = currentScrollBy
                                if (sb != null) sb(-pan.y / zoom.scale) else zoom.offsetY += pan.y
                                clamp()
                                if (pressed == 1) {
                                    panned = true
                                    event.changes.firstOrNull { it.pressed }?.let { tracker.addPosition(it.uptimeMillis, it.position) }
                                } else {
                                    panned = false
                                }
                                event.changes.forEach { if (it.positionChanged()) it.consume() }
                            }
                        }
                    } while (event.changes.any { it.pressed })
                    zoom.settledScale = zoom.scale
                    if (panned && zoom.scale > 1.01f && currentScrollBy != null) {
                        // Finger velocity is in screen pixels; the list lives in 1/scale of that
                        val vy = tracker.calculateVelocity().y
                        if (kotlin.math.abs(vy) > 200f) currentOnFling?.invoke(-vy / zoom.scale)
                    }
                }
            },
    ) {
        Box(
            Modifier
                .fillMaxSize()
                .graphicsLayer {
                    transformOrigin = TransformOrigin(0f, 0f)
                    scaleX = zoom.scale
                    scaleY = zoom.scale
                    translationX = zoom.offsetX
                    translationY = zoom.offsetY
                },
            content = content,
        )
    }
}
