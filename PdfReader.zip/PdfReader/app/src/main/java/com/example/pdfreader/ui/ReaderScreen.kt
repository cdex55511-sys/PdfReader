package com.example.pdfreader.ui

import android.content.Context
import android.content.Intent
import android.print.PrintAttributes
import android.print.PrintManager
import android.widget.Toast
import androidx.activity.compose.BackHandler
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.animation.AnimatedVisibility
import androidx.compose.animation.core.AnimationState
import androidx.compose.animation.core.animateDecay
import androidx.compose.animation.fadeIn
import androidx.compose.animation.fadeOut
import androidx.compose.animation.rememberSplineBasedDecay
import androidx.compose.animation.slideInVertically
import androidx.compose.animation.slideOutVertically
import androidx.compose.foundation.BorderStroke
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.gestures.FlingBehavior
import androidx.compose.foundation.gestures.ScrollScope
import androidx.compose.foundation.gestures.ScrollableDefaults
import androidx.compose.foundation.gestures.scrollBy
import androidx.compose.foundation.horizontalScroll
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.BoxWithConstraints
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.WindowInsets
import androidx.compose.foundation.layout.asPaddingValues
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.navigationBars
import androidx.compose.foundation.layout.navigationBarsPadding
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.statusBars
import androidx.compose.foundation.layout.statusBarsPadding
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.LazyListState
import androidx.compose.foundation.lazy.LazyRow
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.lazy.rememberLazyListState
import androidx.compose.foundation.pager.HorizontalPager
import androidx.compose.foundation.pager.PagerDefaults
import androidx.compose.foundation.pager.PagerSnapDistance
import androidx.compose.foundation.pager.VerticalPager
import androidx.compose.foundation.pager.rememberPagerState
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.filled.ArrowBack
import androidx.compose.material.icons.automirrored.filled.Backspace
import androidx.compose.material.icons.automirrored.filled.Redo
import androidx.compose.material.icons.automirrored.filled.Undo
import androidx.compose.material.icons.filled.Add
import androidx.compose.material.icons.filled.ArrowRightAlt
import androidx.compose.material.icons.filled.Bookmark
import androidx.compose.material.icons.filled.BookmarkBorder
import androidx.compose.material.icons.filled.Close
import androidx.compose.material.icons.filled.ContentCopy
import androidx.compose.material.icons.filled.CropSquare
import androidx.compose.material.icons.filled.Done
import androidx.compose.material.icons.filled.Edit
import androidx.compose.material.icons.filled.FormatListNumbered
import androidx.compose.material.icons.filled.FormatStrikethrough
import androidx.compose.material.icons.filled.FormatUnderlined
import androidx.compose.material.icons.filled.GridView
import androidx.compose.material.icons.filled.Highlight
import androidx.compose.material.icons.filled.Home
import androidx.compose.material.icons.filled.HorizontalRule
import androidx.compose.material.icons.filled.Info
import androidx.compose.material.icons.filled.KeyboardArrowDown
import androidx.compose.material.icons.filled.KeyboardArrowUp
import androidx.compose.material.icons.filled.Lock
import androidx.compose.material.icons.filled.MoreVert
import androidx.compose.material.icons.filled.NoteAdd
import androidx.compose.material.icons.filled.Pause
import androidx.compose.material.icons.filled.PlayArrow
import androidx.compose.material.icons.filled.Print
import androidx.compose.material.icons.filled.RadioButtonUnchecked
import androidx.compose.material.icons.filled.SaveAlt
import androidx.compose.material.icons.filled.Scanner
import androidx.compose.material.icons.filled.Search
import androidx.compose.material.icons.filled.Share
import androidx.compose.material.icons.filled.TextFields
import androidx.compose.material.icons.filled.Toc
import androidx.compose.material.icons.filled.Tune
import androidx.compose.material.icons.filled.ViewModule
import androidx.compose.material3.DropdownMenu
import androidx.compose.material3.DropdownMenuItem
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.IconButtonDefaults
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.Slider
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.DisposableEffect
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.rememberCoroutineScope
import androidx.compose.runtime.setValue
import androidx.compose.runtime.snapshotFlow
import androidx.compose.runtime.withFrameNanos
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.vector.ImageVector
import androidx.compose.ui.platform.LocalClipboardManager
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.platform.LocalDensity
import androidx.compose.ui.platform.LocalView
import androidx.compose.ui.text.AnnotatedString
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import androidx.core.view.WindowCompat
import androidx.core.view.WindowInsetsCompat
import androidx.core.view.WindowInsetsControllerCompat
import com.example.pdfreader.data.AnnotType
import com.example.pdfreader.data.ViewMode
import kotlinx.coroutines.CancellationException
import kotlinx.coroutines.currentCoroutineContext
import kotlinx.coroutines.delay
import kotlinx.coroutines.ensureActive
import kotlinx.coroutines.flow.distinctUntilChanged
import kotlinx.coroutines.launch
import kotlin.math.abs
import kotlin.math.min
import kotlin.math.roundToInt

private enum class Sheet { CONTENTS, SEARCH, VIEW, PAGES, OCR, ANNOTS }

/**
 * Makes fast flicks cover proportionally more ground: slow swipes are boosted a little, hard flicks a lot,
 * so scroll distance follows swipe speed rather than a fixed decay.
 */
private fun boostVelocity(v: Float): Float = v * (1.25f + min(abs(v) / 4000f, 2.2f))

private class SpeedFling(private val base: FlingBehavior) : FlingBehavior {
    override suspend fun ScrollScope.performFling(initialVelocity: Float): Float =
        with(base) { performFling(boostVelocity(initialVelocity)) }
}

@Composable
fun ReaderScreen(vm: AppViewModel, session: DocSession, onOpenPicker: () -> Unit) {
    val context = LocalContext.current
    val view = LocalView.current
    var chrome by remember(session.id) { mutableStateOf(true) }
    var sheet by remember(session.id) { mutableStateOf<Sheet?>(null) }
    var menu by remember { mutableStateOf(false) }
    var goTo by remember { mutableStateOf(false) }
    var organizing by remember(session.id) { mutableStateOf(false) }
    var showProperties by remember(session.id) { mutableStateOf(false) }
    var askPassword by remember(session.id) { mutableStateOf(false) }
    var pendingPassword by remember(session.id) { mutableStateOf<String?>(null) }

    val saveLauncher = rememberLauncherForActivityResult(ActivityResultContracts.CreateDocument("application/pdf")) { uri ->
        if (uri != null) vm.saveCopy(session, uri, pendingPassword)
        pendingPassword = null
    }

    BackHandler {
        when {
            organizing -> organizing = false
            sheet != null -> sheet = null
            session.selection != null -> session.clearSelection()
            session.selectedId != null -> session.selectedId = null
            session.tool != Tool.NONE -> session.tool = Tool.NONE
            else -> vm.showLibrary()
        }
    }

    // Immersive reading: hide system bars together with the chrome
    DisposableEffect(chrome) {
        val window = context.findActivity()?.window
        if (window != null) {
            val controller = WindowCompat.getInsetsController(window, view)
            if (chrome) {
                controller.show(WindowInsetsCompat.Type.systemBars())
            } else {
                controller.systemBarsBehavior = WindowInsetsControllerCompat.BEHAVIOR_SHOW_TRANSIENT_BARS_BY_SWIPE
                controller.hide(WindowInsetsCompat.Type.systemBars())
            }
        }
        onDispose {
            if (window != null) WindowCompat.getInsetsController(window, view).show(WindowInsetsCompat.Type.systemBars())
        }
    }
    DisposableEffect(vm.keepScreenOn) {
        view.keepScreenOn = vm.keepScreenOn
        onDispose { view.keepScreenOn = false }
    }

    Box(Modifier.fillMaxSize().background(deskBackground(session.meta.colorMode))) {
        ReaderPane(session, onAddPage = if (session.meta.template != null) ({ vm.addPage(session) }) else null) { chrome = !chrome }

        AnimatedVisibility(
            visible = chrome,
            enter = slideInVertically { -it } + fadeIn(),
            exit = slideOutVertically { -it } + fadeOut(),
            modifier = Modifier.align(Alignment.TopCenter),
        ) {
            Surface(tonalElevation = 3.dp, shadowElevation = 4.dp, color = MaterialTheme.colorScheme.surface.copy(alpha = 0.97f)) {
                Column(Modifier.statusBarsPadding()) {
                    TabStrip(vm, onOpenPicker)
                    Row(Modifier.fillMaxWidth().padding(start = 16.dp, end = 4.dp), verticalAlignment = Alignment.CenterVertically) {
                        Text(
                            session.meta.name,
                            Modifier.weight(1f),
                            style = MaterialTheme.typography.titleMedium,
                            maxLines = 1,
                            overflow = TextOverflow.Ellipsis,
                        )
                        IconButton(onClick = { session.toggleBookmark() }) {
                            Icon(
                                if (session.isBookmarked) Icons.Default.Bookmark else Icons.Default.BookmarkBorder,
                                "Bookmark this page",
                                tint = if (session.isBookmarked) MaterialTheme.colorScheme.primary else MaterialTheme.colorScheme.onSurfaceVariant,
                            )
                        }
                        IconButton(onClick = { sheet = Sheet.SEARCH }) { Icon(Icons.Default.Search, "Search") }
                        IconButton(
                            onClick = { session.tool = if (session.tool == Tool.NONE) Tool.PEN else Tool.NONE },
                            colors = if (session.tool != Tool.NONE)
                                IconButtonDefaults.iconButtonColors(containerColor = MaterialTheme.colorScheme.primaryContainer)
                            else IconButtonDefaults.iconButtonColors(),
                        ) { Icon(Icons.Default.Edit, "Annotate") }
                        Box {
                            IconButton(onClick = { menu = true }) { Icon(Icons.Default.MoreVert, "More") }
                            DropdownMenu(expanded = menu, onDismissRequest = { menu = false }) {
                                MenuItem("Bookmarks & contents", Icons.Default.Toc) { menu = false; sheet = Sheet.CONTENTS }
                                MenuItem("Thumbnails", Icons.Default.ViewModule) { menu = false; sheet = Sheet.PAGES }
                                MenuItem("View & reading mode", Icons.Default.Tune) { menu = false; sheet = Sheet.VIEW }
                                MenuItem("Go to page", Icons.Default.FormatListNumbered) { menu = false; goTo = true }
                                MenuItem("Add blank page", Icons.Default.NoteAdd) { menu = false; vm.addPage(session) }
                                MenuItem("Organize pages", Icons.Default.GridView) { menu = false; organizing = true }
                                MenuItem("Annotations list", Icons.Default.FormatListNumbered) { menu = false; sheet = Sheet.ANNOTS }
                                MenuItem("Recognize text (OCR)", Icons.Default.Scanner) { menu = false; sheet = Sheet.OCR }
                                MenuItem(
                                    if (session.autoScroll) "Stop auto-scroll" else "Auto-scroll",
                                    if (session.autoScroll) Icons.Default.Pause else Icons.Default.PlayArrow,
                                ) {
                                    menu = false
                                    session.autoScroll = !session.autoScroll
                                    if (session.autoScroll) chrome = false
                                }
                                MenuItem(if (session.meta.template != null) "Export as PDF…" else "Save a copy…", Icons.Default.SaveAlt) {
                                    menu = false
                                    pendingPassword = null
                                    saveLauncher.launch(session.meta.name + ".pdf")
                                }
                                MenuItem("Save with password…", Icons.Default.Lock) { menu = false; askPassword = true }
                                MenuItem("Share", Icons.Default.Share) { menu = false; vm.export(session) { vm.share(it) } }
                                MenuItem("Print", Icons.Default.Print) {
                                    menu = false
                                    vm.export(session) { file -> printFile(context, session.meta.name, file) }
                                }
                                MenuItem("Properties", Icons.Default.Info) { menu = false; showProperties = true }
                                MenuItem("Close tab", Icons.Default.Close) { menu = false; vm.closeTab(session.id) }
                            }
                        }
                    }
                }
            }
        }

        AnimatedVisibility(
            visible = chrome,
            enter = slideInVertically { it } + fadeIn(),
            exit = slideOutVertically { it } + fadeOut(),
            modifier = Modifier.align(Alignment.BottomCenter),
        ) {
            Surface(tonalElevation = 3.dp, shadowElevation = 4.dp, color = MaterialTheme.colorScheme.surface.copy(alpha = 0.97f)) {
                Column(Modifier.navigationBarsPadding()) {
                    if (session.tool != Tool.NONE) {
                        AnnotationBar(session)
                    } else {
                        PageBar(session, onGoTo = { goTo = true }, onAddPage = if (session.meta.template != null) ({ vm.addPage(session) }) else null)
                    }
                }
            }
        }

        if (session.searchHits.isNotEmpty() && sheet != Sheet.SEARCH) {
            SearchPill(session, Modifier.align(Alignment.BottomCenter).padding(bottom = 132.dp))
        }

        if (session.selection != null) {
            SelectionBar(
                session,
                Modifier.align(Alignment.TopCenter).statusBarsPadding().padding(top = if (chrome) 112.dp else 12.dp),
            )
        }

        session.returnPage?.let { back ->
            Surface(
                onClick = { session.goBackFromLink() },
                modifier = Modifier.align(Alignment.BottomStart).padding(start = 16.dp, bottom = 150.dp),
                shape = RoundedCornerShape(24.dp),
                tonalElevation = 6.dp,
                shadowElevation = 6.dp,
            ) {
                Row(Modifier.padding(horizontal = 14.dp, vertical = 10.dp), verticalAlignment = Alignment.CenterVertically) {
                    Icon(Icons.AutoMirrored.Filled.ArrowBack, null, Modifier.size(18.dp))
                    Text("  Back to page ${back + 1}", style = MaterialTheme.typography.labelLarge)
                }
            }
        }

        if (session.autoScroll) {
            Surface(
                modifier = Modifier.align(Alignment.BottomEnd).padding(end = 16.dp, bottom = 150.dp),
                shape = CircleShape,
                tonalElevation = 6.dp,
                shadowElevation = 6.dp,
            ) {
                IconButton(onClick = { session.autoScroll = false }) { Icon(Icons.Default.Pause, "Stop auto-scroll") }
            }
        }

        if (organizing) OrganizerScreen(vm, session) { organizing = false }
    }

    when (sheet) {
        Sheet.CONTENTS -> ContentsSheet(session) { sheet = null }
        Sheet.SEARCH -> SearchSheet(session) { sheet = null }
        Sheet.VIEW -> ViewSheet(vm, session) { sheet = null }
        Sheet.PAGES -> PagesSheet(session) { sheet = null }
        Sheet.OCR -> OcrSheet(vm, session) { sheet = null }
        Sheet.ANNOTS -> AnnotationsSheet(session) { sheet = null }
        null -> Unit
    }
    if (goTo) GoToPageDialog(session) { goTo = false }
    if (showProperties) PropertiesDialog(session) { showProperties = false }
    if (askPassword) {
        SavePasswordDialog(
            onConfirm = { pw ->
                askPassword = false
                pendingPassword = pw
                saveLauncher.launch(session.meta.name + " (protected).pdf")
            },
            onDismiss = { askPassword = false },
        )
    }
    session.textEdit?.let { TextAnnotDialog(session, it) }
    session.noteEdit?.let { NoteDialog(session, it) }
}

@Composable
private fun MenuItem(text: String, icon: ImageVector, onClick: () -> Unit) {
    DropdownMenuItem(text = { Text(text) }, leadingIcon = { Icon(icon, null) }, onClick = onClick)
}

private fun printFile(context: Context, name: String, file: java.io.File) {
    val pm = context.getSystemService(Context.PRINT_SERVICE) as PrintManager
    pm.print(name, FilePrintAdapter(file, name), PrintAttributes.Builder().build())
}

// ------------------------------------------------------------------ tabs

@Composable
private fun TabStrip(vm: AppViewModel, onOpenPicker: () -> Unit) {
    LazyRow(
        Modifier.fillMaxWidth(),
        contentPadding = PaddingValues(horizontal = 8.dp, vertical = 6.dp),
        horizontalArrangement = Arrangement.spacedBy(6.dp),
        verticalAlignment = Alignment.CenterVertically,
    ) {
        item {
            IconButton(onClick = { vm.showLibrary() }, Modifier.size(36.dp)) { Icon(Icons.Default.Home, "Library") }
        }
        items(vm.tabs.toList(), key = { it.id }) { tab ->
            val selected = tab.id == vm.activeId
            Surface(
                onClick = { vm.activate(tab.id) },
                shape = RoundedCornerShape(12.dp),
                color = if (selected) MaterialTheme.colorScheme.primaryContainer else MaterialTheme.colorScheme.surfaceVariant,
            ) {
                Row(Modifier.padding(start = 12.dp, end = 4.dp), verticalAlignment = Alignment.CenterVertically) {
                    Text(
                        tab.meta.name,
                        Modifier.width(110.dp),
                        style = MaterialTheme.typography.labelLarge,
                        maxLines = 1,
                        overflow = TextOverflow.Ellipsis,
                    )
                    IconButton(onClick = { vm.closeTab(tab.id) }, Modifier.size(28.dp)) {
                        Icon(Icons.Default.Close, "Close tab", Modifier.size(16.dp))
                    }
                }
            }
        }
        item {
            IconButton(onClick = onOpenPicker, Modifier.size(36.dp)) { Icon(Icons.Default.Add, "Open another PDF") }
        }
    }
}

// ------------------------------------------------------------------ bottom bars

@Composable
private fun PageBar(session: DocSession, onGoTo: () -> Unit, onAddPage: (() -> Unit)?) {
    val total = session.engine.pageCount
    Row(Modifier.fillMaxWidth().padding(horizontal = 16.dp, vertical = 8.dp), verticalAlignment = Alignment.CenterVertically) {
        Text(
            "${session.currentPage + 1} / $total",
            Modifier.clip(RoundedCornerShape(8.dp)).clickable(onClick = onGoTo).padding(horizontal = 8.dp, vertical = 6.dp),
            style = MaterialTheme.typography.labelLarge,
        )
        if (total > 1) {
            Slider(
                value = (session.currentPage + 1).toFloat(),
                onValueChange = { session.jump(it.roundToInt() - 1) },
                valueRange = 1f..total.toFloat(),
                modifier = Modifier.weight(1f).padding(start = 8.dp),
            )
        }
        if (onAddPage != null) {
            IconButton(onClick = onAddPage) { Icon(Icons.Default.NoteAdd, "Add a page") }
        }
    }
}

@Composable
private fun SearchPill(session: DocSession, modifier: Modifier) {
    Surface(modifier, shape = RoundedCornerShape(24.dp), tonalElevation = 6.dp, shadowElevation = 6.dp) {
        Row(Modifier.padding(horizontal = 6.dp), verticalAlignment = Alignment.CenterVertically) {
            Text(
                "${session.searchIndex + 1} / ${session.searchHits.size}",
                Modifier.padding(horizontal = 12.dp),
                style = MaterialTheme.typography.labelLarge,
            )
            IconButton(onClick = { session.gotoHit(session.searchIndex - 1) }) { Icon(Icons.Default.KeyboardArrowUp, "Previous match") }
            IconButton(onClick = { session.gotoHit(session.searchIndex + 1) }) { Icon(Icons.Default.KeyboardArrowDown, "Next match") }
            IconButton(onClick = { session.clearSearch() }) { Icon(Icons.Default.Close, "Clear search") }
        }
    }
}

/** Floating actions for the selected text: copy, markup, search, share. */
@Composable
private fun SelectionBar(session: DocSession, modifier: Modifier) {
    val context = LocalContext.current
    val clipboard = LocalClipboardManager.current
    val text = session.selectedText()
    Surface(modifier, shape = RoundedCornerShape(28.dp), tonalElevation = 6.dp, shadowElevation = 8.dp) {
        Row(Modifier.padding(horizontal = 4.dp), verticalAlignment = Alignment.CenterVertically) {
            IconButton(onClick = {
                text?.let {
                    clipboard.setText(AnnotatedString(it))
                    Toast.makeText(context, "Copied", Toast.LENGTH_SHORT).show()
                }
                session.clearSelection()
            }) { Icon(Icons.Default.ContentCopy, "Copy") }
            IconButton(onClick = { session.markSelection(AnnotType.MARK_HIGHLIGHT) }) { Icon(Icons.Default.Highlight, "Highlight") }
            IconButton(onClick = { session.markSelection(AnnotType.MARK_UNDERLINE) }) { Icon(Icons.Default.FormatUnderlined, "Underline") }
            IconButton(onClick = { session.markSelection(AnnotType.MARK_STRIKE) }) { Icon(Icons.Default.FormatStrikethrough, "Strikethrough") }
            IconButton(onClick = { session.markSelection(AnnotType.MARK_SQUIGGLY) }) {
                ShapeGlyph(Tool.SQUIGGLY, MaterialTheme.colorScheme.onSurface)
            }
            IconButton(onClick = {
                text?.let { session.search(context, it.replace('\n', ' ').take(80)) }
                session.clearSelection()
            }) { Icon(Icons.Default.Search, "Search for this text") }
            IconButton(onClick = {
                text?.let {
                    val send = Intent(Intent.ACTION_SEND).apply {
                        type = "text/plain"
                        putExtra(Intent.EXTRA_TEXT, it)
                    }
                    context.startActivity(Intent.createChooser(send, "Share text").addFlags(Intent.FLAG_ACTIVITY_NEW_TASK))
                }
            }) { Icon(Icons.Default.Share, "Share text") }
            IconButton(onClick = { session.clearSelection() }) { Icon(Icons.Default.Close, "Dismiss") }
        }
    }
}

// ------------------------------------------------------------------ reading surface

@Composable
private fun ReaderPane(session: DocSession, onAddPage: (() -> Unit)?, onToggleChrome: () -> Unit) {
    val engine = session.engine
    val zoom = session.zoom
    val drawing = session.tool != Tool.NONE
    val density = LocalDensity.current
    val scope = rememberCoroutineScope()

    BoxWithConstraints(Modifier.fillMaxSize()) {
        val wPx = constraints.maxWidth
        val hPx = constraints.maxHeight

        if (session.meta.viewMode == ViewMode.CONTINUOUS) {
            val sidePad = 8.dp
            val pageWidth = wPx - with(density) { (sidePad * 2).roundToPx() }
            val topPad = WindowInsets.statusBars.asPaddingValues().calculateTopPadding() + 112.dp
            val bottomPad = WindowInsets.navigationBars.asPaddingValues().calculateBottomPadding() + 96.dp
            val extraBottom = with(density) { (hPx * (1f - 1f / zoom.settledScale)).toDp() }
            val listState = rememberLazyListState(initialFirstVisibleItemIndex = session.currentPage)
            val baseFling = ScrollableDefaults.flingBehavior()
            val fling = remember(baseFling) { SpeedFling(baseFling) }
            val decay = rememberSplineBasedDecay<Float>()

            LaunchedEffect(engine) { session.jumps.collect { listState.scrollToItem(it) } }
            LaunchedEffect(listState) {
                snapshotFlow { centerPage(listState, zoom.settledScale) }
                    .distinctUntilChanged()
                    .collect { session.onPageChanged(it) }
            }
            // Hands-free reading: scroll at a steady speed until the end or until the user stops it
            LaunchedEffect(session.autoScroll, drawing) {
                if (!session.autoScroll || drawing) return@LaunchedEffect
                var last = withFrameNanos { it }
                while (true) {
                    val now = withFrameNanos { it }
                    val dt = (now - last) / 1_000_000_000f
                    last = now
                    if (zoom.scale > 1.01f) continue
                    val pxPerSecond = (30f + 570f * session.autoSpeed) * density.density
                    try {
                        listState.scrollBy(pxPerSecond * dt)
                    } catch (e: CancellationException) {
                        // a finger on the list interrupts our scroll; only a real cancellation ends the loop
                        currentCoroutineContext().ensureActive()
                    }
                    if (!listState.canScrollForward) {
                        session.autoScroll = false
                        break
                    }
                }
            }

            ZoomContainer(
                zoom = zoom,
                drawingActive = drawing,
                scrollBy = { listState.dispatchRawDelta(it) },
                onTap = { _, _ -> onToggleChrome() },
                onFling = { v ->
                    scope.launch {
                        listState.scroll {
                            var last = 0f
                            AnimationState(0f, boostVelocity(v)).animateDecay(decay) {
                                val d = value - last
                                last = value
                                val consumed = scrollBy(d)
                                if (abs(d - consumed) > 0.5f) cancelAnimation()
                            }
                        }
                    }
                },
            ) {
                LazyColumn(
                    state = listState,
                    userScrollEnabled = !drawing,
                    flingBehavior = fling,
                    contentPadding = PaddingValues(start = sidePad, end = sidePad, top = topPad, bottom = bottomPad + extraBottom),
                    verticalArrangement = Arrangement.spacedBy(10.dp),
                    modifier = Modifier.fillMaxSize(),
                ) {
                    items(count = engine.pageCount, key = { it }) { i ->
                        Box(Modifier.fillMaxWidth(), contentAlignment = Alignment.TopCenter) {
                            PdfPage(session, i, pageWidth, hPx, fit = false)
                        }
                    }
                    if (onAddPage != null) {
                        item(key = "add-page") {
                            Box(Modifier.fillMaxWidth().padding(vertical = 8.dp), contentAlignment = Alignment.Center) {
                                OutlinedButton(onClick = onAddPage) {
                                    Icon(Icons.Default.NoteAdd, null)
                                    Text("  Add page")
                                }
                            }
                        }
                    }
                }
            }
        } else {
            val pagerState = rememberPagerState(initialPage = session.currentPage) { engine.pageCount }
            val canSwipe = zoom.settledScale <= 1.01f && !drawing
            // A hard flick can carry across up to 12 pages; a gentle one still moves a single page
            val pagerFling = PagerDefaults.flingBehavior(
                state = pagerState,
                pagerSnapDistance = PagerSnapDistance.atMost(12),
            )

            LaunchedEffect(engine) {
                session.jumps.collect { p ->
                    if (abs(p - pagerState.currentPage) == 1) pagerState.animateScrollToPage(p) else pagerState.scrollToPage(p)
                }
            }
            LaunchedEffect(pagerState) {
                snapshotFlow { pagerState.currentPage }.distinctUntilChanged().collect {
                    session.onPageChanged(it)
                    zoom.reset()
                }
            }
            LaunchedEffect(session.autoScroll, session.autoSpeed, drawing) {
                if (!session.autoScroll || drawing) return@LaunchedEffect
                while (true) {
                    delay(((12f - 10f * session.autoSpeed) * 1000f).toLong())
                    if (session.currentPage >= engine.pageCount - 1) {
                        session.autoScroll = false
                        break
                    }
                    if (zoom.scale <= 1.01f) session.stepPage(1)
                }
            }

            ZoomContainer(
                zoom = zoom,
                drawingActive = drawing,
                scrollBy = null,
                onTap = { pos, box ->
                    when {
                        pos.x < box.width * 0.2f -> session.stepPage(-1)
                        pos.x > box.width * 0.8f -> session.stepPage(1)
                        else -> onToggleChrome()
                    }
                },
            ) {
                if (session.meta.viewMode == ViewMode.PAGED_HORIZONTAL) {
                    HorizontalPager(
                        state = pagerState,
                        modifier = Modifier.fillMaxSize(),
                        userScrollEnabled = canSwipe,
                        flingBehavior = pagerFling,
                        pageSpacing = 12.dp,
                        beyondViewportPageCount = 1,
                        key = { it },
                    ) { i ->
                        Box(Modifier.fillMaxSize(), contentAlignment = Alignment.Center) { PdfPage(session, i, wPx, hPx, fit = true) }
                    }
                } else {
                    VerticalPager(
                        state = pagerState,
                        modifier = Modifier.fillMaxSize(),
                        userScrollEnabled = canSwipe,
                        flingBehavior = pagerFling,
                        pageSpacing = 12.dp,
                        beyondViewportPageCount = 1,
                        key = { it },
                    ) { i ->
                        Box(Modifier.fillMaxSize(), contentAlignment = Alignment.Center) { PdfPage(session, i, wPx, hPx, fit = true) }
                    }
                }
            }
        }
    }
}

/** The page under the middle of the visible area (accounts for zoom, where only the top 1/scale of the list is visible). */
private fun centerPage(state: LazyListState, scale: Float): Int {
    val info = state.layoutInfo
    val visible = info.visibleItemsInfo
    if (visible.isEmpty()) return 0
    val center = info.viewportStartOffset + (info.viewportEndOffset - info.viewportStartOffset) / (2f * scale)
    return (visible.firstOrNull { it.offset <= center && center < it.offset + it.size } ?: visible.first()).index
}
